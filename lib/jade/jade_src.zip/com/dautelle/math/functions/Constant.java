/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.math.functions;

import com.dautelle.math.Operable;

/**
 * <p> This class represents a constant function (polynomial of degree 0).<p>
 * 
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, March 17, 2004
 */
public final class Constant extends Polynomial {

    /**
     * Holds the factory constructing constant instances.
     */
    private static final Factory FACTORY = new Factory() {
        public Object create() {
            return new Constant();
        }
    };

    /**
     * Default constructor.
     */
    private Constant() {}

    /**
     * Returns a constant function of specified value.
     * 
     * @param value the value returned by this function.
     * @return the corresponding constant function.
     */
    public static Constant valueOf(Operable value) {
        Constant cst = (Constant) FACTORY.object();
        cst._terms.clear();
        cst._terms.put(Term.CONSTANT, value);
        return cst;
    }
 
    /**
     * Returns the constant value for this function.
     *
     * @return <code>getCoefficient(Term.CONSTANT)</code>
     */
    public Operable getValue() {
        return getCoefficient(Term.CONSTANT);
    }

}