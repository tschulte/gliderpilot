/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

import java.io.IOException;
import java.io.Serializable;

/**
 * <p> This class provides a default implementation of the {@link Realtime} 
 *     interface.</p>
 * <p> Instances of this class should be created using a {@link Factory}.
 *     For example:<pre>
 *     public class Foo extends RealtimeObject {
 *         static final Factory FACTORY = new Factory() {
 *             public Object create() {
 *                 return new Foo();
 *             }
 *         };
 *         protected Foo() {} // Constructor for sub-classing. 
 *         public static Foo newInstance() { // Static factory method.
 *             return (Foo) FACTORY.object();
 *         }
 *         public Object export() { // Optional, only if new real-time members.
 *             ... // Exports real-time variable members.
 *             return super.export();
 *         }
 *         public Object toHeap() { // Optional, only if new real-time members.
 *             ... // Moves to heap real-time variable members.
 *             return super.toHeap();
 *         }
 *     }</pre></p>
 * <p> Instances of this class can be immutable. Instances allocated in a
 *     pool context must be {@link #export exported} if referenced
 *     after exiting the pool context.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 18, 2004
 */
public abstract class RealtimeObject implements Realtime, Serializable {

    /**
     * The pool this object belongs to or <code>HEAP</code> if this object 
     * does not come from a factory (e.g. class constructor).  
     */
    private transient Pool _pool = Pool.HEAP;

    /**
     * The index of this object in its pool.
     */
    private transient int _poolIndex;

    /**
     * Default constructor.
     */
    protected RealtimeObject() {
    }

    /**
     * Indicates if this object is an object local to the current 
     * {@link PoolContext}.
     * 
     * <p> Note: Due to the "export" rule, non-local objects cannot refer
     *           to local object.</p>
     * 
     * @return <code>true</code> if this object belongs to the current 
     *         pool context; <code>false</code> otherwise.
     */
    public final boolean isLocalObject() {
        // Object is local if its pool is local.
        return _pool.isLocal();
    }

    /**
     * Indicates if this object belongs to a {@link PoolContext}.
     * 
     * <p> Note: Due to the "export" rule, heap objects cannot refer
     *           to pool object.</p>
     *
     * @return <code>true</code> if this object belongs to a pool; 
     *         <code>false</code> if this object belongs to the heap.
     */
    public final boolean isPoolObject() {
        return !_pool.isHeap();
    }

    /**
     * Recycles this object. This method should only be called when it can be
     * asserted that this object is not going to be referenced anymore. 
     * This method affects only {@link #isLocalObject local objects}
     * and has no effect on heap objects or objects allocated outside of 
     * the current pool context. Recycling is limited to this object and 
     * its internal and has no effect on any shared member.
     */
    public void recycle() {
        if (_pool.isLocal()) {
            _pool.recycle(this);
        }
    }

    // Implements Realtime interface.
    public Object export() {
        if (_pool.isLocal()) {
            _pool.export(this);
        }
        return this;
    }

    // Implements Realtime interface.
    public Object toHeap() {
        if (_pool.isLocal()) {
            _pool.remove(this);
        } else if (!_pool.isHeap()) {
            // Non-local pools require synchronization.
            synchronized (_pool) {
                _pool.remove(this);
            }
        } // Else already on the heap.
        return this;
    }

    /**
     * Overrides the clone method to ensure that the copy references 
     * the heap pool.
     *
     * @return this object's clone allocated on the heap.
     */
    protected Object clone() {
        try {
            RealtimeObject rto = (RealtimeObject) super.clone();
            if (rto._pool != Pool.HEAP) {
                rto._pool = (Pool) rto._pool.getFactory().heapPool();
            }
            return rto;
        } catch (CloneNotSupportedException e) {
            throw new InternalError();
        }
    }

    /**
     * Special handling during deserialization to avoid <code>null</code> pool.
     *
     * @param in the object input stream.
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException,
            ClassNotFoundException {
        in.defaultReadObject();
        _pool = Pool.HEAP;
    }

    /**
     * This abstract class represents the factory responsible for the 
     * creation of {@link RealtimeObject} instances.
     */
    protected static abstract class Factory extends ObjectFactory {

        /**
         * Holds the last used pools from this factory.
         */
        private Pool _cachedPoolNT; // Normal thread.
        private Pool _cachedPoolCT; // Concurrent thread.

        /**
         * Default constructor.
         */
        public Factory() {
            _cachedPoolNT = (Pool) this.heapPool();
            _cachedPoolCT = (Pool) this.heapPool();
        }

        /**
         * Returns a new or recycled object from this factory. 
         * 
         * @return an object from the local stack or from the heap if not 
         *         executing in a pool context.
         */
        public final Object object() {
            Thread thread = Thread.currentThread();
            Pool pool = _cachedPoolNT;
            if (pool.getUser() == thread) {
                return pool.next();
            } else {
                pool = _cachedPoolCT;
                if (pool.getUser() == thread) {
                    return pool.next();
                }
            }
            return object2(thread);
        }
        private final Object object2(Thread thread) { // Cache miss.
            Pool pool = (Pool) currentPool();
            if (thread instanceof ConcurrentThread) {
                _cachedPoolCT = pool;
            } else {
                _cachedPoolNT = pool;
            }
            return pool.next();
        }

        // Overrides.
        protected ObjectPool newPool() {
            return new Pool(this);
        }
    }

    /**
     * This inner class represents a pool of {@link RealtimeObject}.
     */
    private static final class Pool extends ObjectPool {

        /**
         * Holds the pool for objects not issued from a factory (heap pool).
         */
        private static final Pool HEAP = new Pool(null);

        /**
         * Holds the pool's objects.
         */
        private RealtimeObject[] _objects = new RealtimeObject[32];

        /**
         * Holds the current pool's index.
         */
        private int _index;

        /**
         * Holds the current pool's length.
         */
        private int _length;

        /**
         * Indicates if object cleanup is enabled (default <code>true</code>).
         */
        private boolean _isCleanupEnabled = true;

        /**
         * Creates a pool for the specified factory.
         * 
         * @param factory the factory for this pool.
         */
        public Pool(ObjectFactory factory) {
            super(factory);
        }

        // Implements ObjectPool abstract method.
        public Object next() {
            return (_index > 0) ? _objects[--_index] : allocate();
        }

        private Object allocate() {
            RealtimeObject rtObj = (RealtimeObject) getFactory().create();
            if (isHeap()) {
                rtObj._pool = (Pool) getFactory().heapPool();
                return rtObj;
            } else { // Adds to the pool.
                if (_length >= _objects.length) { // Resizes.
                    RealtimeObject[] tmp = new RealtimeObject[_length * 2];
                    System.arraycopy(_objects, 0, tmp, 0, _length);
                    _objects = tmp;
                }
                rtObj._pool = this;
                rtObj._poolIndex = _length;
                _objects[_length++] = rtObj;
                return rtObj;
            }
        }

        // Implements ObjectPool abstract method.
        public void recycle(Object obj) {
            if (!this.isHeap()) { // Recycling from heap has no effect.
                RealtimeObject rtObj = (RealtimeObject) obj;
                if (rtObj._pool == this) {
                    RealtimeObject usedObject = _objects[_index];
                    _objects[rtObj._poolIndex] = usedObject;
                    usedObject._poolIndex = rtObj._poolIndex;
                    _objects[_index] = rtObj;
                    rtObj._poolIndex = _index++;
                    if (_isCleanupEnabled) {
                        cleanup(obj);
                    }
                } else {
                    throw new IllegalArgumentException(
                            "obj: Object not in the pool");
                }
            }
        }

        // Implements ObjectPool abstract method.
        public ObjectPool export(Object obj) {
            Pool outerPool = (Pool) getOuter();
            if (outerPool != null) {
                if (outerPool.isHeap()) {
                    // Exports to heap is equivalent to remove.
                    return remove(obj);
                } else {
                    // Outer pool is not local, synchronized access required.
                    synchronized (outerPool) {
                        RealtimeObject rtObj = (RealtimeObject) obj;
                        if (rtObj._pool == this) {
                            // Swaps with free outer object.
                            RealtimeObject outerObj = (RealtimeObject) outerPool
                                    .next();
                            this._objects[rtObj._poolIndex] = outerObj;
                            outerPool._objects[outerObj._poolIndex] = rtObj;
                            outerObj._pool = this;
                            rtObj._pool = outerPool;
                            // Switches indexes
                            int tmp = rtObj._poolIndex;
                            rtObj._poolIndex = outerObj._poolIndex;
                            outerObj._poolIndex = tmp;
                            return outerPool;
                        } else {
                            throw new IllegalArgumentException(
                                    "obj: Object not in the pool");
                        }
                    }
                }
            } else { // Exporting from heap has no effect.
                return this;
            }
        }

        // Implements ObjectPool abstract method.
        public ObjectPool remove(Object obj) {
            if (!isHeap()) {
                RealtimeObject rtObj = (RealtimeObject) obj;
                if (rtObj._pool == this) {
                    RealtimeObject newObj = (RealtimeObject) getFactory()
                            .create();
                    newObj._pool = this;
                    newObj._poolIndex = rtObj._poolIndex;
                    _objects[rtObj._poolIndex] = newObj;
                    Pool heapPool = (Pool) getFactory().heapPool();
                    rtObj._pool = heapPool; // Marks rtObj as heap object.
                    return heapPool;
                } else {
                    throw new IllegalArgumentException(
                            "obj: Object not in the pool");
                }
            } else { // No effect already belongs to the heap.
                return this;
            }
        }

        // Implements ObjectPool abstract method.
        protected void recycleAll() {
            for (int i = _index; _isCleanupEnabled && (i < _length);) {
                cleanup(_objects[i++]);
            }
            _index = _length;
        }

        // Implements ObjectPool abstract method.
        protected void dispose() {
            _objects = null;
            _index = 0;
            _length = 0;
        }

        /**
         * Attempts to clean-up this object. If the attempt fails, 
         * object cleaning is disabled.
         *
         * @param  obj the object to cleanup.
         */
        private void cleanup(Object obj) {
            try {
                this.getFactory().cleanup(obj);
            } catch (UnsupportedOperationException ex) {
                _isCleanupEnabled = false;
            }
        }
    }
}