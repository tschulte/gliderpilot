/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.dautelle.xml.sax.RealtimeParser;

/**
 * <p> This class restores objects which have been serialized in XML
 *     format using an {@link ObjectWriter}.</p>
 * <p> When the XML document is parsed, each elements are recursively
 *     processed and Java objects are created using the factory method
 *     <code>static Object valueOf(XmlElement)</code> of the class identified
 *     by the name of the XML element. The final object constructed
 *     (and returned) is always the root element of the XML input source.</p>
 * <p> Processing instructions are ignored, but namespaces may be used to
 *     specify package names (java addressing scheme).</p>
 * <p> For example, the following XML representation can be used to create
 *     a matrix composed of complex elements:</p>
 * <pre>
 * &lt;?xml version='1.0'?&gt;
 * &lt;Matrix xmlns="java:com.dautelle.math" row='2' column='2'&gt;
 *   &lt;Complex real='0.0' imaginary='0.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='1.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='1.0'/&gt;
 *   &lt;Complex real='0.0' imaginary='0.0'/&gt;
 * &lt;/Matrix&gt;
 * </pre>
 * <p>The following code segment creates the matrix from a file. </p>
 * <pre>
 *     Constructor constructor = new Constructor();
 *     Matrix M = (Matrix) constructor.create(file);
 * </pre>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.5, May 29, 2003
 * @see     ObjectWriter
 */
public class Constructor {

    /**
     * Holds the real-time parser used.
     */
    private final RealtimeParser _parser;

    /**
     * Holds the constructor handler.
     */
    private final ConstructorHandler _handler;

    /**
     * Default constructor (use {@link RealtimeParser} to parse XML document).
     */
    public Constructor() {
        _parser = new RealtimeParser();
        _handler = new ConstructorHandler();
        _parser.setContentHandler(_handler);
    }

    /**
     * Creates an object from its XML representation read from
     * the specified <code>InputStream</code>.
     *
     * @param  in the input stream containing the XML representation of the
     *         object being created.
     * @return a new object dynamically created.
     * @throws ConstructorException if the object cannot be created.
     */
    public Object create(InputStream in) throws ConstructorException {
        return create(new InputSource(in));
    }

    /**
     * Creates an object from its XML representation read from
     * the specified <code>Reader</code>.
     *
     * @param  reader the reader containing the XML representation of the
     *         object being created.
     * @return a new object dynamically created.
     * @throws ConstructorException if the object cannot be created.
     */
    public Object create(Reader reader) throws ConstructorException {
        return create(new InputSource(reader));
    }

    /**
     * Creates an object from its XML representation read from
     * the specified <code>File</code>.
     *
     * @param  file the file containing the XML representation of the
     *         object being created.
     * @return a new object dynamically created.
     * @throws ConstructorException if the object cannot be created.
     */
    public Object create(File file) throws ConstructorException {
        try {
            return create(new FileInputStream(file));
        } catch (FileNotFoundException e) {
            throw new ConstructorException(e);
        }
    }

    /**
     * Creates an object from its XML representation read from
     * the specified <code>URL</code>.
     *
     * @param  url the url containing the XML representation of the
     *         object being created.
     * @return a new object dynamically created.
     * @throws ConstructorException if the object cannot be created.
     */
    public Object create(URL url) throws ConstructorException {
        String systemID = url.toExternalForm();
        return create(new InputSource(systemID));
    }

    /**
     * Creates an object from its XML representation read from the specified
     * <code>InputSource</code>.
     *
     * @param  xmlSource the input source to read from.
     * @return a new object dynamically created.
     * @throws ConstructorException if the object cannot be created.
     */
    public Object create(InputSource xmlSource) throws ConstructorException {
        try {
            _parser.parse(xmlSource);
            return _handler._root;
        } catch (SAXParseException e1) {
            String message;
            if (e1.getPublicId() != null) {
                message = e1.getMessage() + " (" + e1.getPublicId() +
                    ", line " + e1.getLineNumber() +
                    ", column " +  e1.getColumnNumber() + ")";
            } else if (e1.getSystemId() != null) {
                message = e1.getMessage() + " (" + e1.getSystemId() +
                    ", line " + e1.getLineNumber() +
                    ", column " +  e1.getColumnNumber() + ")";
            } else {
                message = e1.getMessage() + " (" +
                    "line " + e1.getLineNumber() +
                    ", column " +  e1.getColumnNumber() + ")";
            }
            throw new ConstructorException(message);
        } catch (SAXException e2) {
            throw new ConstructorException(e2);
        } catch (IOException e3) {
            throw new ConstructorException(e3);
        }
    }
}