/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * This class is public domain (not copyrighted).
 */
package com.dautelle.util;
import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

/**
 * <p> This class represents the base class for all enumerates; its semantic
 *      is somewhat similar to the new JDK Tiger <code>enum</code> base type, 
 *      with some additional capabilities. In particular:<ul>
 *     <li> The enumeration is extendable (if the constructor is not private).
 *          For example:<pre>
 *     public class Event {
 *         public static abstract class BaseId extends Enum {
 *             public static final Collection VALUES = getInstances(BaseId.class);
 *         }
 *     }
 *     public class MouseEvent extends Event {
 *         public static class Id extends BaseId {
 *             public static final Collection VALUES = getInstances(Id.class);
 *             public static final Id MOUSE_CLICKED = new Id();
 *             public static final Id MOUSE_PRESSED = new Id();
 *             public static final Id MOUSE_RELEASED = new Id();
 *         }
 *     }
 *     public class KeyEvent extends Event {
 *         public static class Id extends BaseId {
 *             public static final Collection VALUES = getInstances(Id.class);
 *             public static final Id KEY_PRESSED = new Id();
 *             public static final Id KEY_RELEASED = new Id();
 *         }
 *     }</pre></li>
 *     <li> {@link Enum}'s instances can be mapped to custom values (up to 
 *          <code>long</code>) for use in <code>switch</code> statements,
 *         bit-wise sets (values power of 2) or look-up tables.
 *         Duplications (name or value) would result in exception thrown 
 *         during initialization:
 *     <pre>
 *     public static final class Color extends Enum {
 *         public static final Collection VALUES = getInstances(Color.class);
 *         private Color(int value, String name)  { // Not extendable (private)
 *             super(value, name);
 *         }
 *         public static final int RED_VALUE = 0xFF0000;
 *         public static final Color RED = new Color(RED_VALUE, "red");
 *
 *         public static final int GREEN_VALUE = 0x00FF00;
 *         public static final Color GREEN = new Color(GREEN_VALUE, "green");
 *
 *         public static final int BLUE_VALUE = 0x0000FF;
 *         public static final Color BLUE = new Color(BLUE_VALUE, "blue");
 *     }
 *     ...
 *     Color color;
 *     switch (color.intValue()) {
 *         case Color.RED_VALUE:
 *         case Color.GREEN_VALUE:
 *         case Color.BLUE_VALUE:
 *     }
 *     </pre></li>
 *     <li> Enum's hierarchies may exist, as {@link Enum} are
 *          not implicitly <code>final</code>. For example:<pre>
 *     public static class WeekDay extends Enum {
 *         public static final Collection VALUES = getInstances(WeekDay.class);
 *         public static final WeekDay SATURDAY = new WeekDay();
 *         public static final WeekDay SUNDAY = new WeekDay();
 *     }
 *     public static class WorkDay extends WeekDay {
 *         public static final Collection VALUES = getInstances(WorkDay.class);
 *         public static final WorkDay MONDAY = new WorkDay();
 *         public static final WorkDay TUESDAY = new WorkDay();
 *         public static final WorkDay WEDNESDAY = new WorkDay();
 *         public static final WorkDay THURSDAY = new WorkDay();
 *         public static final WorkDay FRIDAY = new WorkDay();
 *     }
 *     ...
 *     for (Iterator i = WorkDay.VALUES.iterator(); i.hasNext(); ) {
 *         // Iterates through the five workdays.
 *     }       
 *     for (Iterator i = WeekDay.VALUES.iterator(); i.hasNext(); ) {
 *         // Iterates through the seven weekdays.
 *     }</pre></li>
 *     <li> Finally, this class does not require the latest JDK1.5+</li></ul>
 *
 * <p> <b>Limitations:</b> Unlike the JDK1.5 <code>enum</code> base type, 
 *     instances of this class cannot be used directly in a <code>switch</code>
 *     statement. Although, for mapped's values (see <code>Color</code> example
 *     above) a <code>switch</code> on the enum's value is always possible. 
 *     This approach is also faster as it does not require 
 *     a "multiway if-statement" or "array indirection" 
 *     (Ref. <a href=
 *     "http://jcp.org/aboutJava/communityprocess/jsr/tiger/enum.html">
 *     JDK 1.5 Enum: IV. Implementation Notes</a>).</p>
 *
 * <p><i> This class is <b>public domain</b> (not copyrighted).</i></p>
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 5.3, December 10, 2003
 */
public abstract class Enum extends Number implements Serializable, Comparable {

    /**
     * Holds the value-to-enum mappings per class.
     */
    private static final HashMap VALUE_ENUM_PER_CLASS = new HashMap();

    /**
     * Holds the name-to-enum mappings per class.
     */
    private static final HashMap NAME_ENUM_PER_CLASS = new HashMap();

    /**
     * Holds the value of this enum.
     */
    private transient final long _value;

    /**
     * Holds the name of this enum (for anonymous class: "className#ordinal").
     */
    private final String _name;

    /**
     * Default constructor. The value of this enum is one more than the previous
     * enum (starting at <code>0</code>). This constructor is typically used for
     * anonymous extendable enumerations (with value automatically assigned).
     *
     * @throws IllegalStateException if an enum with same value already exists.
     */
    protected Enum() {
        this(null, null);
    }

    /**
     * Creates an enumerate of specified name. The value of this enum is
     * one more than the previous enum (starting at <code>0</code>).
     * This constructor is typically used for extendable named enumerations
     * (with value automatically assigned).
     *
     * @param  name the name for this enum.
     * @throws IllegalStateException if an enum with same name or same value
     *         already exists.
     */
    protected Enum(String name) {
        this(null, name);
    }
    
    /**
     * Creates an enumerate of specified value. This constructor is typically 
     * used for non-extendable anonymous enumerations (e.g. masks with value
     * power of 2).
     *
     * @param  value the value for this enum.
     * @throws IllegalStateException if an enum with same value already exists.
     */
    protected Enum(long value) {
        this(new LongValue(value), null);
    }

    /**
     * Creates an enumerate of specified value and specified name.
     * This constructor is typically used for enumeration usable in 
     * <code>switch</code> statements (e.g. state machine) with values 
     * being defined by <code>public final static int/long</code> constants.
     *
     * @param  value the value for this enum.
     * @param  name the name for this enum.
     * @throws IllegalStateException if an enum with same name or same value
     *         already exists.
     */
    protected Enum(long value, String name) {
        this(new LongValue(value), name);
    }

    /**
     * Base constructor.
     *
     * @param  value the value for this enum or <code>null</code> if none.
     * @param  name the name for this enum or <code>null</code> if none.
     * @throws IllegalStateException if an enum with same name or same value
     *         already exists.
     */
    private Enum(LongValue value, String name){
        synchronized (Enum.class) {
            Class rootClass = this.getRootClass();
            
            // Maps value.
            FastMap values = (FastMap) VALUE_ENUM_PER_CLASS.get(rootClass);
            if (values == null) {
                values = new FastMap(); 
                VALUE_ENUM_PER_CLASS.put(rootClass, values);
            }
            if (value == null) { // Value automatically assigned.
                value = new LongValue(values.size());
            }
            if (values.containsKey(value)) {
                throw new IllegalStateException(
                  "Value: " + value + " already assigned");
            }
            values.put(value, this);
            // Adds to intermediate enum collections.
            for (Class enumClass = getClass(); enumClass != rootClass;
                enumClass = enumClass.getSuperclass()) {
                values = (FastMap) VALUE_ENUM_PER_CLASS.get(enumClass);
                if (values == null) {
                    values = new FastMap(); 
                    VALUE_ENUM_PER_CLASS.put(enumClass, values);
                }
                values.put(value, this);
            }
        
            // Maps name.
            FastMap names = (FastMap) NAME_ENUM_PER_CLASS.get(rootClass);
            if (names == null) {
                names = new FastMap(); 
                NAME_ENUM_PER_CLASS.put(rootClass, names);
            }
            if (name == null) { // Assigns a unique name per class
                                // (used for serialization).
                FastMap map = (FastMap)NAME_ENUM_PER_CLASS.get(this.getClass());
                int ordinal = (map != null) ? map.size() : 0;
                name = this.getClass().getName() + '#' + ordinal;
            }
            if (names.containsKey(name)) {
                throw new IllegalStateException(
                  "Name: " + name + " already assigned");
            }
            names.put(name, this);
            // Adds to intermediate enum collections.
            for (Class enumClass = getClass(); enumClass != rootClass;
                enumClass = enumClass.getSuperclass()) {
                names = (FastMap) NAME_ENUM_PER_CLASS.get(enumClass);
                if (names == null) {
                    names = new FastMap(); 
                    NAME_ENUM_PER_CLASS.put(enumClass, names);
                }
                names.put(name, this);
            }

            _value = value._long;
            _name = name;
        }
    }
    private Class getRootClass() {
        Class rootClass = this.getClass();
        while (rootClass.getSuperclass() != Enum.class) {
            rootClass = rootClass.getSuperclass();
        }
        return rootClass;
    }

    /**
     * Compares this enum with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     *
     * @param  o the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     *	       is less than, equal to, or greater than the specified object.
     * @throws ClassCastException if the specified object's type prevents it
     *         from being compared to this object.
     */
    public int compareTo(Object o) {
        if (this.getRootClass() == ((Enum)o).getRootClass()) {
            return (((Enum)o)._value == _value) ? 0 :
                (((Enum)o)._value < _value) ? -1 : 1;
        } else {
            throw new ClassCastException(
                "Cannot compare " + this.getClass() +
                " with " + o.getClass());
        }
    }

    /**
     * Returns a read-only list of the specified enumeration.
     * The collection returned is backed by the actual collection of enums
     * -- so it grows as more enums are defined. The iteration order of 
     * the collection returned is always the declarative order of the 
     * {@link Enum} regardless of their actual values. This method is 
     * typically used to export the constant <code>VALUES</code> as in<pre>
     * public static Color extends Enum {
     *     public static final Collection VALUES = getInstances(Color.class);
     *     ... 
     * }</pre>
     *
     * @param  enumClass the enum class.
     * @return an unmodifiable view of the enum collection.
     */
    protected static Collection getInstances(Class enumClass) {
        synchronized (Enum.class) {
            FastMap values = (FastMap)VALUE_ENUM_PER_CLASS.get(enumClass);
            if (values == null) {
                values = new FastMap();
                VALUE_ENUM_PER_CLASS.put(enumClass, values);
            }
            return Collections.unmodifiableCollection(values.values());
        }
    }

    /**
     * Returns the enum with the specified value. This method also ensures
     * that the specified class has been initialized.
     *
     * @param  value the value of the enum to search for.
     * @param  enumClass the class of the enum to return.
     * @return the enum with the specified value or <code>null</code>
     *         if not found.
     */
    public static Enum valueOf(long value, Class enumClass) {
        synchronized (Enum.class) {
            ensureInitialization(enumClass);
            FastMap values = (FastMap)VALUE_ENUM_PER_CLASS.get(enumClass);
            KEY_VALUE._long = value; // Avoids object creation.
            return (values != null) ? (Enum) values.get(KEY_VALUE) : null;
        }
    }
    private static final LongValue KEY_VALUE = new LongValue(0);

    /**
     * Returns the enum with the specified name. This method also ensures
     * that the specified class has been initialized.
     *
     * @param  name the name of the enum to search for.
     * @param  enumClass the class of the enum to return.
     * @return the enum such as <code>name.equals(enum.getName())</code>
     *         or <code>null</code> if not found.
     */
    public static Enum valueOf(CharSequence name, Class enumClass) {
        synchronized (Enum.class) {
            ensureInitialization(enumClass);
            FastMap names = (FastMap)NAME_ENUM_PER_CLASS.get(enumClass);
            return (names != null) ? (Enum) names.get(name) : null;
        }
    }

    /////////////////////////////
    // Parent abstract methods //
    /////////////////////////////

    /**
     * Returns this enum's value as a <code>int</code>.
     * This may involve rounding or truncation.
     *
     * @return  the numeric value represented by this enum after conversion
     *          to type <code>int</code>.
     */
    public final int intValue() {
        return (int) _value;
    }

    /**
     * Returns this enum's value as a <code>long</code>.
     *
     * @return  the numeric value represented by this enum after conversion
     *          to type <code>long</code>.
     */
    public final long longValue() {
        return _value;
    }

    /**
     * Returns this enum's value as a <code>float</code>.
     * This may involve rounding.
     *
     * @return  the numeric value represented by this enum after conversion
     *          to type <code>float</code>.
     */
    public final float floatValue() {
        return _value;
    }

    /**
     * Returns this enum's value as a <code>double</code>.
     * This may involve rounding.
     *
     * @return the numeric value represented by this enum after conversion
     *         to type <code>double</code>.
     */
    public final double doubleValue() {
        return _value;
    }

    /**
     * Returns the unique name for this enum. For anonymous enum, 
     * the name is constructed from the enum class and the declarative 
     * order of the enum <b>within</b> its class (e.g. <code>Color#0</code>
     * for the first declared color in the <code>Color</code> class).
     *
     * @return the name specified at construction or an unique name derived  
     *         from the enum class name and its declarative order.
     */
    public final String getName() {
        return _name;
    }

    /**
     * Returns a string representation of this enum.
     *
     * @return {@link #getName()}
     */
    public String toString() {
        return _name;
    }

    /**
     * Overrides <code>readResolve()</code> to support
     * <code>Serialization</code>. Enum are uniquely identified by their
     * name (independantly of their values to avoid class loading dependencies). 
     *
     * @return  the unique enum identified by the serialized name.
     * @throws  ObjectStreamException if the enum is not found.
     * @see     #getName()
     */
    protected Object readResolve() throws ObjectStreamException {
        // Searches using unique name.
        Enum e = valueOf(this._name, this.getClass());
        if (e != null) {
            return e; 
        } else {// Not found.
            throw new InvalidObjectException ("Enum: " + this + " not found");
        }
    }
    
    /**
     * Throws CloneNotSupportedException.  This guarantees that enums
     * are never cloned, which is necessary to preserve their "singleton"
     * status.
     *
     * @return (never returns)
     */
    protected final Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Enum cannot be cloned");
    }

    /**
     * This class represents a long value for value-to-enum mappings. 
     */
    private static final class LongValue {
        long _long;
        LongValue(long value) {
            _long = value;
        }
        public boolean equals(Object that) {
            return (this._long == ((LongValue)that)._long);
        }
        public int hashCode() {
            return (int)_long;
        }
    }

    /**
     * Ensures initialization of the specified enum class.
     * 
     * @param  enumClass the class to ensure the initialization. 
     */
    private static void ensureInitialization(Class enumClass) {
        if (!VALUE_ENUM_PER_CLASS.containsKey(enumClass)) {
            // Unfortunately, there is no easy way to force class 
            // initialization.
            try {  
                Class.forName(enumClass.getName());
            } catch (ClassNotFoundException e) {
                throw new InternalError(); // Should never get there.
            }
        }
    }
}