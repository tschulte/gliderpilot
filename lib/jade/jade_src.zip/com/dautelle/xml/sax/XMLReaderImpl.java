/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml.sax;
import java.io.IOException;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * <p> This class provides a SAX2-compliant parser wrapping a
 *     {@link RealtimeParser}.</p>
 *
 * <p> <b>See {@link SAXParserFactoryImpl} for Plug-In Installation:</b></p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.5, May 26, 2003
 */
public final class XMLReaderImpl implements XMLReader {

    /**
     * Holds the SAX2 default handler instance.
     */
    private static DefaultHandler DEFAULT_HANDLER = new DefaultHandler();

    /**
     * Holds the real-time parser instance associated to this SAX2 parser.
     */
    private final RealtimeParser _parser;

    /**
     * Default constructor.
     */
    public XMLReaderImpl() {
         _parser = new RealtimeParser();
         Proxy proxy = new Proxy(_parser);
         _parser.setContentHandler(proxy);
    }

    // Implements XMLReader
    public boolean getFeature(String name)
        throws SAXNotRecognizedException, SAXNotSupportedException {
        return _parser.getFeature(name);
    }

    // Implements XMLReader
    public void setFeature(String name, boolean value)
            throws SAXNotRecognizedException, SAXNotSupportedException {
        _parser.setFeature(name, value);
    }

    // Implements XMLReader
    public Object getProperty(String name)
        throws SAXNotRecognizedException, SAXNotSupportedException {
        return _parser.getProperty(name);
    }


    // Implements XMLReader
    public void setProperty (String name, Object value)
	    throws SAXNotRecognizedException, SAXNotSupportedException {
        _parser.setProperty(name, value);
    }

    // Implements XMLReader
    public void setEntityResolver(EntityResolver resolver) {
        _parser.setEntityResolver(resolver);
    }

    // Implements XMLReader
    public EntityResolver getEntityResolver() {
        return _parser.getEntityResolver();
    }

    // Implements XMLReader
    public void setDTDHandler(DTDHandler handler) {
        _parser.setDTDHandler(handler);
    }

    // Implements XMLReader
    public DTDHandler getDTDHandler () {
        return _parser.getDTDHandler();
    }

    // Implements XMLReader
    public void setContentHandler(ContentHandler handler) {
        if (handler != null) {
            Proxy proxy = (Proxy) _parser.getContentHandler();
            proxy._sax2Handler = handler;
        } else {
            throw new NullPointerException();
        }
    }

    // Implements XMLReader
    public ContentHandler getContentHandler() {
        Proxy proxy = (Proxy) _parser.getContentHandler();
        return (proxy._sax2Handler == DEFAULT_HANDLER) ?
            null : proxy._sax2Handler;
    }

    // Implements XMLReader
    public void setErrorHandler(ErrorHandler handler) {
        _parser.setErrorHandler(handler);
    }

    // Implements XMLReader
    public ErrorHandler getErrorHandler() {
        return _parser.getErrorHandler();
    }

    // Implements XMLReader
    public void parse(InputSource input) throws IOException, SAXException {
        _parser.parse(input);
    }

    // Implements XMLReader
    public void parse(String systemId) throws IOException, SAXException {
        _parser.parse(systemId);
    }

    /**
     * This class defines the proxy for content handler and attributes.
     */
    private static final class Proxy implements
            com.dautelle.xml.sax.ContentHandler, Attributes {

        /**
         * Holds the SAX2 content handler to which SAX2 events are forwarded.
         */
        private ContentHandler _sax2Handler = DEFAULT_HANDLER;

        /**
         * Holds the real-time attributes implementation from which attributes
         * values are read.
         */
        private final AttributesImpl _attributes;

        /**
         * Creates a proxy for the specified {@link RealtimeParser}.
         *
         * @param parser the real-time parser.
         */
        public Proxy(RealtimeParser parser) {
            _attributes = parser._attributes;
        }

        // Implements ContentHandler
        public void setDocumentLocator(Locator locator) {
            _sax2Handler.setDocumentLocator(locator);
        }

        // Implements ContentHandler
        public void startDocument() throws SAXException {
            _sax2Handler.startDocument();
        }

        // Implements ContentHandler
        public void endDocument() throws SAXException {
            _sax2Handler.endDocument();
        }

        // Implements ContentHandler
        public void startPrefixMapping(CharSequence prefix, CharSequence uri)
                throws SAXException {
            _sax2Handler.startPrefixMapping(prefix.toString(), uri.toString());
        }

        // Implements ContentHandler
        public void endPrefixMapping(CharSequence prefix) throws SAXException {
            _sax2Handler.endPrefixMapping(prefix.toString());
        }

        // Implements ContentHandler
        public void startElement(
                CharSequence namespaceURI, CharSequence localName,
                CharSequence qName, com.dautelle.xml.sax.Attributes atts)
                throws SAXException {
            _sax2Handler.startElement(
                namespaceURI.toString(), localName.toString(),
                qName.toString(), this);
        }

        // Implements ContentHandler
        public void endElement(
                CharSequence namespaceURI, CharSequence localName,
                CharSequence qName) throws SAXException {
            _sax2Handler.endElement
                (namespaceURI.toString(), localName.toString(),
                qName.toString());
        }

        // Implements ContentHandler
        public void characters(char ch[], int start, int length)
                throws SAXException {
            _sax2Handler.characters(ch, start, length);
        }

        // Implements ContentHandler
        public void ignorableWhitespace(char ch[], int start, int length)
                throws SAXException {
            _sax2Handler.ignorableWhitespace(ch, start, length);
        }

        // Implements ContentHandler
        public void processingInstruction(
                CharSequence target, CharSequence data) throws SAXException {
            _sax2Handler.processingInstruction(
                target.toString(), data.toString());
        }

        // Implements ContentHandler
        public void skippedEntity(CharSequence name) throws SAXException {
            _sax2Handler.skippedEntity(name.toString());
        }

        // Implements Attributes
        public int getLength() {
            return _attributes.getLength();
        }

        // Implements Attributes
        public String getURI(int index) {
            CharSequence chars = _attributes.getURI(index);
            return (chars != null) ? chars.toString() : null;
        }

        // Implements Attributes
        public String getLocalName(int index) {
            CharSequence chars = _attributes.getLocalName(index);
            return (chars != null) ? chars.toString() : null;
        }

        // Implements Attributes
        public String getQName(int index) {
            CharSequence chars = _attributes.getQName(index);
            return (chars != null) ? chars.toString() : null;
        }

        // Implements Attributes
        public String getType(int index) {
            return _attributes.getType(index);
        }

        // Implements Attributes
        public String getValue(int index) {
            CharSequence chars = _attributes.getValue(index);
            return (chars != null) ? chars.toString() : null;
        }

        // Implements Attributes
        public int getIndex(String uri, String localName) {
            return _attributes.getIndex(uri, localName);
        }

        // Implements Attributes
        public int getIndex(String qName) {
            return _attributes.getIndex(qName);
        }

        // Implements Attributes
        public String getType(String uri, String localName) {
            return _attributes.getType(uri, localName);
        }

        // Implements Attributes
        public String getType(String qName) {
            return _attributes.getType(qName);
        }

        // Implements Attributes
        public String getValue(String uri, String localName) {
            CharSequence chars = _attributes.getValue(uri, localName);
            return (chars != null) ? chars.toString() : null;
        }

        // Implements Attributes
        public String getValue(String qName) {
            CharSequence chars = _attributes.getValue(qName);
            return (chars != null) ? chars.toString() : null;
        }
    }
}