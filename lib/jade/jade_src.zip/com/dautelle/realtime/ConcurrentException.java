/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

/**
 * This class encapsulates errors or exceptions raised during the execution
 * of concurrent threads ({@link ConcurrentException} are raised upon exit of
 * the {@link ConcurrentContext}). 
 * {@link ConcurrentException#getCause} identifies the source of the error.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 5.0, August 17, 2003
 * @see     ConcurrentContext#exit
 */
public class ConcurrentException extends RuntimeException {

    /**
     * Constructs a {@link ConcurrentException} caused by the specified
     * error or exception.
     *
     * @param cause the cause of the error or exception.
     */
    ConcurrentException(Throwable cause) { 
        if (cause instanceof ConcurrentException) {
            initCause(cause.getCause());
        } else {
            initCause(cause);
        }
    }

    /**
     * Returns the original cause of the exception or error.
     *
     * @return the exception or error as it has been raised by the
     *         <code>java.lang.Runnable</code>.
     */
    public Throwable getCause() { // For documentation purpose only.
        return super.getCause();
    }
}