/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import com.dautelle.realtime.RealtimeObject;

/**
 * <p> This class represents a <code>Set</code> backed by a {@link FastMap}
 *     instance.</p>
 * 
 * <p> Instances of this class can directly be allocated from the current
 *     thread stack using the {@link #newInstance} factory method
 *     (e.g. for throw-away set to avoid the creation cost).</p>  
 * 
 * <p> {@link FastSet} has a predictable iteration order, which is the order
 *     in which the element were added to the set. The set iterator
 *     is also real-time compliant (allocated on the stack when running 
 *     in a pool context).</p>
 * 
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, Mar 24, 2004
 */
public class FastSet extends RealtimeObject implements Set, Cloneable {

    /**
     * Holds the backing map.
     */
    private FastMap _map;
    
    /**
     * Base constructor.
     * 
     * @param map the backing map.
     */
    private FastSet(FastMap map) {
        _map = map;
    }

    /**
     * Creates a {@link FastSet} with a capacity of <code>16</code> elements.
     */
    public FastSet() {
        this(16);
    }

    /**
     * Creates a {@link FastSet}, copy of the specified <code>Set</code>.
     * If the specified set is not an instance of {@link FastSet}, the 
     * newly created set has a capacity set to the specified set's size.
     * The copy has the same order as the original, regardless of the original 
     * set's implementation.
     * 
     * @param  set the set whose elements are to be placed in this set.
     */
    public FastSet(Set set) {
        this((set instanceof FastSet) ? 
           ((FastSet)set)._map.capacity() : set.size());
        addAll(set);
    }
    
    /**
     * Creates a {@link FastSet} with the specified capacity. Unless the 
     * capacity is exceeded, operations on this set do not allocate memory.
     * For optimum performance, the capacity should be of the same order 
     * of magnitude or larger than the expected set's size.
     * 
     * @param  capacity the initial capacity of the backing map.
     */
    public FastSet(int capacity) {
        this(new FastMap(capacity));
    }

    /**
    * Returns a {@link FastSet} allocated from the current
    * stack (or the heap if not in a pool context). 
    *
    * @param capacity the minimum capacity for the set to return.
    * @return a new or recycled set instance.
    */
    public static FastSet newInstance(int capacity) {
         FastSet fastSet = (FastSet)FACTORY.object();
         fastSet._map = FastMap.newInstance(capacity);
         return fastSet;
    }
    private static final Factory FACTORY = new Factory() {
        public Object create() {
            return new FastSet((FastMap)null);
        }
        public void cleanup(Object obj) {
            // The backing map is external to the set (free to be reused
            // independently). Clears the reference.
            ((FastSet)obj)._map = null; 
        }
    };

    /**
     * Returns the number of elements in this set (its cardinality). 
     *
     * @return the number of elements in this set (its cardinality).
     */
    public int size() {
        return _map.size();
    }

    /**
     * Returns <code>true</code> if this set contains no elements.
     *
     * @return <code>true</code> if this set contains no elements.
     */
    public boolean isEmpty() {
        return _map.isEmpty();
    }

    /**
     * Returns <code>true</code> if this set contains the specified element.
     *
     * @param o element whose presence in this set is to be tested.
     * @return <code>true</code> if this set contains the specified element.
     */
    public boolean contains(Object o) {
        return _map.containsKey(o);
    }

    /**
     * Returns an iterator over the elements in this set.  The elements are
     * returned in is the order in which they were inserted into the map.
     *
     * @return an iterator over the elements in this set.
     */
    public Iterator iterator() {
        return _map.keySet().iterator();
    }

    /**
     * Adds the specified element to this set if it is not already present.
     *
     * @param o element to be added to this set.
     * @return <code>true</code> if this set did not already contain the 
     *         specified element.
     */
    public boolean add(Object o) {
        return _map.put(o, o) == null;
    }

    /**
     * Removes the specified element from this set if it is present.
     *
     * @param o object to be removed from this set, if present.
     * @return true if the set contained the specified element.
     */
    public boolean remove(Object o) {
        return _map.remove(o) == o;
    }

    /**
     * Removes all of the elements from this set.
     */
    public void clear() {
        _map.clear();
    }

    /**
     * Returns a shallow copy of this {@link FastSet}. The keys and
     * the values themselves are not cloned  but moved to the heap as well.
     *
     * @return a shallow copy of this set.
     */
    public Object clone() {
        FastSet fastSet = (FastSet) super.clone();
        fastSet._map = (FastMap) _map.clone();
        return fastSet;
    }

    /**
     * Compares the specified object with this {@link FastSet} for equality. 
     * Returns <code>true</code> if the given object is also a set and the two
     * set represent the collection (regardless of collection iteration
     * order).
     *
     * @param obj the object to be compared for equality with this set.
     * @return <code>true</code> if the specified object is equal to this set;
     *         <code>false</code> otherwise.
     */
    public boolean equals(Object obj) {
        return _map.entrySet().equals(obj);
    }

    /**
     * Returns the hash code value for this {@link FastSet}.
     *
     * @return the hash code value for this set.
     */
    public int hashCode() {
        return _map.entrySet().hashCode();
    }

    /**
     * Adds all of the elements in the specified collection to this set if
     * they're not already present.
     *
     * @param c collection whose elements are to be added to this set.
     * @return <code>true</code> if this set changed as a result of the call.
     */
    public boolean addAll(Collection c) {
        boolean modified = false;
        Iterator e = c.iterator();
        while (e.hasNext()) {
            if (add(e.next())) {
                modified = true;
            }
        }
        return modified;
    }

    /**
     * Returns <code>true</code> if this set contains all of the elements of the
     * specified collection.  If the specified collection is also a set, this
     * method returns <code>true</code> if it is a <i>subset</i> of this set.
     *
     * @param  c collection to be checked for containment in this set.
     * @return <code>true</code> if this set contains all of the elements of the
     *         specified collection.
     */
    public boolean containsAll(Collection c) {
        return _map.keySet().containsAll(c);
    }

    /**
     * Removes from this set all of its elements that are contained in the
     * specified collection. If the specified collection is also a set, 
     * this operation effectively modifies this set so that its value is
     * the <i>asymmetric set difference</i> of the two sets.
     *
     * @param c collection that defines which elements will be removed from
     *        this set.
     * @return <code>true</code> if this set changed as a result of the call.
     */
    public boolean removeAll(Collection c) {
        return _map.keySet().removeAll(c);
    }

    /**
     * Retains only the elements in this set that are contained in the
     * specified collection. In other words, removes from this set all of its 
     * elements that are not contained in the specified collection. 
     * If the specified collection is also a set, this operation effectively 
     * modifies this set so that its value is the <i>intersection</i> of the
     * two sets.
     *
     * @param c collection that defines which elements this set will retain.
     * @return <code>true</code> if this collection changed as a result of the
     *         call.
     */
    public boolean retainAll(Collection c) {
        return _map.keySet().retainAll(c);
    }

    /**
     * Returns an array containing all of the elements in this set.
     *
     * @return an array containing all of the elements in this set.
     */
    public Object[] toArray() {
        return _map.keySet().toArray();
    }

    /**
     * Returns an array containing all of the elements in this set; the 
     * runtime type of the returned array is that of the specified array. 
     *
     * @param a the array into which the elements of this set are to
     *      be stored, if it is big enough; otherwise, a new array of the
     *      same runtime type is allocated for this purpose.
     * @return an array containing the elements of this set.
     */
    public Object[] toArray(Object[] a) {
        return _map.keySet().toArray(a);
    }

    /**
     * Returns a <code>String</code> representation of this set.
     *
     * @return the backing map key set representation.
     */
    public String toString() {
        return _map.keySet().toString();
    }

    // Overrides.
    public Object export() {
        _map.export();
        return super.export();
    }

    // Overrides.
    public Object toHeap() {
        _map.toHeap();
        return super.toHeap();
    }

    // Overrides.
    public void recycle() {
        super.recycle();
        _map.recycle(); // The map is not a shared member.
    }

}