/*
 * J.A.D.E. Java(TM) Addition to Default Environment. Latest release available
 * at http://jade.dautelle.com/ Copyright (C) 2004 Jean-Marie Dautelle.
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation (http://www.gnu.org/copyleft/lesser.html); either
 * version 2.1 of the License, or any later version.
 */
package com.dautelle.math;

import com.dautelle.realtime.ArrayPool;
import com.dautelle.realtime.ObjectPool;
import com.dautelle.realtime.PoolContext;
import com.dautelle.xml.Representable;
import com.dautelle.xml.XmlElement;

/**
 * <p> This class represents an integer number of arbitrary size.</p>
 * <p> It has the following advantages over the 
 *     <code>java.math.BigInteger</code> class:
 * <ul>
 *     <li> Optimized for 64 bits architectures. But still runs significantly 
 *          faster on 32 bits processors.</li>
 *     <li> Real-time compliant for improved performance and predictability.
 *          No temporary object allocated on the heap and no garbage collection
 *          if executions are performed within a {@link PoolContext}
 *          (e.g. {@link #add add} operation <b>5x</b> faster).</li>
 *     <li> Implements the {@link Operable} interface for modular
 *          arithmetic and can be used in conjonction with the {@link Matrix}
 *          class to resolve modulo equations (ref. number theory).
 *          <b>(WORK IN PROGRESS)</b></li>
 *     <li> Improved algorithms (e.g. FFT multiplication in O(nlog(n))
 *          instead of O(n<sup>2</sup>) <b>(WORK IN PROGRESS)</b>.</li>
 *     <li> For very large numbers, internal use of 
 *          {@link com.dautelle.realtime.ConcurrentContext ConcurrentContext}
 *          for automatic distribution of CPUs work load<b> (WORK IN PROGRESS)
 *          </b>.</li>
 * </ul></p>
 * 
 * @author <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 24, 2004
 */
public final class LargeInteger extends RealtimeNumber
        implements
            Comparable,
            Operable,
            Representable {

    /**
     * Holds the maximum words size for words to be intrinsic .
     */
    private static final int INTRINSIC_WORDS_SIZE = 18;

    /**
     * Holds the LargeInteger factory with intrinsic words array.
     */
    private static final Factory FACTORY_INTRINSIC_WORDS = new Factory() {
        public Object create() {
            return new LargeInteger(new long[INTRINSIC_WORDS_SIZE]);
        }
    };

    /**
     * Holds the LargeInteger factory with external words array. 
     */
    private static final Factory FACTORY_EXTERNAL_WORDS = new Factory() {
        public Object create() {
            return new LargeInteger(null);
        }
        public void cleanup(Object obj) {
            ((LargeInteger) obj)._words = null; // Clears external reference.
        }
    };

    /**
     * The large integer representing the additive identity.
     */
    public static final LargeInteger ZERO = (LargeInteger) LargeInteger
            .valueOf(0).toHeap();

    /**
     * The large integer representing the multiplicative identity.
     */
    public static final LargeInteger ONE = (LargeInteger) LargeInteger
            .valueOf(1).toHeap();

    /**
     * Indicates if this large integer is negative.
     */
    private boolean _isNegative;

    /**
     * The size of this large integer in words. 
     * The most significand word different from 0 is at index: _size-1
     */
    private int _size;

    /**
     * This large integer positive words (63 bits). 
     * Least significant word first (index 0).
     */
    private long[] _words;

    /**
     * Holds the remainder after a {@link #divide} operation.
     */
    private LargeInteger _remainder;

    /**
     * Base constructor.
     * 
     * @param words the words buffer or <code>null</code> for external 
     *        allocations.
     */
    private LargeInteger(long[] words) {
        _words = words;
    }

    /**
     * Returns the large integer of specified <code>long</code> value.
     * 
     * @param  value the <code>long</code> value.
     * @return the corresponding large integernumber.
     */
    public static LargeInteger valueOf(long value) {
        if (value >= 0) {
            LargeInteger z = newInstance(1);
            z._isNegative = false;
            z._size = (value == 0) ? 0 : 1;
            z._words[0] = value;
            return z;
        } else {
            if (value != Long.MIN_VALUE) {
                LargeInteger z = newInstance(1);
                z._isNegative = true;
                z._size = 1;
                z._words[0] = -value;
                return z;
            } else { // Negative would overflow.
                LargeInteger z = newInstance(2);
                z._isNegative = true;
                z._size = 2;
                z._words[0] = 0;
                z._words[1] = 1;
                return z;
            }
        }
    }

    /**
     * Returns the large integer of specified two's-complement binary
     * representation. The input array is assumed to be in <i>big-endian</i>
     * byte-order: the most significant byte is at the offset position.
     * 
     * <p>Note: This representation is consitent with <code>java.lang.BigInteger
     *          </code> byte array representation and can be used for conversion 
     *          between the two classes.</p>
     * 
     * @param  bytes the binary representation (two's-complement).
     * @param  offset the offset at which to start reading the bytes.
     * @param  length the maximum number of bytes to read.
     * @return the corresponding large integer number.
     * @throws IndexOutOfBoundsException 
     *         if <code>offset + length > bytes.length</code>  
     * @see    #toByteArray
     */
    public static LargeInteger valueOf(byte[] bytes, int offset, int length) {
        // Ensures result is large enough (takes into account potential
        // extra bits during negative to positive conversion).
        LargeInteger z = newInstance(((length * 8 + 1) / 63) + 1);
        final boolean isNegative = bytes[offset] < 0;
        int wordIndex = 0;
        int bitIndex = 0;
        z._words[0] = 0;
        for (int i = offset + length; i > offset; bitIndex += 8) {
            long bits = (isNegative ? ~bytes[--i] : bytes[--i]) & MASK_8;
            if (bitIndex < 63 - 8) {
                z._words[wordIndex] |= bits << bitIndex;
            } else { // End of word reached.
                z._words[wordIndex] |= (bits << bitIndex) & MASK_63;
                bitIndex -= 63; // In range [-8..-1]
                z._words[++wordIndex] = bits >> -bitIndex;
            }
        }
        // Calculates size.
        while (z._words[wordIndex] == 0) {
            if (--wordIndex < 0) {
                break;
            }
        }
        z._size = wordIndex + 1;
        z._isNegative = isNegative;

        // Converts one's-complement to two's-complement if negative.
        if (isNegative) { // Adds ONE.
            if (z._size > 0) {
                z._size = add(z._words, z._size, ONE._words, 1, z._words);
            } else {
                z._size = add(ONE._words, 1, z._words, 0, z._words);
            }
        }
        return z;
    }

    /**
     * Returns the large integer for the specified character sequence in
     * decimal number.
     * 
     * @param chars the character sequence.
     * @return {@link #valueOf(CharSequence, int) valueOf(chars, 10)}
     */
    public static LargeInteger valueOf(CharSequence chars) {
        return valueOf(chars, 10);
    }

    /**
     * Returns the large integer for the specified character sequence stated
     * in the specified radix. The characters must all be digits of the
     * specified radix, except the first character which may be a plus sign
     * <code>'+'</code> or a minus sign <code>'-'</code>.
     * 
     * @param chars the character sequence to parse.
     * @param radix the radix to be used while parsing.
     * @return the corresponding large integer.
     * @throws NumberFormatException if the specified character sequence does
     *         not contain a parsable large integer.
     */
    public static LargeInteger valueOf(CharSequence chars, int radix) {
        try {
            final int charsLength = chars.length();
            final boolean isNegative = (chars.charAt(0) == '-') ? true : false;
            int i = (isNegative || (chars.charAt(0) == '+')) ? 1 : 0;

            // Ensures capacity large enough.
            // Bits per character: log2(radix) between 1 and 6 (radix 2 to 36)
            // Most often around 4 (radix 10, 16).
            // Use maximum value of 6 with a division by 64 instead of 63.
            // Adds extra word for potential carry in radix multiplication.
            LargeInteger z = newInstance(((charsLength * 6) >> 6) + 2);

            // z = digit
            z._isNegative = isNegative;
            z._size = chars.charAt(i) == '0' ? 0 : 1;
            z._words[0] = Character.digit(chars.charAt(i), radix);
            LargeInteger digit = LargeInteger.valueOf(0xFF);
            while (++i < charsLength) {
                // z *= radix
                z._size = multiply(z._words, z._size, radix, z._words, 0);
                // z += digit
                digit._words[0] = Character.digit(chars.charAt(i), radix);
                if (z._size > 0) {
                    z._size = add(z._words, z._size, digit._words, 1, z._words);
                } else {
                    z._size = add(digit._words, 1, z._words, 0, z._words);
                }
            }
            digit.recycle();
            return z;
        } catch (IndexOutOfBoundsException e) {
            throw new NumberFormatException("For input characters: \""
                    + chars.toString() + "\"");
        }
    }

    /**
     * XML factory method.
     * 
     * @param  xml the XML element describing the integer to return 
     *        (e.g. <code>&lt;math:Integer value="0"/&gt;</code>).
     * @return a new integer number as described by the specified xml element.
     * @see    #valueOf(CharSequence)
     */
    public static LargeInteger valueOf(XmlElement xml) {
        CharSequence chars = xml.getAttribute("value");
        return valueOf(chars);
    }

    /**
     * Indicates if this large integer is greater than {@link #ZERO}
     * ({@link #ZERO}is not included).
     * 
     * @return <code>this > ZERO</code>
     */
    public boolean isPositive() {
        return !_isNegative && (_size != 0);
    }

    /**
     * Indicates if this large integer is less than {@link #ZERO}.
     * 
     * @return <code>this < ZERO</code>
     */
    public boolean isNegative() {
        return _isNegative;
    }

    /**
     * Indicates if this large integer is equal to {@link #ZERO}.
     * 
     * @return <code>this == ZERO</code>
     */
    public boolean isZero() {
        return _size == 0;
    }

    /**
     * Returns the final undivided part after division that is less or of 
     * lower degree than the divisor. This value is only set by the 
     * {@link #divide} operation and is not considered as part of 
     * this large integer (ignored by all methods).
     * 
     * @return the remainder of the division for which this large integer
     *         is the quotient.
     */
    public LargeInteger getRemainder() {
        return _remainder;
    }

    /**
     * Indicates if this large integer is larger than the one
     * specified in absolute value.
     * 
     * @param that the integer to be compared with.
     * @return <code>this.abs().compareTo(that.abs()) > 0</code>.
     */
    public boolean isLargerThan(LargeInteger that) {
        return (this._size > that._size)
                || ((this._size == that._size) && compare(this._words,
                        that._words, this._size) > 0);
    }

    /**
     * Returns the two's-complement binary representation of this 
     * large integer. The output array is in <i>big-endian</i>
     * byte-order: the most significant byte is at the offset position.
     * 
     * <p>Note: This representation is consitent with <code>java.lang.BigInteger
     *          </code> byte array representation and can be used for conversion 
     *          between the two classes.</p>
     * 
     * @param  bytes the bytes to hold the binary representation 
     *         (two's-complement) of this large integer.
     * @param  offset the offset at which to start writing the bytes.
     * @return the number of bytes written.
     * @throws IndexOutOfBoundsException 
     *         if <code>bytes.length < (bitLength() >> 3) + 1</code>  
     * @see    #valueOf(byte[], int, int)
     * @see    #bitLength
     */
    public int toByteArray(byte[] bytes, int offset) {
        int bytesLength = (bitLength() >> 3) + 1;
        int wordIndex = 0;
        int bitIndex = 0;
        if (_isNegative) {
            long word = _words[0] - 1;
            long borrow = word >> 63; // -1 if borrow
            word = ~word & MASK_63;
            for (int i = bytesLength + offset; i > offset; bitIndex += 8) {
                if (bitIndex < 63 - 8) {
                    bytes[--i] = (byte) word;
                    word >>= 8;
                } else { // End of word reached.
                    byte bits = (byte) word;
                    word = (++wordIndex < _size)
                            ? _words[wordIndex] + borrow
                            : borrow;
                    borrow = word >> 63; // -1 if borrow
                    word = ~word & MASK_63;
                    bitIndex -= 63; // In range [-8..-1]
                    bytes[--i] = (byte) ((word << -bitIndex) | bits);
                    word >>= (8 + bitIndex);
                }
            }
        } else {
            if (_size != 0) {
                long word = _words[0];
                for (int i = bytesLength + offset; i > offset; bitIndex += 8) {
                    if (bitIndex < 63 - 8) {
                        bytes[--i] = (byte) word;
                        word >>= 8;
                    } else { // End of word reached.
                        byte bits = (byte) word;
                        word = (++wordIndex < _size) ? _words[wordIndex] : 0;
                        bitIndex -= 63; // In range [-8..-1]
                        bytes[--i] = (byte) ((word << -bitIndex) | bits);
                        word >>= (8 + bitIndex);
                    }
                }
            } else { // ZERO
                bytes[offset] = 0;
            }
        }
        return bytesLength;
    }

    /**
     * Returns the minimal number of bits to represent this large integer
     * in the minimal two's-complement (sign excluded).
     * 
     * @return the length of this integer in bits (sign excluded).
     */
    public int bitLength() {
        if (_size != 0) {
            int bitLength = 0;
            long word = _words[_size - 1];
            if (word >= 1L << 32) {
                word >>= 32;
                bitLength += 32;
            }
            if (word >= 1L << 16) {
                word >>= 16;
                bitLength += 16;
            }
            if (word >= 1L << 8) {
                word >>= 8;
                bitLength += 8;
            }
            if (word >= 1L << 4) {
                word >>= 4;
                bitLength += 4;
            }
            bitLength += BIT_LENGTH[(int) word]; // word is now 4 bits long.
            if (_isNegative) { // Correct for exact power of 2 (one less bit).
                int i = _size - 1;
                // _words[i] is always different from 0 and bitLength >= 1
                boolean isPow2 = (_words[i] == (1L << (bitLength - 1)));
                while (isPow2 && (i > 0)) {
                    isPow2 = _words[--i] == 0L;
                }
                if (isPow2) {
                    bitLength--;
                }
            }
            return bitLength + (_size - 1) * 63;
        } else {
            return 0;
        }
    }

    private static final int BIT_LENGTH[] = new int[]{0, 1, 2, 2, 3, 3, 3, 3,
        4, 4, 4, 4, 4, 4, 4, 4};

    /**
     * Returns the negation of this large integer.
     * 
     * @return <code>-this</code>.
     */
    public LargeInteger negate() {
        LargeInteger z = copy();
        z._isNegative = (!_isNegative) && (_size != 0); // -0 = 0
        return z;
    }

    /**
     * Returns the sum of this large integer with the one specified.
     * 
     * @param that the integer to be added.
     * @return <code>this + that</code>.
     */
    public LargeInteger add(LargeInteger that) {
        if (this._isNegative == that._isNegative) {
            if (this._size >= that._size) {
                LargeInteger z = newInstance(this._size + 1);
                z._size = add(this._words, this._size, that._words, that._size,
                        z._words);
                z._isNegative = _isNegative;
                return z;
            } else {
                LargeInteger z = newInstance(that._size + 1);
                z._size = add(that._words, that._size, this._words, this._size,
                        z._words);
                z._isNegative = _isNegative;
                return z;
            }
        } else { // Different signs, equivalent to subtraction.
            // Subtracts smallest to largest (absolute value)
            if (this.isLargerThan(that)) { // this.abs() > that.abs()
                LargeInteger z = newInstance(this._size);
                z._size = subtract(this._words, this._size, that._words,
                        that._size, z._words);
                z._isNegative = this._isNegative;
                return z;
            } else { // that.abs() >= this.abs()
                LargeInteger z = newInstance(that._size);
                z._size = subtract(that._words, that._size, this._words,
                        this._size, z._words);
                z._isNegative = that._isNegative && (z._size != 0);
                return z;
            }
        }
    }

    /**
     * Returns the difference between this large integer and the one
     * specified.
     * 
     * @param that the integer to be subtracted.
     * @return <code>this - that</code>.
     */
    public LargeInteger subtract(LargeInteger that) {
        if (this._isNegative == that._isNegative) {
            // Subtracts smallest to largest (absolute value)
            if (this.isLargerThan(that)) { // this.abs() > that.abs()
                LargeInteger z = newInstance(this._size);
                z._size = subtract(this._words, this._size, that._words,
                        that._size, z._words);
                z._isNegative = this._isNegative;
                return z;
            } else { // that.abs() >= this.abs()
                LargeInteger z = newInstance(that._size);
                z._size = subtract(that._words, that._size, this._words,
                        this._size, z._words);
                z._isNegative = !that._isNegative && (z._size != 0);
                return z;
            }
        } else { // Different signs, equivalent to addition.
            if (this._size >= that._size) {
                LargeInteger z = newInstance(this._size + 1);
                z._size = add(this._words, this._size, that._words, that._size,
                        z._words);
                z._isNegative = _isNegative;
                return z;
            } else {
                LargeInteger z = newInstance(that._size + 1);
                z._size = add(that._words, that._size, this._words, this._size,
                        z._words);
                z._isNegative = _isNegative;
                return z;
            }
        }
    }

    /**
     * Returns the product of this large integer with the specified 
     * <code>long</code>.
     * 
     * @param l the <code>long</code> multiplier.
     * @return <code>this * l</code>.
     */
    public LargeInteger multiply(long l) {
        if (this._size != 0) {
            if (l > 0) {
                LargeInteger z = newInstance(_size + 1);
                z._size = multiply(_words, _size, l, z._words, 0);
                z._isNegative = _isNegative;
                return z;
            } else if (l == Long.MIN_VALUE) { // Avoids -l overflow.
                LargeInteger z = this.shiftLeft(63);
                z._isNegative = !_isNegative;
                return z;
            } else if (l < 0) {
                LargeInteger z = newInstance(_size + 1);
                z._size = multiply(_words, _size, -l, z._words, 0);
                z._isNegative = !_isNegative;
                return z;
            }
        }
        return ZERO;
    }

    /**
     * Returns the product of this large integer with the one specified.
     * 
     * @param that the large integer multiplier.
     * @return <code>this * that</code>.
     */
    public LargeInteger multiply(LargeInteger that) {
        if (that.bitLength() <= 63) {
            return multiply(that.longValue());
        } else if ((this._size != 0) && (that._size != 0)) {
            LargeInteger z = newInstance(this._size + that._size);
            z._size = (this._size >= that._size) ? multiply(this._words,
                    this._size, that._words, that._size, z._words) : multiply(
                    that._words, that._size, this._words, this._size, z._words);
            z._isNegative = this._isNegative != that._isNegative;
            return z;
        } else {
            return ZERO;
        }
    }

    /**
     * Returns this large integer divided by the specified <code>int</code>.
     * The remainder of this division is accessible using {@link #getRemainder}. 
     * 
     * @param i the <code>int</code> divisor.
     * @return <code>this / i</code> and <code>this % i</code>
     *        ({@link #getRemainder})
     * @throws ArithmeticException if <code>i == 0</code>
     */
    public LargeInteger divide(int i) {
        if (i != 0) {
            if (this._size != 0) {
                if (i > 0) {
                    LargeInteger z = newInstance(_size);
                    long rem = divide(_words, _size, i, z._words);
                    z._size = (z._words[_size - 1] == 0L) ? _size - 1 : _size;
                    z._isNegative = _isNegative && (z._size != 0);
                    z._remainder = valueOf(_isNegative ? -rem : rem);
                    return z;
                } else if (i == Integer.MIN_VALUE) { // Negative would overflow.
                    LargeInteger z = this.abs().shiftRight(31);
                    z._isNegative = !_isNegative && (z._size != 0);
                    z._remainder = _isNegative ? valueOf(
                            -(_words[0] & MASK_31)) : valueOf(_words[0]
                            & MASK_31);
                    return z;
                } else { // i < 0
                    LargeInteger z = this.divide( -i);
                    z._isNegative = !_isNegative && (z._size != 0);
                    return z;
                }
            } else { // Zero. 
                LargeInteger zero = valueOf(0);
                zero._remainder = ZERO;
                return zero;
            }
        } else {
            throw new ArithmeticException("Division by zero");
        }
    }

    /**
     * Returns this large integer divided by the one specified (integer
     * division). This operation is independant from the current modulo (unlike
     * {@link #reciprocal}).
     * The remainder of this division is accessible using {@link #getRemainder}. 
     * 
     * @param that the integer divisor.
     * @return <code>this / that</code> and <code>this % that</code> 
     *        ({@link #getRemainder})
     * @throws ArithmeticException if <code>that.equals(ZERO)</code>
     */
    public LargeInteger divide(LargeInteger that) {
        if (that.bitLength() <= 1) {
            return divide(that.intValue());
        } else if (that._size != 0) {
            // Adapted from "Fast Multiplication & Division of Very Large Numbers",
            // by Uwe Hollerbach, post to sci.math.research, Jan 1996, archived at 
            // Swarthmore, http://forum.swarthmore.edu/epigone/sci.math.research/zhouyimpzimp/x1ybdbxz5w4v@forum.swarthmore.edu
            LargeInteger q = LargeInteger.ONE;
            int e = 0;
            PoolContext.enter();
            try {
                LargeInteger n = this.abs();
                LargeInteger d = that.abs();
                e = d.bitLength();
                int ag = 1;
                int ar = 31 + n.bitLength() - d.bitLength();
                while (true) {
                    // Many optimizations possible here (todo)
                    LargeInteger tmp = d.multiply(q.multiply(q));
                    q = q.shiftLeft(e + 1).subtract(tmp);
                    e *= 2;
                    ag *= 2;
                    int qsh = q.bitLength() - 1 - (4 + ag);
                    if (qsh > 0) {
                        q = q.shiftRight(qsh);
                        e -= qsh;
                    }
                    if (ag > ar) {
                        q = n.multiply(q);
                        break;
                    }
                }
                q = q.shiftRight(e);

                // Calculates remainder.
                LargeInteger rem = n.subtract(q.multiply(d)); // Positive.
                // Result can be off by one, check the remainder and adjusts.
                if (rem.compareTo(d) >= 0) {
                    rem = rem.subtract(d);
                    q = q.add(ONE);
                }
                rem._isNegative = _isNegative && (rem._size != 0);
                q._isNegative = (this._isNegative != that._isNegative)
                        && (q._size != 0);
                q._remainder = (LargeInteger) rem.export();
                return (LargeInteger) q.export();
            } finally {
                PoolContext.exit();
            }
        } else {
            throw new ArithmeticException("Division by zero");
        }
    }

    /**
     * Returns the greatest common divisor of this large integer and 
     * the one specified.
     * 
     * @param  that the other number to compute the GCD with.
     * @return a positive number or {@link #ZERO} if
     *         <code>(this.isZero() && that.isZero())</code>.
     */
    public LargeInteger gcd(LargeInteger that) {
        // To optimize using binary algorithm 
        // http://www.cut-the-knot.org/blue/binary.shtml
        LargeInteger a = this.abs();
        LargeInteger b = that.abs();
        while (!b.isZero()) {
            LargeInteger tmp = a.divide(b);
            LargeInteger c = tmp.getRemainder();
            tmp.recycle();
            a.recycle();
            a = b;
            b = c;
        }
        return a;
    }

    /**
     * Returns the absolute value of this large integer.
     * 
     * @return <code>abs(this)</code>.
     */
    public LargeInteger abs() {
        return (isPositive() || isZero()) ? this : this.negate();
    }

    /**
     * Returns the value of this large integer after performing a binary
     * shift to left.
     * 
     * @param n the shift distance, in bits.
     * @return <code>this &lt;&lt; n</code>.
     * @throws IllegalArgumentException if <code>n &lt; 0</code>
     */
    public LargeInteger shiftLeft(int n) {
        if (n >= 0) {
            if (_size != 0) {
                final int wordShift = n < 63 ? 0 : n / 63;
                final int bitShift = n - wordShift * 63;
                LargeInteger z = newInstance(_size + wordShift + 1);
                z._isNegative = _isNegative;
                z._size = shiftLeft(wordShift, bitShift, _words, _size,
                        z._words);
                return z;
            } else { // ZERO << n == ZERO
                return this;
            }
        } else {
            throw new IllegalArgumentException("n: " + n
                    + ", negative shift values not allowed.");
        }
    }

    /**
     * Returns the value of this large integerafter performing a binary
     * shift to right with sign extension <code>(-1 >> 1 == -1)</code>.
     * 
     * @param n the shift distance, in bits.
     * @return <code>this &gt;&gt; n</code>.
     * @throws IllegalArgumentException if <code>n &lt; 0</code>
     */
    public LargeInteger shiftRight(int n) {
        if (n >= 0) {
            final int wordShift = n < 63 ? 0 : n / 63;
            final int bitShift = n - wordShift * 63;
            if (_size > wordShift) {
                LargeInteger z = newInstance(_size - wordShift);
                z._size = shiftRight(wordShift, bitShift, _words, _size,
                        z._words);
                z._isNegative = _isNegative;
                if (_isNegative) { // Adjust, two's-complement is being shifted.
                    int i = wordShift;
                    boolean bitsLost = (bitShift != 0)
                            && (_words[i] << (64 - bitShift)) != 0;
                    while ((!bitsLost) && --i >= 0) {
                        bitsLost = _words[i--] != 0;
                    }
                    if (bitsLost) { // Adds ONE to result.
                        if (z._size > 0) {
                            z._size = add(z._words, z._size, ONE._words, 1,
                                    z._words);
                        } else {
                            z._size = add(ONE._words, 1, z._words, 0, z._words);
                        }
                    }
                }
                return z;
            } else { // All bits have been shifted.
                return _isNegative ? valueOf( -1) : valueOf(0);
            }
        } else {
            throw new IllegalArgumentException("n: " + n
                    + ", negative shift values not allowed.");
        }
    }

    /**
     * Appends the text representation of this large integer in
     * the specified radix to the <code>StringBuffer</code> argument.
     *
     * @param sb the <code>StringBuffer</code> to append.
     * @param radix the radix of the representation.
     * @return the specified <code>StringBuffer</code>.
     */
    public StringBuffer appendTo(StringBuffer sb, int radix) {
        if (this.isZero()) {
            return sb.append('0');
        } else if (this.isNegative()) {
            sb.append('-');
        }
        PoolContext.enter();
        try {
            int tmpSize = (radix < 8)
                    ? this.bitLength()
                    : (this.bitLength() / 3) + 1;
            ObjectPool tmpPool = ArrayPool.byteArray(tmpSize);
            byte[] tmp = (byte[]) tmpPool.next();
            int tmpIndex = 0;
            LargeInteger x = this.abs();
            while (!x.isZero()) {
                LargeInteger i = x.divide(radix);
                LargeInteger j = i.multiply(radix);
                LargeInteger k = x.subtract(j);
                tmp[tmpIndex++] = k.byteValue();
                // Recycles temporary objects.
                k.recycle();
                j.recycle();
                x.recycle();
                x = i;
            }
            for (int i = tmpIndex; i > 0; ) {
                sb.append((Character.forDigit(tmp[--i], radix)));
            }
            tmpPool.recycle(tmp);
        } finally {
            PoolContext.exit();
        }
        return sb;
    }

    /**
     * Returns the decimal text representation of this large integer.
     *
     * @return the text representation of this integer number.
     */
    public String toString() {
        return appendTo(new StringBuffer((bitLength() / 3) + 1), 10).toString();
    }

    /**
     * Returns the text representation of this large integer in
     * the specified radix.
     *
     * @param radix the radix of the representation.
     * @return the text representation of this integer number.
     */
    public String toString(int radix) {
        return appendTo(new StringBuffer(), radix).toString();
    }

    /**
     * Compares this large integer against the specified object.
     * 
     * @param that the object to compare with.
     * @return <code>true</code> if the objects are the same; <code>false</code>
     *         otherwise.
     */
    public boolean equals(Object that) {
        if (that instanceof LargeInteger) {
            LargeInteger x = (LargeInteger) that;
            return (_size == x._size) && (_isNegative == x._isNegative)
                    && (compare(_words, x._words, _size) == 0);
        } else {
            return false;
        }
    }

    /**
     * Returns the hash code for this large integer number.
     * 
     * @return the hash code value.
     */
    public int hashCode() {
        long code = 0;
        for (int i = _size - 1; i >= 0; i--) {
            code = code * 31 + _words[i];
        }
        return _isNegative ? -(int) code : (int) code;
    }

    /**
     * Returns the low order bits of this large integer as 
     * an <code>int</code>.
     * 
     * <p>Note: This conversion can lose information about the overall magnitude
     *          of the integer value and may return a result with the opposite 
     *          sign.</p>
     * 
     * @return the numeric value represented by this integer after conversion
     *         to type <code>int</code>.
     */
    public int intValue() {
        return (int) longValue();
    }

    /**
     * Returns the low order bits of this large integer as 
     * a <code>long</code>.
     * 
     * <p>Note: This conversion can lose information about the overall magnitude
     *          of the integer value and may return a result with the opposite 
     *          sign.</p>
     * 
     * @return the numeric value represented by this integer after conversion
     *         to type <code>long</code>.
     */
    public long longValue() {
        if (_size == 0) {
            return 0;
        } else if (_size == 1) {
            return _isNegative ? -_words[0] : _words[0];
        } else {
            return _isNegative
                    ? -((_words[1] << 63) | _words[0])
                    : (_words[1] << 63) | _words[0];
        }
    }

    /**
     * Returns the value of this large integer as a <code>float</code>.
     * 
     * @return the numeric value represented by this integer after conversion
     *         to type <code>float</code>.
     */
    public float floatValue() {
        return (float) doubleValue();
    }

    /**
     * Returns the value of this large integeras a <code>double</code>.
     * 
     * @return the numeric value represented by this integer after conversion
     *         to type <code>double</code>.
     */
    public double doubleValue() {
        if (_size == 0) {
            return 0.0;
        } else if (_size == 1) {
            return _isNegative ? -_words[0] : _words[0];
        } else { // size >= 2
            double absValue = ((_words[_size - 1] * TWO_POW63) + _words[_size
                    - 2]) * Math
                    .pow(TWO_POW63, _size - 2);
            return _isNegative ? -absValue : absValue;
        }
    }

    private static final double TWO_POW63 = 9223372036854775808.0;

    /**
     * Compares two large integer numerically.
     * 
     * @param  that the integer to compare with.
     * @return -1, 0 or 1 as this integer is numerically less than, equal to,
     *         or greater than <code>that</code>.
     * @throws ClassCastException <code>that</code> is not a 
     *         large integer.
     */
    public int compareTo(Object that) {
        LargeInteger x = (LargeInteger) that;
        // Compares sign.
        if (_isNegative && !x._isNegative) {
            return -1;
        } else if (!_isNegative && x._isNegative) {
            return 1;
        } else { // Same sign.
            // Compares size.
            if (_size > x._size) {
                return _isNegative ? -1 : 1;
            } else if (x._size > _size) {
                return _isNegative ? 1 : -1;
            } else { // Same size.
                return _isNegative
                        ? compare(x._words, _words, _size)
                        : compare(_words, x._words, _size);
            }
        }
    }

    /**
     * Returns a copy of this large integer allocated in the current context.
     *
     * @return a copy of this large integer. 
     */
    private LargeInteger copy() {
        LargeInteger x = newInstance(_size);
        x._isNegative = _isNegative;
        x._size = _size;
        if (_size < 32) {
            for (int i = _size; i > 0; ) {
                x._words[--i] = _words[i];
            }
            return x;
        } else { // Use system copy for large arrays.
            System.arraycopy(_words, 0, x._words, 0, _size);
            return x;
        }
    }

    /**
     * Sets the current modulus context for modular arithmetic (used by
     * {@link Operable} operations only).
     * 
     * @param modulo the new modulus context.
     * @see com.dautelle.realtime.LocalContext
     * @see #plus
     * @see #opposite
     * @see #times
     * @see #reciprocal
     */
    public static void setModulus(LargeInteger modulo) {
        throw new UnsupportedOperationException(
                "MODULAR ARITHMETIC NOT IMPLEMENTED YET");
    }

    // Implements Operable.
    public Operable plus(Operable that) {
        throw new UnsupportedOperationException(
                "MODULAR ARITHMETIC NOT IMPLEMENTED YET");
    }

    // Implements Operable.
    public Operable opposite() {
        throw new UnsupportedOperationException(
                "MODULAR ARITHMETIC NOT IMPLEMENTED YET");
    }

    // Implements Operable.
    public Operable times(Operable that) {
        throw new UnsupportedOperationException(
                "MODULAR ARITHMETIC NOT IMPLEMENTED YET");
    }

    // Implements Operable.
    public Operable reciprocal() {
        throw new UnsupportedOperationException(
                "MODULAR ARITHMETIC NOT IMPLEMENTED YET");
    }

    // Implements Representable.
    public void toXml(XmlElement xml) {
        appendTo(xml.newAttribute("value"), 10);
    }

    ///////////////
    // Utilities //
    ///////////////
    private static final long MASK_63 = 0x7FFFFFFFFFFFFFFFL;

    private static final long MASK_32 = 0xFFFFFFFFL;

    private static final long MASK_31 = 0x7FFFFFFFL;

    private static final long MASK_8 = 0xFFL;

    // Preconditions: xSize >= ySize
    private static int add(long[] x, int xSize, long[] y, int ySize, long[] z) {
        long sum = 0;
        int i = 0;
        while (i < ySize) {
            sum += x[i] + y[i];
            z[i++] = sum & MASK_63;
            sum >>>= 63;
        }
        while ((sum != 0) && (i < xSize)) {
            sum += x[i];
            z[i++] = sum & MASK_63;
            sum >>>= 63;
        }
        if (sum == 0) {
            while (i < xSize) {
                z[i] = x[i++];
            }
            return i;
        } else { // i >= xSize
            z[i++] = sum;
            return i;
        }
    }

    // Preconditions: x >= y.
    private static int subtract(long[] x, int xSize, long[] y, int ySize,
            long[] z) {
        long diff = 0;
        int i = 0;
        while (i < ySize) {
            diff += x[i] - y[i];
            z[i++] = diff & MASK_63;
            diff >>= 63; // Equals to -1 if borrow.
        }
        while (diff != 0) {
            diff += x[i];
            z[i++] = diff & MASK_63;
            diff >>= 63; // Equals to -1 if borrow.
        }
        while (i < xSize) {
            z[i] = x[i++];
        }
        // Calculates size.
        while ((--i >= 0) && (z[i] == 0)) {}
        return i + 1;
    }

    private static int compare(long[] left, long[] right, int size) {
        for (int i = size - 1; i >= 0; i--) {
            if (left[i] > right[i]) {
                return 1;
            } else if (left[i] < right[i]) {
                return -1;
            }
        }
        return 0;
    }

    // Preconditions: size > 0
    private static int shiftLeft(int wordShift, int bitShift, long[] words,
            int size, long[] z) {
        final int shiftRight = 63 - bitShift;
        int i = size;
        int j = size + wordShift;
        long tmp = words[--i];
        z[j--] = tmp >>> shiftRight;
        while (i > 0) {
            z[j--] = ((tmp << bitShift) & MASK_63)
                    | ((tmp = words[--i]) >>> shiftRight);
        }
        z[j] = (tmp << bitShift) & MASK_63;
        while (j > 0) {
            z[--j] = 0;
        }
        return (z[size + wordShift] != 0) ? size + wordShift + 1 : size
                + wordShift;
    }

    // Preconditions: size > wordShift 
    private static int shiftRight(int wordShift, int bitShift, long[] words,
            int size, long[] z) {
        final int shiftLeft = 63 - bitShift;
        int i = wordShift;
        int j = 0;
        long tmp = words[i];
        while (i < size - 1) {
            z[j++] = (tmp >>> bitShift) | ((tmp = words[++i]) << shiftLeft)
                    & MASK_63;
        }
        tmp >>>= bitShift;
        z[j] = tmp;
        return (tmp != 0) ? j + 1 : j;
    }

    // Precondition: xSize >= ySize
    private static int multiply(long[] x, int xSize, long[] y, int ySize,
            long[] z) {
        if (ySize != 0) {
            // Calculates z = x * y[0];
            int zSize = multiply(x, xSize, y[0], z, 0);

            // Increment z with shifted products.
            for (int i = 1; i < ySize; ) {
                zSize = multiply(x, xSize, y[i], z, i++);
            }
            return zSize;
        }
        return 0; // x * ZERO = ZERO
    }

    // Preconditions: size > 0, z.length > size + shift, k >= 0
    private static int multiply(long[] words, int size, long k, long[] z,
            int shift) {
        long carry = 0; // 63 bits
        long kl = k & MASK_32; // 32 bits.
        long kh = k >> 32; // 31 bits
        for (int i = 0, j = shift; i < size; ) {
            long w = words[i++];
            long wl = w & MASK_32; // 32 bits
            long wh = w >> 32; // 31 bits
            // Lower product.
            long tmp = wl * kl; // 64 bits
            long low = (tmp & MASK_63) + carry;
            carry = (tmp >>> 63) + (low >>> 63);

            // Cross product.
            tmp = wl * kh + wh * kl; // 64 bits
            low = (low & MASK_63) + ((tmp << 32) & MASK_63);

            // Calculates new carry  
            carry += ((wh * kh) << 1 | (low >>> 63)) + (tmp >>> 31);

            if (shift != 0) { // Adds to z.
                low = z[j] + (low & MASK_63);
                z[j++] = low & MASK_63;
                carry += low >>> 63;
            } else { // Sets z.
                z[j++] = low & MASK_63;
            }
        }
        z[shift + size] = carry;
        return (carry != 0) ? shift + size + 1 : shift + size;
    }

    // Precondition: y length <= 32 bits.
    // Returns remainder.
    private static long divide(long[] x, int xSize, long y, long[] z) {
        long r = 0;
        for (int i = xSize; i > 0; ) {
            long w = x[--i];

            long wh = (r << 31) | (w >>> 32);
            long qh = wh / y;
            r = wh - qh * y;

            long wl = (r << 32) | (w & MASK_32);
            long ql = wl / y;
            r = wl - ql * y;

            z[i] = (qh << 32) | ql;
        }
        return r;
    }

    //////////////
    // Realtime //
    //////////////
    // Static factory method.
    private static LargeInteger newInstance(int wordsLength) {
        if (wordsLength <= INTRINSIC_WORDS_SIZE) {
            return (LargeInteger) FACTORY_INTRINSIC_WORDS.object();
        } else {
            LargeInteger x = (LargeInteger) FACTORY_EXTERNAL_WORDS.object();
            x._words = (long[]) ArrayPool.longArray(wordsLength).next();
            return x;
        }
    }

    // Overrides.
    public Object export() {
        if (isLocalObject()) {
            super.export();
            if (_words.length > INTRINSIC_WORDS_SIZE) { // External being used.
                _words = (long[]) ArrayPool.outerCopy(_words, 0, _size);
            }
        } // Else non-local objects cannot refer to local object.
        return this;
    }

    // Overrides.
    public Object toHeap() {
        if (isPoolObject()) {
            super.toHeap();
            if (_words.length > INTRINSIC_WORDS_SIZE) { // External being used.
                _words = (long[]) ArrayPool.heapCopy(_words, 0, _size);
            }
        } // Else heap object cannot refer to pool objects.
        return this;
    }

}