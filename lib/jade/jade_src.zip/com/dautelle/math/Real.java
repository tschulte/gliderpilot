/*
 * J.A.D.E. Java(TM) Addition to Default Environment. Latest release available
 * at http://jade.dautelle.com/ Copyright (C) 2004 Jean-Marie Dautelle.
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation (http://www.gnu.org/copyleft/lesser.html); either
 * version 2.1 of the License, or any later version.
 */
package com.dautelle.math;

import com.dautelle.xml.Representable;
import com.dautelle.xml.XmlElement;

/**
 * <p> This class represents a real number of arbitrary precision
 *     <b>(WORK IN PROGRESS)</b>.<p>
 * 
 * <p> The class resembles <code>java.lang.BigDecimal</code> but 
 *     "scale manipulation" is unnecessary as the internal scale 
 *     is automatically derived from the actual precision.<p>
 *  
 * <p> The current precision of any {@link Real} instance is <b>accessible</b>
 *     (see {@link #getAbsoluteError}, {@link #getRelativeError}) and  
 *     <b>guaranteed</b> (the true/exact value is always within the precision 
 *     range)!</p>
 * 
 * <p> Operations on instances of this class are quite fast   
 *     as information substantially below the precision level (aka noise)
 *     is not processed/stored. There is no limit on a {@link Real} precision
 *     but precision degenerates (due to numeric errors) as more and more
 *     operations are performed.</p>
 * 
 * <p> Instances of this class can be utilized to find approximate 
 *     solutions to linear equations using the {@link Matrix} class for which
 *     high-precision reals is often required, the primitive type
 *     <code>double</code> being not accurate enough to resolve equations 
 *     when the matrix's size exceeds 100x100. Furthermore, even for small 
 *     matrices the "qualified" result is indicative of possible system 
 *     singularities.</p>
 * 
 * @author <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, February 1, 2004
 */
public final class Real extends RealtimeNumber implements Comparable, Operable,
        Representable {

    /**
     * Holds the factory constructing rational instances.
     */
    private static final Factory FACTORY = new Factory() {

        public Object create() {
            return new Real();
        }
    };

    /**
     * A {@link Real} representing the additive identity.
     */
    public static final Real ZERO = (Real) valueOf(LargeInteger.ZERO,
            LargeInteger.ZERO, 0).toHeap();

    /**
     * A {@link Real} for which the interval of possible values is unknown.
     */
    public static final Real UNKNOWN = (Real) valueOf(LargeInteger.ZERO,
            LargeInteger.ZERO, Short.MAX_VALUE).toHeap();

    ///**
    // * The maximum number of bits in error being tolerated.
    // */
    //private final static int MAX_BITS_IN_ERROR = 16;

    /**
     * The mantissa  value.
     */
    private LargeInteger _mantissa;

    /**
     * The mantissa current error.
     */
    private LargeInteger _error;

    /**
     * The log base 2 of the scale multiplier for both mantissa and error
     * (range ]Short.MIN_VALUE .. Short.MAX_VALUE]).
     * Note: This number is a multiplier of ERROR_BITS  as scaling is always
     *      performed based upon the current error.
     */
    private int _log2Scale;

    /**
     * Default constructor.
     */
    private Real() {
    }

    /**
     * Constructs a {@link Real} from the specified mantissa, error and scale
     * (<code>(mantissa ± error) * 2<sup>log2Scale</sup></code>).
     * 
     * @param mantissa the mantissa.
     * @param error the error on the mantissa.
     * @param log2Scale the log base 2 of the scale multiplier.
     */
    public static Real valueOf(LargeInteger mantissa, LargeInteger error,
            int log2Scale) {
        Real real = (Real) FACTORY.object();
        // Truncates some of the noise.
        //while (error.bitLength() > MAX_BITS_IN_ERROR) {
        //    mantissa = mantissa.shiftRight(MAX_BITS_IN_ERROR);
        //    real.error.shiftRight(MAX_BITS_IN_ERROR).add(LargeInteger.ONE);
        //    log2Scale += MAX_BITS_IN_ERROR;
        //}
        real._mantissa = mantissa;
        real._error = error;
        real._log2Scale = log2Scale;
        return real;
    }

    /**
     * Returns the {@link Real} for the specified character sequence.
     * If the precision is not specified (using the <code>±</code> symbol), 
     * the number of digits is characteristic of the precision.
     * Example of valid character sequences for <code>1.2 ± 0.001</code>:<ul>
     * <li>"1.200"</li>
     * <li>"1.2±0.001</li>
     * <li>"1200±1E-3</li></ul>
     * 
     * @param  chars the character sequence.
     * @return the corresponding real number.
     */
    public static Real valueOf(CharSequence chars) {
        throw new UnsupportedOperationException("NOT IMPLEMENTED YET");
    }

    /**
     * XML factory method.
     * 
     * @param xml the XML element describing the real to return
     *        (e.g. <code>&lt;math:Real value="1.23000"/&gt;</code>).
     * @return a new Real number as described by the specified xml element.
     * @see    #valueOf(CharSequence)
     */
    public static Real valueOf(XmlElement xml) {
        CharSequence chars = xml.getAttribute("value");
        return valueOf(chars);
    }

    /**
     * Indicates if this {@link Real} is greater than {@link #ZERO}.
     * 
     * @return <code>this > ZERO</code>
     */
    public boolean isPositive() {
        return _mantissa.isPositive();
    }

    /**
     * Indicates if this {@link Real} is less than {@link #ZERO}.
     * 
     * @return <code>this < ZERO</code>
     */
    public boolean isNegative() {
        return _mantissa.isNegative();
    }

    /**
     * Indicates if this {@link Real} is equal to {@link #ZERO}.
     * Zero reals are the only reals in existence with "exact" precision.
     * 
     * @return <code>true</code> if this real is zero (exact);
     *         <code>false</code> otherwise.
     */
    public boolean isZero() {
        return _mantissa.isZero() && !this.isUnknown();
    }

    /**
     * Indicates if this {@link Real} is unknown. Unknown reals are 
     * always different from any other reals or themselves.
     * 
     * @return <code>true</code> if this real possible values are unknown;
     *         <code>false</code> otherwise.
     * @see    #equals
     * @see    #approxEquals
     */
    public boolean isUnknown() {
        return this._log2Scale == Short.MAX_VALUE;
    }

    /**
     * Indicates if this {@link Real} is approximately equal to {@link #ZERO}.
     * 
     * @return <code>true</code> if this real is approximately zero;
     *         <code>false</code> otherwise.
     */
    public boolean isApproxZero() {
        return _mantissa.abs().compareTo(_error) <= 0;
    }

    /**
     * Indicates if this {@link Real} is approximately equals to the one 
     * specified. This method takes into account possible errors (e.g. numeric
     * errors) to make this determination. 
     * 
     * <p>Note: This method always returns <code>false</code> 
     *          if <code>this</code> or <code>that</code> is unknown.
     *
     * @param  that the real to compare with.
     * @return <code>this  &ape; that</code>
     * @see    #isUnknown
     */
    public boolean approxEquals(Real that) {
        return this.subtract(that).isApproxZero();
    }

    /**
     * Returns the value by which this {@link Real} may differ from
     * its exact value.
     *
     * @return the absolute error.
     */
    public double getAbsoluteError() {
        return _error.doubleValue() * Math.pow(2, _log2Scale);
    }

    /**
     * Returns the percentage by which this {@link Real} may differ
     * from its exact value.
     *
     * @return the relative error.
     */
    public double getRelativeError() {
        return _error.doubleValue() / _mantissa.doubleValue();
    }

    /**
     * Returns the closest {@link Integer} to this {@link Real}.
     * 
     * @return this real rounded to the nearest integer.
     */
    public LargeInteger round() {
        throw new UnsupportedOperationException("NOT IMPLEMENTED YET");
    }

    /**
     * Returns the negation of this {@link Real}.
     * 
     * @return <code>-this</code>.
     */
    public Real negate() {
        return valueOf(_mantissa.negate(), _error, _log2Scale);
    }

    /**
     * Returns the sum of this {@link Real} with the one specified.
     * 
     * @param that the real to be added.
     * @return <code>this + that</code>.
     */
    public Real add(Real that) {
        if (this._log2Scale == that._log2Scale) {
            LargeInteger mantissa = this._mantissa.add(that._mantissa);
            LargeInteger error = this._error.add(that._error);
            return valueOf(mantissa, error, _log2Scale);
        } else if (this._log2Scale < that._log2Scale) {
            return this.shiftRight(that._log2Scale - this._log2Scale).add(that);
        } else {
            return this.add(that.shiftRight(this._log2Scale - that._log2Scale));
        }
    }

    //  Internal shift, it does not change the value.
    private Real shiftRight(int n) {
        return valueOf(_mantissa.shiftRight(n), _error.shiftRight(n).add(
                LargeInteger.ONE), _log2Scale + n);
    }

    /**
     * Returns the difference between this {@link Real} and the one
     * specified.
     * 
     * @param that the real to be subtracted.
     * @return <code>this - that</code>.
     */
    public Real subtract(Real that) {
        return this.add(that.negate());
    }

    /**
     * Returns the product of this {@link Real} with the one specified.
     * 
     * @param that the real multiplier.
     * @return <code>this * that</code>.
     */
    public Real multiply(Real that) {
        LargeInteger mantissa = this._mantissa.multiply(that._mantissa);
        LargeInteger error = this._mantissa.abs().multiply(that._error).add(
                that._mantissa.abs().multiply(this._error)).add(
                this._error.multiply(that._error));
        int log2Scale = this._log2Scale + that._log2Scale;
        return valueOf(mantissa, error, log2Scale);
    }

    /**
     * Returns this {@link Real} divided by the one specified.
     * 
     * @param that the real divisor.
     * @return <code>this / that</code>.
     * @throws ArithmeticException if <code>that.equals(ZERO)</code>
     */
    public Real divide(Real that) {
        return this.multiply(that.inverse());
    }

    /**
     * Returns the inverse of this {@link Real}.
     *
     * @return <code>1 / this</code>.
     */
    public final Real inverse() {
        if (!isApproxZero()) {
            LargeInteger min = _mantissa.subtract(_error);
            LargeInteger max = _mantissa.add(_error);
            int shift = Math.max(min.bitLength(), max.bitLength());
            LargeInteger pow2 = LargeInteger.ONE.shiftLeft(shift * 2);
            LargeInteger invMin = pow2.divide(min);
            LargeInteger invMax = pow2.divide(max);
            LargeInteger mantissa = invMin.add(invMax);
            LargeInteger error = invMin.subtract(invMax).abs().add(
                    LargeInteger.ONE);
            int log2Scale = -_log2Scale + shift * 2;
            return valueOf(mantissa, error, log2Scale);
        } else {
            return UNKNOWN;
        }
    }

    /**
     * Returns the absolute value of this {@link Real}.
     * 
     * @return <code>abs(this)</code>.
     */
    public Real abs() {
        return _mantissa.isNegative() ? this.negate() : this;
    }

    /**
     * Appends the decimal text representation of this {@link Real} to the
     * <code>StringBuffer</code> argument.
     * 
     * @param sb the <code>StringBuffer</code> to append.
     * @return the specified <code>StringBuffer</code>.
     */
    public StringBuffer appendTo(StringBuffer sb) {
        throw new UnsupportedOperationException("NOT IMPLEMENTED YET");
    }

    /**
     * Returns the decimal text representation of this {@link Real}.
     * 
     * @return the text representation of this Real number.
     */
    public String toString() {
        return appendTo(new StringBuffer()).toString();
    }

    /**
     * Compares this {@link Real} against the specified object.
     * 
     * <p>Note: This method always returns <code>false</code> 
     *          if <code>this</code> or <code>that</code> is unknown.
     * 
     * @param that the object to compare with.
     * @return <code>true</code> if the objects are the same;
     *         <code>false</code> otherwise.
     * @see    #isUnknown
     */
    public boolean equals(Object that) {
        if (that instanceof Real) {
            Real thatReal = (Real) that;
            return this._error.equals(thatReal._error)
                    && this._mantissa.equals(thatReal._mantissa)
                    && (this._log2Scale == thatReal._log2Scale)
                    && !this.isUnknown();
        } else {
            return false;
        }
    }

    /**
     * Returns the hash code for this {@link Real} number.
     * 
     * @return the hash code value.
     */
    public int hashCode() {
        return _mantissa.hashCode();
    }

    /**
     * Returns the value of this {@link Real} as an <code>int</code>.
     * 
     * @return the numeric value represented by this real after conversion
     *         to type <code>int</code>.
     */
    public int intValue() {
        return (int) doubleValue();
    }

    /**
     * Returns the value of this {@link Real} as a <code>long</code>.
     * 
     * @return the numeric value represented by this real after conversion
     *         to type <code>long</code>.
     */
    public long longValue() {
        return (long) doubleValue();
    }

    /**
     * Returns the value of this {@link Real} as a <code>float</code>.
     * 
     * @return the numeric value represented by this real after conversion
     *         to type <code>float</code>.
     */
    public float floatValue() {
        return (float) doubleValue();
    }

    /**
     * Returns the value of this {@link Real} as a <code>double</code>.
     * 
     * @return the numeric value represented by this real after conversion
     *         to type <code>double</code>.
     */
    public double doubleValue() {
        return _mantissa.doubleValue() * Math.pow(2, _log2Scale);
    }

    /**
     * Compares two {@link Real} numerically.
     * Comparing to {@link #UNKNOWN} always returns <code>0</code>.
     * 
     * @param that the real to compare with.
     * @return -1, 0 or 1 as this real is numerically less than, equal to,
     *         or greater than <code>that</code>.
     * @throws ClassCastException <code>that</code> is not a {@link Real}.
     */
    public int compareTo(Object that) {
        Real diff = this.subtract((Real) that);
        if (diff.isPositive()) {
            return 1;
        } else if (diff.isNegative()) {
            return -1;
        } else {
            return 0;
        }
    }

    // Implements Operable.
    public Operable plus(Operable that) {
        return this.add((Real) that);
    }

    // Implements Operable.
    public Operable opposite() {
        return this.negate();
    }

    // Implements Operable.
    public Operable times(Operable that) {
        return this.multiply((Real) that);
    }

    // Implements Operable.
    public Operable reciprocal() {
        return this.inverse();
    }

    // Implements Representable.
    public void toXml(XmlElement xml) {
        appendTo(xml.newAttribute("value"));
    }

    // Overrides export.
    public Object export() {
        super.export();
        _mantissa.export();
        _error.export();
        return this;
    }

    // Overrides export.
    public Object toHeap() {
        super.toHeap();
        _mantissa.toHeap();
        _error.toHeap();
        return this;
    }
}
