/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.physics.models;

import javax.units.Converter;
import javax.units.MultiplyConverter;
import javax.units.NonSI;
import javax.units.SI;

/**
 * This class represents the relativistic model.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.1, February 17, 2003
 */
public final class RelativisticModel extends PhysicalModel {

    /**
     * Holds the single instance of this class.
     */
    private final static RelativisticModel INSTANCE = new RelativisticModel();

    /**
     * Selects the relativistic model as the current model.
     */
    public static void select() {
        INSTANCE.setPhysicalDimensions();
        PhysicalModel.setCurrent(INSTANCE);
    }

    /**
     * Sets the dimensional units of the seven base quantities as follow:
     * <ul>
     * <li>{@link com.dautelle.physics.Length Length} : <code>"s"</code></li>
     * <li>{@link com.dautelle.physics.Mass Mass} : <code>"eV"</code></li>
     * <li>{@link com.dautelle.physics.Duration Duration} : <code>"s"</code></li>
     * <li>{@link com.dautelle.physics.ElectricCurrent ElectricCurrent} : <code>"A"</code></li>
     * <li>{@link com.dautelle.physics.Temperature Temperature} : <code>"K"</code></li>
     * <li>{@link com.dautelle.physics.AmountOfSubstance AmountOfSubstance} : <code>"mol"</code></li>
     * <li>{@link com.dautelle.physics.LuminousIntensity LuminousIntensity} : <code>"cd"</code></li>
     * </ul>
     *
     * @see     javax.units.BaseUnit#setDimension
     */
    protected final void setPhysicalDimensions() {

        // SPEED_OF_LIGHT (METER / SECOND) = 1
        SI.METER.setDimension(SI.SECOND, new MultiplyConverter(1 / c));

        // ENERGY = m²·kg/s² = kg·c²
        SI.KILOGRAM.setDimension(NonSI.ELECTRON_VOLT, new MultiplyConverter(c
                * c / ePlus));

        SI.SECOND.setDimension(SI.SECOND, Converter.IDENTITY);
        SI.KELVIN.setDimension(SI.KELVIN, Converter.IDENTITY);
        SI.AMPERE.setDimension(SI.AMPERE, Converter.IDENTITY);
        SI.MOLE.setDimension(SI.MOLE, Converter.IDENTITY);
        SI.CANDELA.setDimension(SI.CANDELA, Converter.IDENTITY);
    }
}