/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml.sax;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderAdapter;

/**
 * <p> This class represents the JAXP factory class for creating SAX parsers.
 *     This factory creates an instance of {@link XMLReaderImpl}.</p>
 * <p> <b>SAX Plug-In Installation:</b>
 *     <p>
 *     In order to automatically use this library's {@link XMLReaderImpl}
 *     at run-time, you may either:
 *     <ul>
 *     <li> Set the <code>javax.xml.parsers.SAXParserFactory</code> system
 *          property to <code>com.dautelle.xml.sax.SAXParserFactoryImpl</code>
 *          (usually done in the <code>$JAVA_HOME/jre/lib/jaxp.properties
 *          </code> file).</li>
 *     <li> Place the <code>jade.jar</code> in the classpath before any other
 *          JAXP library.</li>
 *     <li> Place the <code>jade.jar</code> in the <code>$JAVA_HOME/jre/lib/ext/
 *          </code> directory (if no other JAXP library present).</li>
 *     </ul></p></p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.5, May 26, 2003
 */
public final class SAXParserFactoryImpl extends SAXParserFactory {

    /**
     * Default constructor.
     */
    public SAXParserFactoryImpl() {
        setNamespaceAware(true);
        setValidating(false);
    }

    /**
     * Creates a new instance of {@link XMLReaderImpl} using the currently
     * configured factory parameters.
     *
     * @return a new instance of {@link XMLReaderImpl}.
     * @throws ParserConfigurationException if {@link XMLReaderImpl} cannot
     *         satisfy the requested configuration.
     * @throws SAXException any SAX exception, possibly wrapping another
     *         exception.
     */
    public SAXParser newSAXParser() throws ParserConfigurationException,
                                           SAXException {
        if (isValidating()) {
            throw new ParserConfigurationException(
                "com.dautelle.xml.sax.XMLReaderImpl is non-validating");
        }
        if (!isNamespaceAware()) {
            throw new ParserConfigurationException(
                "com.dautelle.xml.sax.XMLReaderImpl parser is namespace-aware");
        }
        return new SAXParserImpl();
    }
    private static final class SAXParserImpl extends SAXParser {
        private final XMLReader _xmlReader = new XMLReaderImpl();
        // Implements abstract method, deprecated but necessary...
        public org.xml.sax.Parser getParser() throws SAXException {
            return new XMLReaderAdapter(_xmlReader);
        }
        public XMLReader getXMLReader() {
            return _xmlReader;
        }
        public boolean isNamespaceAware() {
            return true;
        }
        public boolean isValidating() {
            return false;
        }
        public Object getProperty(String name) throws SAXNotRecognizedException,
                                                      SAXNotSupportedException {
            return _xmlReader.getProperty(name);
        }
        public void setProperty(String name, Object value) throws
                SAXNotRecognizedException, SAXNotSupportedException {
            _xmlReader.setProperty(name, value);
        }
    }

    /**
     * Returns the particular property requested for in the underlying
     * implementation of org.xml.sax.XMLReader.
     *
     * @param  name the name of the property to be retrieved.
     * @return value of the requested property.
     * @throws ParserConfigurationException if {@link XMLReaderImpl} cannot
     *         satisfy the requested configuration.
     * @throws SAXNotRecognizedException when the underlying XMLReader does
     *         not recognize the property name.
     * @throws SAXNotSupportedException when the underlying XMLReader
     *         recognizes the property name but doesn't support the property.
     */
    public boolean getFeature(String name)
            throws ParserConfigurationException, SAXNotRecognizedException,
                  SAXNotSupportedException {
        if (name.equals("http://xml.org/sax/features/namespaces")) {
            return true;
        } else if (name.equals(
                "http://xml.org/sax/features/namespace-prefixes")) {
            return true;
        } else {
            throw new SAXNotRecognizedException(
                "Feature " + name + " not recognized");
        }
    }

    /**
     *
     * Sets the particular feature in the underlying implementation of
     * org.xml.sax.XMLReader.
     * A list of the core features and properties can be found at
     * <a href="http://www.megginson.com/SAX/Java/features.html">
     * http://www.megginson.com/SAX/Java/features.html </a>
     *
     * @param  name the name of the feature to be set.
     * @param  value the value of the feature to be set.
     * @throws ParserConfigurationException if {@link XMLReaderImpl} cannot
     *         satisfy the requested configuration.
     * @throws SAXNotRecognizedException when the underlying XMLReader does
     *         not recognize the property name.
     * @throws SAXNotSupportedException when the underlying XMLReader does
     *         recognizes the property name but doesn't support the property.
     */
    public void setFeature(String name, boolean value)
        throws ParserConfigurationException, SAXNotRecognizedException,
                SAXNotSupportedException {
        if (    name.equals("http://xml.org/sax/features/namespaces") ||
                name.equals("http://xml.org/sax/features/namespace-prefixes")) {
            return; // Ignores, these features are always set.
        } else {
            throw new SAXNotRecognizedException(
                "Feature " + name + " not recognized");
        }
    }
}