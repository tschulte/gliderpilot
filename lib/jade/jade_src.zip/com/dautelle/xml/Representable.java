/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;

/**
 * <p> This interface identifies classes, whose instances are serializable
 *     using the XML format.</p>
 * <p> For deserialization, the reciprocal factory method:
 *     <pre>public static Object valueOf(XmlElement xmlElement)</pre>
 *     should be provided, either by the class itself, one of its ancestor or
 *     a delegate class (Ref. {@link XmlElement#setFactoryClass}).</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.0, February 29, 2003
 * @see     XmlElement
 */
public interface Representable {

    /**
     * Sets the attributes and content of the XML element corresponding
     * to this object.
     *
     * @param  xml the XML element to set according to this object's desired XML
     *         representation.
     */
    void toXml(XmlElement xml);

}