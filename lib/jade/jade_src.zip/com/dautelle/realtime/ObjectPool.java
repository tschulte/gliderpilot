/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

/**
 * This abstract class represents an object pool managed by a 
 * {@link PoolContext}. {@link #isLocal Local} pools are safe to use 
 * without synchronization. The real-time framework guarantees that 
 * no more than one thread can have access to any local pool at any
 * given time. As for operations upon non-local pools, synchronization
 * has to be performed on the pool itself to guarantee thread-safety.
 * For example:<pre>
 *      public Object toHeap() {
 *          if (_pool.isLocal()) {
 *              _pool = _pool.remove(this);
 *          } else if (!_pool.isHeap()) {
 *              // Non-local pools require synchronization.
 *              synchronized (_pool) {
 *                 _pool = _pool.remove(this);
 *              }
 *          } // Else already on the heap.
 *          return this;
 *      }</pre>
 * 
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 16, 2004
 */
public abstract class ObjectPool {

    /**
     * Holds the outer pool of this pool or <code>null</code>
     * if this pool represents the heap.
     */
    ObjectPool outer;

    /**
     * Holds the current user of this pool.  
     */
    Thread user;

    /**
     * Holds the factory constructing the objects of this pool.  
     */
    private final ObjectFactory _factory;

    /**
     * Base constructor.
     * 
     * @param factory the factory constructing the objects of this pool.  
     */
    protected ObjectPool(ObjectFactory factory) {
        _factory = factory;
    }

    /**
     * Returns the factory constructing the objects of this pool.
     * 
     * @return the factory constructing the objects of this pool.  
     */
    public final ObjectFactory getFactory() {
        return _factory;
    }

    /**
     * Returns the current user of this pool or <code>null</code> if none.
     * 
     * @return the pool current user (unique).  
     */
    public final Thread getUser() {
        return user;
    }

    /**
     * Indicates if this pool is actively used by the current thread.
     * 
     * @return <code>true</code> if this pool is local for the current thread;
     *         <code>false</code> otherwise.
     */
    public final boolean isLocal() {
        // Only non-local pools can be shared between multiple threads.
        // assert (user == null) || (user == Thread.currentThread()) : 
        //    "Local pool visible to more than one thread!";
        return (user != null);
    }

    /**
     * Indicates if this pool allocates on the heap. A pool which has been 
     * disposed always allocates on the heap.
     * 
     * @return <code>true</code> if this pool represents the heap;
     *        <code>false</code> otherwise.
     */
    public final boolean isHeap() {
        return outer == null;
    }

    /**
     * Returns the outer pool of this pool.
     * 
     * @return the outer pool or <code>null</code> if this pool represents the
     *         heap.  
     */
    public final ObjectPool getOuter() {
        return outer;
    }

    /**
     * Returns the next available object from this pool. If there is none,
     * a new object is allocated on the heap, added to the pool and returned.  
     * 
     * @return the next available object from this pool.
     */
    public abstract Object next();

    /**
     * Recycles the specified object. Callers should make sure that the recycled
     * object is not going to be referenced anymore (in a heap context it would
     * be garbage collected).
     * 
     * <p>Note: This method has no effect if this pool represents the heap.</p>
     * 
     * @param obj the object to recycle to this pool.
     * @throws IllegalArgumentException if the specified object do not belong
     *         to the pool.
     */
    public abstract void recycle(Object obj);

    /**
     * Exports the specified object out of this pool to the outer pool.
     * To avoid pool depletion it is usually recommended to swap the 
     * specified object with a free object from the outer pool.
     * 
     * <p>Note: This method has no effect if this pool represents the heap.</p>
     * 
     * @param obj the object to export to outer pool.
     * @return the new pool this objects now belongs to.
     * @throws IllegalArgumentException if the specified object do not belong
     *         to the pool.
     */
    public abstract ObjectPool export(Object obj);

    /**
     * Removes the specified object from this pool. After removal the specified
     * object belongs to the heap and will be garbage collected if not 
     * referenced.
     *   
     * <p>Note: This method has no effect if this pool represents the heap.</p>
     * 
     * @param obj the object to remove from this pool.
     * @return the heap pool this objects now belongs to.
     * @throws IllegalArgumentException if the specified object do not belong
     *         to the pool.
     */
    public abstract ObjectPool remove(Object obj);

    /////////////////////
    // Control Methods //
    /////////////////////

    /**
     * Recycles all the objects of this pool.
     * 
     * <p> Note: This method is called upon {@link PoolContext#exit exit}
     *           of a pool context for which this pool has been used.</p>
     */
    protected abstract void recycleAll();

    /**
     * Removes all objects from this pool, after disposal this pool 
     * allocates object on the heap exclusively (and <code>this.isHeap()</code>
     * always returns <code>true</code>).
     * 
     * <p> Note: This method is called upon {@link PoolContext#clear 
     *           clearing} of the pool context this pool belongs to.
     */
    protected abstract void dispose();

}