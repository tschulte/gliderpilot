/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

import java.lang.reflect.Array;

import com.dautelle.util.FastMap;

/**
 * <p> This class provides static methods to return {@link ObjectPool} for
 *     array of any type. The pool returned allocates arrays from the "stack" 
 *     when the current thread executes in {@link PoolContext}.</p>
 * <p> Allocating large arrays is very time consuming and prone to garbage
 *     collection interrruptions. It is therefore highly recommended to use this
 *     class when new arrays are dynamically allocated.</p>
 * <p> Applications may create arrays of any component type including primitive
 *     types. For example:<pre>
 *     char[] chars = (char[]) ArrayPool.charArray(128).next();
 *     Thread[] threads = (Thread[]) ArrayPool.array(Thread.class, 64).next();
 *     </pre>
 *     The arrays returned may have a length larger than the specified capacity.
 *     If the exact length is required then custom {@link ObjectFactory} should
 *     be used instead.</p>
 * <p> Arrays may be individually recycled when it can be asserted 
 *     that the arrays will not be referenced anymore. For example:<pre>
 *     ObjectPool pool = ArrayPool.charArray(1024);
 *     char[] buffer = (char[]) pool.next(); 
 *     for (int i = reader.read(buffer, 0, buffer.length); i > 0;) {
 *         ...
 *     } 
 *     pool.recycle(buffer);</pre>
 *     <i> Note: Array allocation/recycling is effective only if the current
 *               thread executes within a {@link PoolContext}.</i></p>
 * <p> "Stack" allocated arrays are often used to implement dynamically sized
 *     {@link Realtime} objects, in which case its factory implements the 
 *     {@link ObjectFactory#cleanup cleanup} method to clear the dynamic 
 *     reference for future reuse (this does not apply to fixed size arrays 
 *     allocated at construction time). For example:<pre>
 *     public class FastString extends RealtimeObject implements CharSequence {
 *          private static final Factory FACTORY = new Factory() {
 *              public Object create() {
 *                  return new FastString();
 *              }
 *              public void cleanup(Object obj) {
 *                  ((FastString)obj)._data = null;;
 *              }
 *          };
 *          char[] _data;
 *          int _first, _length;
 *          public static FastString newInstance(int capacity) {
 *              FastString str = (FastString) FACTORY.object();
 *              str._data = (char[]) ArrayPool.charArray(capacity).next();
 *              str._first = 0;
 *              str._length = 0;
 *              return str;
 *          }
 *    }</pre></p> 
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 24, 2004
 */
public final class ArrayPool {

    /**
     * Default constructor (forbids derivation).
     */
    private ArrayPool() {
    }

    /**
     * Holds the mapping class to factory.
     */
    private static final FastMap CLASS_TO_FACTORIES = new FastMap();

    /**
     * Copies the specified array into the outer pool.
     * This method is typically used when exporting real-time objects 
     * referencing arrays allocated through {@link ObjectFactory}.
     * For example:<pre>
     *     public Object export() {
     *         if (isLocalObject()) {
     *             super.export();
     *             _data = (char[]) ArrayPool.outerCopy(_data, _first, _length);
     *             _first = 0;
     *         }  // Else non-local object cannot refer to local object.
     *         return this;
     *     }</pre>
     *
     * @param array the array to copy.
     * @param first the index of the first component to copy 
     *        (will be at position <code>0</code> in the copy).
     * @param length the number of components to copy.
     * @return a copy allocated in the outer context.
     * @throws IllegalArgumentException if array is not an array.
     */
    public static Object outerCopy(Object array, int first, int length) {
        Class componentType = array.getClass().getComponentType();
        if (componentType != null) {
            ObjectPool pool = array(componentType, length);
            ObjectPool outerPool = pool.getOuter();
            if ((outerPool != null) && !outerPool.isHeap()) {
                Object copy;
                synchronized (outerPool) { // Non-local pool.
                    copy = outerPool.next();
                }
                System.arraycopy(array, first, copy, 0, length);
                return copy;
            } else { // Outer context is the heap.
                return heapCopy(array, first, length);
            }
        } else {
            throw new IllegalArgumentException("array : Not an array");
        }
    }

    /**
     * Copies the specified array to the heap.
     * This method is typically used when moving to the heap real-time objects 
     * referencing arrays allocated through an {@link ObjectFactory}.
     * For example:<pre>
     *     public Object toHeap() {
     *         if (isPoolObject()) {
     *             super.toHeap();
     *             _data = (char[]) ArrayPool.heapCopy(_data, _first, _length);
     *             _first = 0;
     *         }  // Else heap objects can only refer to heap objects.
     *         return this;
     *     }</pre>
     *
     * @param array the array to copy.
     * @param first the index of the first component to copy 
     *        (will be at position <code>0</code> in the copy).
     * @param length the number of components to copy.
     * @return a copy allocated in the heap context.
     * @throws IllegalArgumentException if array is not an array.
     */
    public static Object heapCopy(Object array, int first, int length) {
        Class componentType = array.getClass().getComponentType();
        if (componentType != null) {
            Object copy = Array.newInstance(componentType, length);
            System.arraycopy(array, first, copy, 0, length);
            return copy;
        } else {
            throw new IllegalArgumentException("array : Not an array");
        }
    }

    /**
     * Returns the current pool for arrays of specified component type and 
     * minimum capacity. The arrays are automatically cleared (components set 
     * to <code>null<code>) when recycled for future reuse.
     *
     * @param  componentType the <code>Class</code> object representing the
     *         component type of the array.
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     * @see    ObjectFactory#cleanup
     */
    public static ObjectPool array(Class componentType, int capacity) {
        synchronized (CLASS_TO_FACTORIES) {
            ObjectFactory[] factories = (ObjectFactory[]) CLASS_TO_FACTORIES
                    .get(componentType);
            int i = log2(capacity);
            if (factories != null) {
                ObjectFactory factory = factories[i];
                if (factory != null) { return factory.currentPool(); }
            } else {
                factories = new ArrayFactory[32];
                CLASS_TO_FACTORIES.put(componentType, factories);
            }
            factories[i] = new ArrayFactory(componentType, 1 << i);
            return factories[i].currentPool();
        }
    }

    private final static class ArrayFactory extends ObjectFactory {

        private final Class _componentType;

        private final int _length;

        private ArrayFactory(Class componentType, int length) {
            _componentType = componentType;
            _length = length;
        }

        public Object create() {
            return Array.newInstance(_componentType, _length);
        }

        public void cleanup(Object obj) {
            clear((Object[]) obj, 0, _length);
        }
    }

    /**
     * Returns the current pool for <code>Object[]</code>.
     * The arrays are automatically cleared (components set 
     * to <code>null<code>) when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool objectArray(int capacity) {
        int i = log2(capacity);
        ObjectsFactory factory = OBJECT_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new ObjectsFactory(1 << i);
            OBJECT_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class ObjectsFactory extends ObjectFactory {

        private final int _length;

        private ObjectsFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new Object[_length];
        }

        public void cleanup(Object obj) {
            clear((Object[]) obj, 0, _length);
        }
    }

    private static final ObjectsFactory[] OBJECT_FACTORIES = new ObjectsFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Object.class, OBJECT_FACTORIES);
    }

    /**
     * Returns the current pool for <code>byte[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool byteArray(int capacity) {
        int i = log2(capacity);
        BytesFactory factory = BYTE_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new BytesFactory(1 << i);
            BYTE_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class BytesFactory extends ObjectFactory {

        private final int _length;

        private BytesFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new byte[_length];
        }
    }

    private static final BytesFactory[] BYTE_FACTORIES = new BytesFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Byte.TYPE, BYTE_FACTORIES);
    }

    /**
     * Returns the current pool for <code>char[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool charArray(int capacity) {
        int i = log2(capacity);
        CharsFactory factory = CHAR_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new CharsFactory(1 << i);
            CHAR_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class CharsFactory extends ObjectFactory {

        private final int _length;

        private CharsFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new char[_length];
        }
    }

    private static final CharsFactory[] CHAR_FACTORIES = new CharsFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Character.TYPE, CHAR_FACTORIES);
    }

    /**
     * Returns the current pool for <code>int[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool intArray(int capacity) {
        int i = log2(capacity);
        IntsFactory factory = INT_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new IntsFactory(1 << i);
            INT_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class IntsFactory extends ObjectFactory {

        private final int _length;

        private IntsFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new int[_length];
        }
    }

    private static final IntsFactory[] INT_FACTORIES = new IntsFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Integer.TYPE, INT_FACTORIES);
    }

    /**
     * Returns the current pool for <code>long[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool longArray(int capacity) {
        int i = log2(capacity);
        LongsFactory factory = LONG_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new LongsFactory(1 << i);
            LONG_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class LongsFactory extends ObjectFactory {

        private final int _length;

        private LongsFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new long[_length];
        }
    }

    private static final LongsFactory[] LONG_FACTORIES = new LongsFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Long.TYPE, LONG_FACTORIES);
    }

    /**
     * Returns the current pool for <code>float[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool floatArray(int capacity) {
        int i = log2(capacity);
        FloatsFactory factory = FLOAT_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new FloatsFactory(1 << i);
            FLOAT_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class FloatsFactory extends ObjectFactory {

        private final int _length;

        private FloatsFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new float[_length];
        }
    }

    private static final FloatsFactory[] FLOAT_FACTORIES = new FloatsFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Float.TYPE, FLOAT_FACTORIES);
    }

    /**
     * Returns the current pool for <code>double[]</code>.
     * The arrays are not cleared when recycled for future reuse.
     *
     * @param  capacity the minimum length of the array.
     * @return the current pool.
     */
    public static ObjectPool doubleArray(int capacity) {
        int i = log2(capacity);
        DoublesFactory factory = DOUBLE_FACTORIES[i];
        if (factory == null) { // Factory does not exist, creates.
            factory = new DoublesFactory(1 << i);
            DOUBLE_FACTORIES[i] = factory;
        }
        return factory.currentPool();
    }

    private final static class DoublesFactory extends ObjectFactory {

        private final int _length;

        private DoublesFactory(int length) {
            _length = length;
        }

        public Object create() {
            return new double[_length];
        }
    }

    private static final DoublesFactory[] DOUBLE_FACTORIES = new DoublesFactory[32];
    static {
        CLASS_TO_FACTORIES.put(Double.TYPE, DOUBLE_FACTORIES);
    }

    /**
     * Returns <code>j</code> such as <code>2<sup>j</sup> >= i</code>.
     * This function is used for factory selection.
     *  
     * @param i the <code>int</code> value.
     * @return <code>j</code> such as <code>2<sup>j</sup> >= i</code>
     */
    private static int log2(int i) {
        return (i < LOG_2.length) ? LOG_2[i] : highLog2(i);
    }

    private static int highLog2(int i) {
        int j = 8;
        while (i > (1 << ++j)) {
        }
        return j;
    }

    private static final int[] LOG_2;
    static {
        LOG_2 = new int[257];
        for (int i = 0, j = 0; i < LOG_2.length; i++) {
            if (i > (1 << j)) {
                j++;
            }
            LOG_2[i] = j;
        }
    }

    /**
     * Clears an array beginning at the specified position.
     *  
     * @param  array the array whose components are set to <code>null</code>.
     * @param  start the the starting position.
     * @param  length the number of components to clear.
     * @throws IndexOutOfBoundsException if clearing would cause access of data
     *         outside array bounds.
     */
    private static void clear(Object[] array, int start, int length) {
        for (int i = length - 4096; i >= 0; i -= 4096) {
            System.arraycopy(NULL_4096, 0, array, i + start, 4096);
        }
        System.arraycopy(NULL_4096, 0, array, start, length & 0xFFF);
    }

    private static final Object[] NULL_4096 = new Object[4096];

}