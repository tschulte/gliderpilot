/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

/**
 * <p> This class represents a pool context; it is used to reduce
 *     memory allocation and its "evil-brother" garbage collection.</p>
 * <p> Threads executing in a pool context may allocate objects from 
 *     the context's pools and recycle objects to the context's pool.
 *     As for all contexts, pool context are thread-local and can be
 *     reused over and over by the same thread.</p>
 * <p> Objects allocated within a pool context should not be directly 
 *     referenced outside of the context unless they have been 
 *     {@link Realtime#export exported} first. 
 *     If you follow this simple rule, then pool context are
 *     completely safe. In fact, pool contexts promote the use of immutable 
 *     objects (as their allocation cost is being significantly reduced) 
 *     and often lead to safer, faster and more robust applications.</p>
 * <p> Recycling occurs automatically upon {@link PoolContext#exit exit} and
 *     is typically very fast as all objects are recycled in block 
 *     (faster than GC). Individual recycling is also supported for methods
 *     having access to the object pool (e.g. member methods on their own pool). 
 *     The {@link ArrayPool} class has its pools public and therefore allows
 *     for individual recycling of any array.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 24, 2004
 */
public final class PoolContext extends Context {

    /**
     * Holds the pools for this context.
     */
    private final ObjectPool[] _pools = new ObjectPool[ObjectFactory.MAX];

    /**
     * Holds the pools used while the owner thread is in this context or 
     * within an inner pool context.
     */
    private final ObjectPool[] _usedPools = new ObjectPool[ObjectFactory.MAX];

    /**
     * Holds the number of pools used.
     */
    private int _usedPoolsLength;

    /**
     * Holds the outer pools context or null if none.
     */
    private PoolContext _outerPools;

    /**
     * Default constructor.
     */
    PoolContext() {
    } 

    /**
     * Enters a {@link PoolContext}.
     */
    public static void enter() {
        PoolContext ctx = (PoolContext) push(PoolContext.class);
        if (ctx == null) {
            ctx = new PoolContext();
            push(ctx);
        }        
        PoolContext outer = ctx.getOuter().poolContext();
        if (outer != null) {
            outer.setUsedPoolsLocal(false);
        }
    }

    /**
     * Exits the current {@link PoolContext}.
     *
     * @throws ClassCastException if the current context is not a
     *         {@link PoolContext}.
     */
    public static void exit() {
        PoolContext ctx = (PoolContext) pop();
        ctx.recyclePools();
        PoolContext outer = ctx.getOuter().poolContext();
        if (outer != null) {
            outer.setUsedPoolsLocal(true);
        }
    }

    /**
     * Disposes of all unused pools for the current thread. 
     * This method has no effect on local pools and outer pools.
     * Disposing of the pools has a direct impact on performance and 
     * should seldom be used. 
     */
    public static void clear() {
        for (Context context = Context.current().getInner(); context != null; context = context
                .getInner()) {
            if (context instanceof PoolContext) {
                PoolContext ctx = (PoolContext) context;
                for (int i = ObjectFactory.Count; i > 0;) {
                    ObjectPool pool = ctx._pools[--i];
                    if (pool != null) {
                        pool.dispose();
                        pool.outer = null;
                        ctx._pools[i] = null;
                    }
                    ctx._usedPools[i] = null;
                }
                ctx._usedPoolsLength = 0;
            }
        }
    }

    /**
     * Sets the pool currently being used as local or non-local.
     *
     * @param isCurrent <code>true</code> if this context is the current 
     *        pool context; <code>false</code> otherwise.
     */
    void setUsedPoolsLocal(boolean areLocal) {
        Thread user = areLocal ? getOwner() : null;
        for (int i = _usedPoolsLength; i > 0;) {
            _usedPools[--i].user = user;
        }
    }

    /**
     * Sets the outer context of this pool context (used exclusively 
     * by concurrent threads to connect to another context hierarchy).
     * 
     * @param outerPools the context containing the outer pools.
     */
    void setOuter(Context outer) {
        super.setOuter(outer);
        PoolContext outerPools = outer.poolContext();
        if (outerPools != _outerPools) {
            _outerPools = outerPools;
            for (int id = ObjectFactory.Count; id > 0;) {
                ObjectPool pool = _pools[--id];
                if (pool != null) {
                    if (outerPools != null) {
                        pool.outer = outerPools.getPool(id);
                    } else {
                        pool.outer = ObjectFactory.INSTANCES[id].heapPool();
                    }
                }
            }
        }
    }

    /**
     * Returns the pool from the specified factory and marks it as local. 
     *
     * @param factory the factory for the pool to return.
     * @return the corresponding pool marked as local. 
     */
    ObjectPool getLocalPool(ObjectFactory factory) {
        ObjectPool pool = getPool(factory.id);
        if (pool.isLocal()) {
            return pool;
        } else { // Pool is not currently used (otherwise it would be local) 
            pool.user = getOwner();
            _usedPools[_usedPoolsLength++] = pool;
            return pool;
        }
    }

    /**
     * Returns the pool from the specified factory in this context.
     *
     * @param id the factory id of the pool to return.
     * @return the corresponding pool. 
     */
    ObjectPool getPool(int id) {
        ObjectPool pool = _pools[id];
        if (pool == null) { // Creates pool, synchronization required
            synchronized (this) { // to maintain unicity.
                pool = _pools[id];
                if (pool == null) {
                    pool = ObjectFactory.INSTANCES[id].newPool();
                    pool.outer = (_outerPools != null) ? _outerPools
                            .getPool(id) : ObjectFactory.INSTANCES[id]
                            .heapPool();
                    _pools[id] = pool;
                }
            }
        }
        return pool;
    }

    /**
     * Recycles pools.
     */
    void recyclePools() {
        // Recycles pools and reset pools used.
        for (int i = _usedPoolsLength; i > 0;) {
            ObjectPool pool = _usedPools[--i];
            pool.recycleAll();
            pool.user = null;
        }
        _usedPoolsLength = 0;
    }

}