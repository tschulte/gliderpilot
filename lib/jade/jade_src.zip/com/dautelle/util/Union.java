/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * This class is public domain (not copyrighted).
 */
package com.dautelle.util;
import java.nio.ByteBuffer;

/**
 * <p> This class represents a <code>C/C++ union</code>; it works in the same
 *     way as {@link Struct} (sub-class) except that all members are mapped
 *     to the same location in memory.</p>
 * <p> Here is an example of C union: <pre>
 *     union Number {
 *         int   asInt;
 *         float asFloat;
 *         char  asString[12];
 *     };</pre>
 *     And its Java equivalent:<pre>
 *     public class Number extends Union {
 *         Signed32   asInt    = new Signed32();
 *         Float32    asFloat  = new Float32();
 *         UTF8String asString = new UTF8String(12);
 *     }</pre>
 *     As for any {@link Struct}, fields are directly accessible:<pre>
 *     Number num = new Number();
 *     num.asInt.set(23);
 *     num.asString.set("23"); // Null terminated (C compatible)
 *     float f = num.asFloat.get();</pre>
 *
 * <p><i> This class is <b>public domain</b> (not copyrighted).</i></p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 5.2, September 28, 2003
 */
public abstract class Union extends Struct {

    /**
     * Default constructor. Top-level {@link Union} created using this
     * constructor are backed by a direct buffer. 
     */
    public Union() {
        super();
    }

    /**
     * Creates a {@link Union} backed by the specified {@link ByteBuffer}.
     *
     * @param buffer the byte buffer for this {@link Union}.
     */
    public Union(ByteBuffer buffer) {
        super(buffer);
    }

    ///////////////////////////////
    // No method, tagging class. //
    ///////////////////////////////
}