/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

/**
 * <p> This class represents a heap context; it is used to allocate objects
 *     from the heap pool (always safe).</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 5.0, August 17, 2003
 */
public final class HeapContext extends Context {

    /**
     * Default constructor.
     */
    HeapContext() {
    } 

    /**
     * Enters a {@link HeapContext}.
     */
    public static void enter() {
        HeapContext ctx = (HeapContext) push(HeapContext.class);
        if (ctx == null) {
            ctx = new HeapContext();
            push(ctx);
        }
        PoolContext outer = ctx.getOuter().poolContext();
        if (outer != null) {
            outer.setUsedPoolsLocal(false);
        }
    }

    /**
     * Exits the current {@link HeapContext}.
     *
     * @throws ClassCastException if the current context is not a heap context.
     * @throws UnsupportedOperationException if the current context is the root 
     *         context.
     */
    public static void exit() {
        HeapContext ctx = (HeapContext) pop();
        PoolContext outer = ctx.getOuter().poolContext();
        if (outer != null) {
            outer.setUsedPoolsLocal(true);
        }
    }
}