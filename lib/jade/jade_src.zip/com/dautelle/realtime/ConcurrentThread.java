/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

import com.dautelle.util.TypeFormat;

/**
 * <p> This class represents "worker" threads employed by 
 *     {@link ConcurrentContext} to perform concurrent 
 *     {@link ConcurrentContext#execute executions} on multi-processors
 *     systems.</p>
 * <p> Instances of this class are created are start-up and maintained
 *     on-standby in order to execute quickly.</p>
 * <p> To avoid thread proliferation, the number of instance of this class 
 *     is voluntarily limited (see <a href=
 *     "{@docRoot}/overview-summary.html#configuration">JADE's Configuration</a>
 *     for details). By default, only systems with Hyper-Threading or 
 *     multi-processors have instances of this class.</p> 
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 1, 2004
 */
public final class ConcurrentThread extends Thread {

    /**
     * Holds the maximum number of {@link ConcurrentThread} (system property 
     * <code>"jade.concurrency"</code>, default 
     * <code>Runtime.getRuntime().availableProcessors() - 1</code>).
     */
    public static final int MAX = TypeFormat.parseInt(System.getProperty(
            "jade.concurrency", String.valueOf(Runtime.getRuntime()
                    .availableProcessors() - 1)));

    /**
     * Holds the concurrent threads instances.
     */
    private static final ConcurrentThread[] INSTANCES 
        = new ConcurrentThread[MAX];
    static {
        for (int i=0; i < MAX; i++) {
            INSTANCES[i] = new ConcurrentThread(i);
            INSTANCES[i].start();
        }
    }

    /**
     * Holds the current context for this concurrent thread.
     */
    private Context _currentContext;

    /**
     * Holds the concurrent context this thread belongs to.
     */
    private ConcurrentContext _concurrentContext;

    /**
     * Holds this concurrent thread index, range [0, {@link #MAX}[.
     */
    private final int _index;

    /**
     * Holds the number of logics to be executed.
     */
    int logicsLength;

    /**
     * Default constructor.
     */
    private ConcurrentThread(int index) {
        super("ConcurrentThread-" + index);
        setDaemon(true);
        _index = index;
    }

    /**
     * Requests for all {@link ConcurrentThread} available to execute the logics
     * of the specified concurrent context.
     *
     * @return the actual number of threads working for this concurrent context.
     */
    static int execute(ConcurrentContext concurrentContext) {
        int concurrency = 0;
        if (MAX > 0) { 
            synchronized (INSTANCES) {
                for (int i=0; i < MAX; i++) {
                    if (INSTANCES[i]._concurrentContext == null) {
                        synchronized (INSTANCES[i]) {
                            INSTANCES[i]._concurrentContext = concurrentContext;
                            INSTANCES[i].notify();
                        }
                        concurrency++;
                    }
                }
            }
        }
        return concurrency;
    }

    /**
     * Returns a unique identifier for this thread which can be used 
     * as index in an array (range [0, {@link #MAX}[).
     * 
     * @return this thread's index.
     */
    public int getIndex() {
        return _index;
    }

    /**
     * Overrides parent's <code>run</code> method.
     */
    public void run() {
        PoolContext rootContext = new PoolContext();
        while (true) {
           try {
               synchronized (this) {
                    while (_concurrentContext == null) {
                        this.wait();
                    }
               }
               _currentContext = rootContext;
               rootContext.setOuter(_concurrentContext);
               while (_concurrentContext.executeNext()) {
                   rootContext.recyclePools();
               }
           } catch (Throwable e) {
               e.printStackTrace();   
           } finally {
               synchronized (INSTANCES) {  
                   _concurrentContext = null; // Thread available again.
               }
           }
        }
    }

    /**
     * Returns the current context of this concurrent thread.
     * 
     * @return this thread context.
     */
    Context getCurrentContext() {
        return _currentContext;
    }

    /**
     * Sets the current context of this concurrent thread.
     * 
     * @return this thread context.
     */
    void setCurrentContext(Context current) {
        _currentContext = current;
    }
}