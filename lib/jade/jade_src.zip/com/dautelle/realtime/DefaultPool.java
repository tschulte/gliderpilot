/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

/**
 * This class provides a default implementation for {@link ObjectPool}.
 * 
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, Jan 18, 2004
 */
final class DefaultPool extends ObjectPool {

    /**
     * Holds the pool's objects.
     */
    private Object[] _objects = new Object[32];

    /**
     * Holds the current pool's index.
     */
    private int _index;

    /**
     * Holds the current pool's length.
     */
    private int _length;

    /**
     * Indicates if object cleanup is enabled (default <code>true</code>).
     */
    private boolean _isCleanupEnabled = true;

    /**
     * Creates a pool for the specified factory.
     * 
     * @param factory the factory for this pool.
     */
    DefaultPool(ObjectFactory factory) {
        super(factory);
    }

    // Implements ObjectPool abstract method.
    public Object next() {
        return (_index > 0) ? _objects[--_index] : allocate();
    }

    private Object allocate() {
        Object obj = getFactory().create();
        if (!isHeap()) { // Adds to the pool.
            if (_length >= _objects.length) { // Resizes.
                Object[] tmp = new Object[_length * 2];
                System.arraycopy(_objects, 0, tmp, 0, _length);
                _objects = tmp;
            }
            _objects[_length++] = obj;
        }
        return obj;
    }

    // Implements ObjectPool abstract method.
    public void recycle(Object obj) {
        if (!this.isHeap()) { // No effect on heap pool.
            int i = indexOf(obj);
            if (i >= 0) {
                _objects[i] = _objects[_index];
                _objects[_index++] = obj;
                if (_isCleanupEnabled) {
                    cleanup(obj);
                }
            } else {
                throw new IllegalArgumentException(
                        "obj: Object not in the pool");
            }
        }
    }

    // Implements ObjectPool abstract method.
    public ObjectPool export(Object obj) {
        DefaultPool outerPool = (DefaultPool) getOuter();
        if (outerPool != null) {
            if (outerPool.isHeap()) {
                return remove(obj); // Exports to heap is equivalent to remove.
            } else {
                // Outer pool is not local, synchronized access required.
                synchronized (outerPool) {
                    int i = indexOf(obj);
                    if (i >= 0) {
                        // Swaps with outer object.
                        int outerIndex = (outerPool._index > 0) ? outerPool._index - 1
                                : outerPool._length;
                        Object outerObject = outerPool.next();
                        outerPool._objects[outerIndex] = obj;
                        _objects[i] = outerObject;
                        return outerPool;
                    } else {
                        throw new IllegalArgumentException(
                                "obj: Object not in the pool");
                    }
                }
            }
        } else { // Exports from heap has no effect.
            return this;
        }
    }

    // Implements ObjectPool abstract method.
    public ObjectPool remove(Object obj) {
        if (!isHeap()) {
            int i = indexOf(obj);
            if (i >= 0) {
                _objects[i] = getFactory().create();
                return getFactory().heapPool();
            } else {
                throw new IllegalArgumentException(
                        "obj: Object not in the pool");
            }
        } else { // No effect already belongs to the heap.
            return this;
        }
    }

    // Implements ObjectPool abstract method.
    protected void recycleAll() {
        // Cleanup used objects if cleanup enabled.
        for (int i = _index; _isCleanupEnabled && (i < _length);) {
            cleanup(_objects[i++]);
        }
        // Resets pointer.
        _index = _length;
    }

    // Implements ObjectPool abstract method.
    protected void dispose() {
        _objects = null;
        _index = 0;
        _length = 0;
    }

    /**
     * Searches for the specified object in this pool.
     *
     * @param  obj the object to search for.
     * @return the index of this object or <code>-1</code> if not found.
     */
    private int indexOf(Object obj) {
        for (int i = _index; i < _length; i++) {
            if (_objects[i] == obj) { return i; }
        }
        return -1;
    }

    /**
     * Attempts to clean-up this object. If the attempt fails, object cleaning
     * is disabled.
     *
     * @param  obj the object to cleanup.
     */
    private void cleanup(Object obj) {
        try {
            this.getFactory().cleanup(obj);
        } catch (UnsupportedOperationException ex) {
            _isCleanupEnabled = false;
        }
    }
}