/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;

/**
 * <p> Signals that a problem of some sort has occurred when creating an object
 *     from its XML representation.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.0, February 29, 2003
 * @see     Constructor
 */
public class ConstructorException extends RuntimeException {

    /**
     * Constructs a <code>ConstructorException</code> with  no detail message.
     */
    public ConstructorException() {
        super();
    }

    /**
     * Constructs a <code>ConstructorException</code> with the specified detail
     * message.
     *
     * @param   message the detail message.
     */
    public ConstructorException(String message) {
        super(message);
    }

    /**
     * Constructs a <code>ConstructorException</code> with the specified detail
     * message and cause.
     *
     * @param  message the detail message.
     * @param  cause the cause.
     */
    public ConstructorException(String message, Throwable cause) {
        super(message + " caused by " + cause);
    }

    /**
     * Constructs a <code>ConstructorException</code> with the specified cause.
     *
     * @param  cause the cause.
     */
    public ConstructorException(Throwable cause) {
        super("Constructor exception caused by " + cause.toString());
    }
}