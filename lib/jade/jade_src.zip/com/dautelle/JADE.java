/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

import javax.units.NonSI;
import javax.units.SI;

import org.xml.sax.XMLReader;

import com.dautelle.math.Complex;
import com.dautelle.math.LargeInteger;
import com.dautelle.math.Matrix;
import com.dautelle.math.Numerics;
import com.dautelle.math.Operable;
import com.dautelle.math.Numerics.Float64;
import com.dautelle.money.Currency;
import com.dautelle.physics.Duration;
import com.dautelle.physics.Quantity;
import com.dautelle.physics.Scalar;
import com.dautelle.realtime.ArrayPool;
import com.dautelle.realtime.ConcurrentContext;
import com.dautelle.realtime.HeapContext;
import com.dautelle.realtime.PoolContext;
import com.dautelle.util.FastMap;
import com.dautelle.util.FastString;
import com.dautelle.xml.Constructor;
import com.dautelle.xml.ObjectWriter;
import com.dautelle.xml.sax.RealtimeParser;

/**
 * <p> This class represents the JADE library; it contains the library
 *     {@link #initialize} method as well as a {@link #main} method for
 *     versionning, self-tests, and performance analysis.</p>
 * <p> Initialization is <b>mandatory</b> for packages using the
 *     <code>Unit</code> class (e.g. <code>physics</code> and
 *     <code>money</code>). It ensures that the unit database is loaded and
 *     that predefined quantities are recognized.
 *     Initialization can be performed either at start-up (recommended):<pre>
 *     public static void main(String[] args) {
 *         com.dautelle.JADE.initialize();
 *         ... // Initializes other classes (e.g. custom quantity classes).
 *     }</pre>
 *     or dynamically (class initialization). For example:<pre>
 *     class ClassUsingUnits {
 *         static {
 *             com.dautelle.JADE.initialize(); // No effect if library
 *                                             // already initialized.
 *         }
 *     }</pre></p>
 * <p> Failure to initialize, results in <code>IllegalStateException</code>
 *     being thrown.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.4, March 31, 2003
 */
public final class JADE {

    /**
     * Holds the version information.
     */
    public final static String VERSION = "@VERSION@";

    /**
     * Indicates if the library needs to be initialized.
     */
    private static boolean _doInitialize = true;

    /**
     * Default constructor.
     */
    private JADE() {// Forbids derivation.
    }

    /**
     * The library {@link #main} method.
     * The archive <code>jade.jar</code> is auto-executable.
     * <ul>
     * <li><code>java -jar jade.jar</code> to output version information.</li>
     * <li><code>java -jar jade.jar test</code> to perform self-tests.</li>
     * <li><code>java -jar jade.jar perf</code> for performance analysis.</li>
     * </ul>
     *
     * @param  args the option arguments.
     * @throws Exception if a problem occurs.
     */
    public static void main(String[] args) throws Exception {
        System.out.println("Java(TM) Addition to Default Environment "
                + "(http://jade.dautelle.com/)");
        System.out.println("Version " + VERSION);
        if (args.length > 0) {
            if (args[0].equals("test")) {
                testing();
            } else if (args[0].equals("perf")) {
                benchmark();
            }
        }
    }

    /**
     * Initializes library classes. This method <b>has to be called</b> at
     * least once by the application (typically at start-up).
     * It ensures that:
     * <ol>
     *     <li> The unit database is loaded (e.g. <code>Unit.valueOf("ft")
     *          </code> returns <code>NonSI.FOOT</code>).</li>
     *     <li> Predefined quantity sub-classes are mapped to their respective
     *          units (e.g. <code>Quantity.valueOf(1, SI.METER)</code>
     *          returns a <code>Length</code> instance).</li>
     *     <li> Class initialization is performed in a {@link HeapContext}.
     *          Static class members are allocated on the heap and
     *          can safely be referenced anywhere.</li>
     *     <li> Classes are initialized in the correct order. The initialization
     *          state is unvarying, regardless of library usages.</li>
     *     <li> Execution time is more predictable as class initialization
     *          has already been performed.</li>
     * </ol>
     *
     * <p><i> Note: It the library is extended (e.g. new quantity sub-classes),
     *        it is the responsibility of the application to ensure that
     *        the new classes are properly initialized as well.</i></p>
     */
    public static synchronized void initialize() {
        if (_doInitialize) { //  Performs initialization only once.
            _doInitialize = false;
            try {
                HeapContext.enter();

                // Initializes utilities classes.
                Class.forName("com.dautelle.util.TypeFormat");

                // Initializes SI, NonSI units.
                Class.forName("javax.units.SI");
                Class.forName("javax.units.NonSI");

                // Initializes physical quantities.
                Class.forName("com.dautelle.physics.Acceleration");
                Class.forName("com.dautelle.physics.AmountOfSubstance");
                Class.forName("com.dautelle.physics.Angle");
                Class.forName("com.dautelle.physics.AngularAcceleration");
                Class.forName("com.dautelle.physics.AngularVelocity");
                Class.forName("com.dautelle.physics.Area");
                Class.forName("com.dautelle.physics.CatalyticActivity");
                Class.forName("com.dautelle.physics.DataAmount");
                Class.forName("com.dautelle.physics.DataRate");
                Class.forName("com.dautelle.physics.Duration");
                Class.forName("com.dautelle.physics.ElectricCapacitance");
                Class.forName("com.dautelle.physics.ElectricCharge");
                Class.forName("com.dautelle.physics.ElectricConductance");
                Class.forName("com.dautelle.physics.ElectricCurrent");
                Class.forName("com.dautelle.physics.ElectricInductance");
                Class.forName("com.dautelle.physics.ElectricPotential");
                Class.forName("com.dautelle.physics.ElectricResistance");
                Class.forName("com.dautelle.physics.Energy");
                Class.forName("com.dautelle.physics.Force");
                Class.forName("com.dautelle.physics.Frequency");
                Class.forName("com.dautelle.physics.Illuminance");
                Class.forName("com.dautelle.physics.Length");
                Class.forName("com.dautelle.physics.LuminousFlux");
                Class.forName("com.dautelle.physics.LuminousIntensity");
                Class.forName("com.dautelle.physics.MagneticFlux");
                Class.forName("com.dautelle.physics.MagneticFluxDensity");
                Class.forName("com.dautelle.physics.Mass");
                Class.forName("com.dautelle.physics.Power");
                Class.forName("com.dautelle.physics.Pressure");
                Class.forName("com.dautelle.physics.RadiationDoseAbsorbed");
                Class.forName("com.dautelle.physics.RadiationDoseEffective");
                Class.forName("com.dautelle.physics.RadioactiveActivity");
                Class.forName("com.dautelle.physics.Scalar");
                Class.forName("com.dautelle.physics.SolidAngle");
                Class.forName("com.dautelle.physics.Temperature");
                Class.forName("com.dautelle.physics.Torque");
                Class.forName("com.dautelle.physics.Velocity");
                Class.forName("com.dautelle.physics.Volume");
                Class.forName("com.dautelle.physics.VolumetricDensity");

                // Initializes physical constants.
                Class.forName("com.dautelle.physics.Constants");

                // Initializes standard model (default model).
                Class.forName("com.dautelle.physics.models.StandardModel");

                // Initializes money package.
                Class.forName("com.dautelle.money.Currency");
                Class.forName("com.dautelle.money.Money");

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                HeapContext.exit();
            }
        }
    }

    /**
     * Verifies that the library is in a correct state (initialized).
     *
     * @throws IllegalStateException if the library has not been initialized.
     * @see    #initialize
     */
    public static synchronized void verify() {
        if (_doInitialize) {
            throw new IllegalStateException(
                "JADE library has not been initialized, please read "
                   + "com.dautelle.JADE.initialize() specification.");
        }
    }

    /**
     * Performs simple tests.
     *
     * @throws Exception if a problem occurs.
     */
    private static void testing() throws Exception {
        System.out.println();
        System.out.print("Testing...");
        initialize();
        Matrix M = Matrix.valueOf(
                new Operable[][]{
                    {Scalar.ZERO, Scalar.ONE},
                    {Quantity.valueOf(2, NonSI.BAR), Scalar.valueOf(1.234)},
                    {Quantity.valueOf(22.336, Currency.EUR),
                        Quantity.valueOf(2, Currency.USD)},
                    {Quantity.valueOf(1, NonSI.FOOT),
                        Quantity.valueOf(3, NonSI.POUND)},});

        // Writes Matrix.
        ObjectWriter ow = new ObjectWriter();
        ow.setNamespace("", "com.dautelle.physics");
        ow.setNamespace("money", "com.dautelle.money");
        ow.setNamespace("math", "com.dautelle.math");

        StringWriter out = new StringWriter();
        ow.write(M, out);
        //System.err.println(out.getBuffer().toString()); // For Debugging

        // Read Matrix.
        StringReader in = new StringReader(out.getBuffer().toString());
        Constructor constructor = new Constructor();
        Matrix R = (Matrix) constructor.create(in);
        //System.err.println(R); // For Debugging

        if (Quantity.approxEquals(M, R)) {
            System.out.println("Success");
            System.exit(0);
        } else {
            System.out.println("Failed");
            System.exit( -1);
        }
    }

    /**
     * Measures performance.
     */
    private static void benchmark() {
        System.out.println();
        System.out.println("Benchmark...");

        System.out.println();
        System.out.print("Initialization: ");
        long time = System.currentTimeMillis();
        initialize();
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 1, SI.MILLI(SI.SECOND)));

        System.out.println();
        System.out.println("Heap versus Stack Allocation (Pool-Context)");
        Object[] results = new Object[10000];
        Duration.showAs(SI.NANO(SI.SECOND));

        System.out.print("java.lang.Double Heap Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            for (int j = 0; j < results.length; j++) {
                results[j] = new Double(1.0);
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        Duration.showAs(SI.MICRO(SI.SECOND));
        System.out.print("char[128] Heap Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < results.length; j++) {
                results[j] = new char[128];
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        System.out.print("char[256] Heap Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < results.length; j++) {
                results[j] = new char[256];
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        Duration.showAs(SI.NANO(SI.SECOND));
        System.out.print(
                "com.dautelle.math.Numerics.Float64 Pool-Context Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                for (int j = 0; j < results.length; j++) {
                    results[j] = Numerics.Float64.valueOf(1.0);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        Duration.showAs(SI.MICRO(SI.SECOND));
        System.out.print("char[128] Pool-Context Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            PoolContext.enter();
            try {
                for (int j = 0; j < results.length; j++) {
                    results[j] = ArrayPool.charArray(128).next();
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        System.out.print("char[256] Pool-Context Creation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            PoolContext.enter();
            try {
                for (int j = 0; j < results.length; j++) {
                    results[j] = ArrayPool.charArray(256).next();
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        System.out.println();
        System.out.println("Concurrent-Context: ");
        Duration.showAs(SI.SECOND);

        int size = 256;
        Matrix X = Matrix.newInstance(size,size);
        for (int i=0; i < size; i++) {
            for (int j=0; j < size; j++) {
                X.set(i,j, Float64.valueOf(Math.random()));
            }
        }

        System.out.print("Complex Numbers 256x256 Matrix Multiplication (Concurrency Disabled): ");
        ConcurrentContext.setEnabled(false);
        time = System.currentTimeMillis();
        for (int i=0; i < 10; i++) {
            X.multiply(X);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND)).divide(10));
        
        System.out.print("Complex Numbers 256x256 Matrix Multiplication (Concurrency Enabled): ");
        ConcurrentContext.setEnabled(true);
        time = System.currentTimeMillis();
        for (int i=0; i < 10; i++) {
            X.multiply(X);
        }    
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND)).divide(10));
        
        System.out.println("");
        System.out.println("Numerics: ");
        Duration.showAs(SI.NANO(SI.SECOND));

        System.out.print("com.dautelle.math.Numerics.Float64 add: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Numerics.Float64 x = Numerics.Float64.valueOf(1.0);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.add(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.print("com.dautelle.math.Complex add: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Complex x = Complex.valueOf(1.0, 2.0);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.add(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.print("com.dautelle.physics.Quantity (mass) add: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Quantity x = Quantity.valueOf(1, SI.KILOGRAM);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.add(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.print("com.dautelle.math.Numerics.Float64 multiply: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Numerics.Float64 x = Numerics.Float64.valueOf(1.0);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.multiply(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.print("com.dautelle.math.Complex multiply: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Complex x = Complex.valueOf(1.0, 2.0);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.multiply(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.print("com.dautelle.physics.Quantity (mass) multiply: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            PoolContext.enter();
            try {
                Quantity x = Quantity.valueOf(1, SI.KILOGRAM);
                for (int j = 0; j < results.length; j++) {
                    results[j] = x.multiply(x);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1000 * results.length));

        System.out.println();
        System.out.println("LargeInteger (PoolContext) versus BigInteger: ");
        Duration.showAs(SI.MICRO(SI.SECOND));

        System.out.print("java.math.BigInteger (1024 bits) add: ");
        BigInteger big = BigInteger.probablePrime(1024, new Random());
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < results.length; j++) {
                results[j] = big.add(big);
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        System.out.print("com.dautelle.math.LargeInteger (1024 bits) add: ");
        byte[] bytes = big.toByteArray();
        LargeInteger large = LargeInteger.valueOf(bytes, 0, bytes.length);
        time = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            PoolContext.enter();
            try {
                for (int j = 0; j < results.length; j++) {
                    results[j] = large.add(large);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(100 * results.length));

        System.out.println();
        System.out.println("FastString versus String/StringBuffer: ");
        Duration.showAs(SI.MILLI(SI.SECOND));

        final String TXT_STRING = "Performs 100 successive concatenations of this string.";
        System.out.println("\"" + TXT_STRING + "\"");
        final FastString TXT_STRING_RT = FastString.valueOf(TXT_STRING);

        System.out.print("java.lang.String Concatenation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            String x = TXT_STRING;
            for (int j = 0; j < 100; j++) {
                x = x.concat(TXT_STRING); // Or: x += TXT_STRING;
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1E4));
        System.out.print("java.lang.StringBuffer Concatenation: ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            StringBuffer x = new StringBuffer(TXT_STRING);
            for (int j = 0; j < 100; j++) {
                x.append(TXT_STRING);
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1E4));
        System.out.print(
                "com.dautelle.util.FastString Concatenation(Heap-Context): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            FastString x = TXT_STRING_RT;
            for (int j = 0; j < 100; j++) {
                x = x.concat(TXT_STRING_RT);
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1E4));
        System.out.print(
                "com.dautelle.util.FastString Concatenation(Pool-Context): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < 10000; i++) {
            PoolContext.enter();
            try {
                FastString x = TXT_STRING_RT;
                for (int j = 0; j < 100; j++) {
                    x = x.concat(TXT_STRING_RT);
                }
            } finally {
                PoolContext.exit();
            }
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(1E4));

        System.out.println();
        System.out.println("XML Parsing:");
        // Creates a dummy xml input source (containing a large matrix).
        int matrixSize = 256;
        Operable[][] matrixArray = new Operable[matrixSize][matrixSize];
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                matrixArray[i][j] = Complex.valueOf(Math.PI, Math.PI);
            }
        }
        Matrix M = Matrix.valueOf(matrixArray);
        ObjectWriter ow = new ObjectWriter();
        ow.setNamespace("math", "com.dautelle.math");
        StringWriter out = new StringWriter();
        try {
            ow.write(M, out);
        } catch (Exception e) {
            throw new Error(e);
        }
        String xmlString = out.getBuffer().toString();

        XMLReader xmlReader = null;

        try {
            xmlReader = (XMLReader) Class
                    .forName("org.apache.crimson.parser.XMLReaderImpl")
                    .newInstance();
            time = System.currentTimeMillis();
            xmlReader.parse(new org.xml.sax.InputSource(new StringReader(
                    xmlString)));
            time = System.currentTimeMillis() - time;
            System.out.println(xmlReader.getClass() + " : " + time);
        } catch (Exception e) {}

        try {
            xmlReader = (XMLReader) Class
                    .forName("com.dautelle.xml.sax.XMLReaderImpl")
                    .newInstance();
            time = System.currentTimeMillis();
            xmlReader.parse(new org.xml.sax.InputSource(new StringReader(
                    xmlString)));
            time = System.currentTimeMillis() - time;
            System.out.println(xmlReader.getClass() + " : " + time);
        } catch (Exception e) {}

        try {
            RealtimeParser rtParser = new RealtimeParser();
            time = System.currentTimeMillis();
            rtParser.parse(new org.xml.sax.InputSource(new StringReader(
                    xmlString)));
            time = System.currentTimeMillis() - time;
            System.out.println(rtParser.getClass() + " : " + time);
        } catch (Exception e) {}

        System.out.println();
        System.out.println("FastMap versus HashMap:");
        // Allocates keys and values.
        final int mapSize = 100000;
        Object[] keys = new Object[mapSize];
        for (int i = 0; i < mapSize; i++) {
            keys[i] = new Object();
        }
        Object value = new Object();
        Duration.showAs(SI.MICRO(SI.SECOND));

        System.out.print("java.util.HashMap#put(key, value): ");
        HashMap hashMap = new HashMap(mapSize);
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            hashMap.put(keys[i], value);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("java.util.HashMap#get(key): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            hashMap.get(keys[i]);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("java.util.HashMap#entrySet()#iterator(): ");
        time = System.currentTimeMillis();
        for (Iterator i = hashMap.entrySet().iterator(); i.hasNext(); ) {
            i.next();
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("java.util.HashMap#remove(key): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            hashMap.remove(keys[i]);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("com.dautelle.util.FastMap#put(key, value): ");
        FastMap fastMap = FastMap.newInstance(mapSize);
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            fastMap.put(keys[i], value);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("com.dautelle.util.FastMap#get(key): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            fastMap.get(keys[i]);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("java.util.FastMap#entrySet()#iterator(): ");
        time = System.currentTimeMillis();
        for (Iterator i = fastMap.entrySet().iterator(); i.hasNext(); ) {
            i.next();
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.print("java.util.FastMap#remove(key): ");
        time = System.currentTimeMillis();
        for (int i = 0; i < mapSize; i++) {
            fastMap.remove(keys[i]);
        }
        time = System.currentTimeMillis() - time;
        System.out.println(Quantity.valueOf(time, 0.5, SI.MILLI(SI.SECOND))
                .divide(mapSize));

        System.out.println();
        System.out.println("More performance analysis in future versions...");
    }
}