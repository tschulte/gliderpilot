/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Iterator;

import com.dautelle.util.Enum;
import com.dautelle.util.TypeFormat;

/**
 * <p> This class represents a XML element. Instances of this class are made
 *     available only during the XML serialization/deserialization process.</p>
 * <p> During serialization, XML elements are used to define the XML mapping of
 *     Java objects (ref. {@link Representable} interface).
 * <p> During deserialization, XML elements are restored and are converted
 *     to Java objects using the factory method: <code>
 *     <pre>static Object <i>elementName</i>.valueOf(XmlElement xml)</pre></code>
 *     where the <code>xml</code> parameter contains the attributes
 *     (<code>CharSequence</code>) as well as all the inners objects
 *     ({@link Representable}) recursively created from the XML document.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.6, July 15, 2003
 * @see     ObjectWriter
 * @see     Constructor
 */
public final class XmlElement extends AbstractList {

    /**
     * Holds the XML attribute's names (CharSequence elements).
     */
    final ArrayList _attributeNames = new ArrayList();

    /**
     * Holds the XML attribute's values (CharSequence elements).
     */
    final ArrayList _attributeValues = new ArrayList();

    /**
     * Holds the element's content.
     */
    final ArrayList _content = new ArrayList();

    /**
     * Holds the factory class used to deserialize this element.
     */
    Class _factoryClass;

    /**
     * Holds the parent of this element.
     */
    XmlElement _parent;

    /**
     * Default constructor.
     */
    XmlElement() {}

    ///////////////////
    // Serialization //
    ///////////////////

    /**
     * Creates a new attribute for this {@link XmlElement} and returns the
     * <code>StringBuffer</code> holding the attribute's value.
     *
     * <p> Note: This method allows for custom formatting of attribute's values
     *           without allocating temporary <code>String</code> objects.
     *           For example:<pre>
     *           // Formats an attribute in hexadecimal.
     *           TypeFormat.format(intValue, 16, xml.newAttribute(name));
     *           </pre></p>
     *
     * @param  name the attributes' name.
     * @return an empty <code>StringBuffer</code> to hold the attribute's value.
     */
    public StringBuffer newAttribute(CharSequence name) {
        StringBuffer sb = newStringBuffer();
        sb.setLength(0);
        _attributeNames.add(name);
        _attributeValues.add(sb);
        return sb;
    }

    /**
     * Sets the specified attribute (generic).
     *
     * @param  name the attributes' name.
     * @param  value the attributes' value.
     */
    public void setAttribute(CharSequence name, CharSequence value) {
        _attributeNames.add(name);
        _attributeValues.add(value);
    }

    /**
     * Sets the specified <code>Enum</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>Enum</code>for the specified attribute.
     * @see    #getAttribute(String, Enum)
     */
    public void setAttribute(String name, Enum value) {
        setAttribute(name, value.getName());
    }

    /**
     * Sets the specified <code>boolean</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>boolean</code> value for the specified attribute.
     * @see    #getAttribute(String, boolean)
     */
    public void setAttribute(String name, boolean value) {
        TypeFormat.format(value, newAttribute(name));
    }

    /**
     * Sets the specified <code>int</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>int</code> value for the specified attribute.
     * @see    #getAttribute(String, int)
     */
    public void setAttribute(String name, int value) {
        TypeFormat.format(value, newAttribute(name));
    }

    /**
     * Sets the specified <code>long</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>long</code> value for the specified attribute.
     * @see    #getAttribute(String, long)
     */
    public void setAttribute(String name, long value) {
        TypeFormat.format(value, newAttribute(name));
    }

    /**
     * Sets the specified <code>float</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>float</code> value for the specified attribute.
     * @see    #getAttribute(String, float)
     */
    public void setAttribute(String name, float value) {
        TypeFormat.format(value, newAttribute(name));
    }

    /**
     * Sets the specified <code>double</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  value the <code>double</code> value for the specified attribute.
     * @see    #getAttribute(String, double)
     */
    public void setAttribute(String name, double value) {
        TypeFormat.format(value, newAttribute(name));
    }

    /**
     * Sets the factory class to use for deserialization (identified by the
     * XML element tag name). By default, the factory class is the class of the
     * element being serialized.
     *
     * @param  factoryClass the class to use for deserialization.
     */
    public void setFactoryClass(Class factoryClass) {
        _factoryClass = factoryClass;
    }

    /////////////////////
    // Deserialization //
    /////////////////////

    /**
     * Returns the parent of this XML element (container element).
     *
     * @return this XML element's parent or <code>null</code> if this element
     *         is a root element.
     */
    public XmlElement getParent() {
        return _parent;
    }

    /**
     * Returns an iterator over the names of all the attributes being set for
     * this XML element.
     *
     * @return an iterator over the attributes' names (<code>CharSequence</code>
     *         objects).
     */
    public Iterator attributeNames() {
        return _attributeNames.iterator();
    }

    /**
     * Indicates if the specified attribute is present.
     *
     * @param  name the name of the attribute.
     * @return <code>true</code> if this xml element contains the specified
     *         attribute; <code>false</code> otherwise.
     */
    public boolean isAttribute(CharSequence name) {
        return getAttribute(name) != null;
    }

    /**
     * Searches for the specified attribute (generic).
     *
     * @param  name the name of the attribute.
     * @return the value of the attribute or <code>null</code> if not found.
     * @see    #setAttribute(CharSequence, CharSequence)
     */
    public CharSequence getAttribute(CharSequence name) {
        for (int i=0; i < _attributeNames.size(); i++) {
            if (_attributeNames.get(i).equals(name)) {
                return (CharSequence) _attributeValues.get(i);
            }
        }
        return null;
    }

    /**
     * Searches for the specified <code>String</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  defaultValue a default value.
     * @return the <code>String</code> value for the specified attribute or
     *         the <code>defaultValue</code> if the attribute is not found.
     */
    public String getAttribute(String name, String defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? chars.toString() : defaultValue;
    }

    /**
     * Searches for the specified <code>Enum</code> attribute.
     *
     * @param  name the name of the attribute.
     * @param  defaultValue a default value which also identifies the
     *          enumeration.
     * @return the <code>Enum</code> for the specified attribute or
     *         the <code>defaultValue</code> if the attribute is not found.
     */
    public Enum getAttribute(String name, Enum defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? 
            Enum.valueOf(chars, defaultValue.getClass()) :
            defaultValue;
    }

    /**
     * Returns the specified <code>boolean</code> attribute.
     *
     * @param  name the name of the attribute searched for.
     * @param  defaultValue the value returned if the attribute is not found.
     * @return the <code>boolean</code> value for the specified attribute or
     *         the default value if the attribute is not found.
     */
    public boolean getAttribute(String name, boolean defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? TypeFormat.parseBoolean(chars) :
                                 defaultValue;
    }

    /**
     * Returns the specified <code>int</code> attribute. This method handles
     * string formats that are used to represent octal and hexadecimal numbers.
     *
     * @param  name the name of the attribute searched for.
     * @param  defaultValue the value returned if the attribute is not found.
     * @return the <code>int</code> value for the specified attribute or
     *         the default value if the attribute is not found.
     */
    public int getAttribute(String name, int defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? TypeFormat.parseInt(chars) :
                                 defaultValue;
    }

    /**
     * Returns the specified <code>long</code> attribute. This method handles
     * string formats that are used to represent octal and hexadecimal numbers.
     *
     * @param  name the name of the attribute searched for.
     * @param  defaultValue the value returned if the attribute is not found.
     * @return the <code>long</code> value for the specified attribute or
     *         the default value if the attribute is not found.
     */
    public long getAttribute(String name, long defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? TypeFormat.parseLong(chars) :
                                 defaultValue;
    }

    /**
     * Returns the specified <code>float</code> attribute.
     *
     * @param  name the name of the attribute searched for.
     * @param  defaultValue the value returned if the attribute is not found.
     * @return the <code>float</code> value for the specified attribute or
     *         the default value if the attribute is not found.
     */
    public float getAttribute(String name, float defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? (float) TypeFormat.parseDouble(chars) :
                                 defaultValue;
    }

    /**
     * Returns the specified <code>double</code> attribute.
     *
     * @param  name the name of the attribute searched for.
     * @param  defaultValue the value returned if the attribute is not found.
     * @return the <code>double</code> value for the specified attribute or
     *         the default value if the attribute is not found.
     */
    public double getAttribute(String name, double defaultValue) {
        CharSequence chars = getAttribute(name);
        return (chars != null) ? TypeFormat.parseDouble(chars) :
                                 defaultValue;
    }

    /**
     * Sets the factory class for this XML element. The factory class is
     * responsible for the convertion of the XML element to a Java
     * Object.
     *
     * @return the factory class.
     * @see    #setFactoryClass
     */
    public Class getFactoryClass() {
        return _factoryClass;
    }

    /**
     * Convenience method equivalent to
     * <code>getFactoryClass().newInstance()</code>.
     * Typically, this method is used to provide a default XML factory method
     * inherited by sub-classes. For example:
     * <pre>
     *     abstract class TopClass {
     *         public static TopClass valueOf(XmlElement xml) {
     *             TopClass instance = (TopClass) xml.newInstance();
     *             ... // Initializes instance from xml.
     *             return instance;
     *         }
     *     }
     * </pre>
     *
     * @return a new instance of the class corresponding to this XML element
     *         using the class default constructor.
     * @throws ConstructorException if the instance cannot be created.
     */
    public Object newInstance() throws ConstructorException {
        try {
            return _factoryClass.newInstance();
        } catch (IllegalAccessException e2) {
            throw new ConstructorException(
                _factoryClass + " default constructor inaccessible");
        } catch (InstantiationException e3) {
            throw new ConstructorException(
                _factoryClass + " default constructor " +
                " instantiation exception (" + e3 + ")");
        }
    }

    //////////////////////
    // List operations. //
    //////////////////////

    /**
     * Appends the specified nested element to this {@link XmlElement}.
     *
     * @param  element the nested element to be inserted.
     */
    public void add(Representable element) {
        _content.add(element);
    }

    /**
     * Appends the specified nested elements to this {@link XmlElement}.
     *
     * @param  elements the nested elements being appended.
     * @return <code>true</code> if this {@link XmlElement} changed as a result
     *         of this call; <code>false</code> otherwise.
     */
    public boolean addAll(Representable[] elements) {
        for (int i=0; i < elements.length; i++) {
            add(elements[i]);
        }
        return (elements.length != 0);
    }

    /**
     * Returns the object contained by this XML element at the specified
     * position.
     *
     * <p> Note: Typically the object returned is a {@link Representable},
     *           but it does not have to be if the class is deserializable
     *           only (XML document created externally).
     *
     * @param  index the index of the object to return.
     * @return the object at the specified position.
     * @throws IndexOutOfBoundsException if the given index is out of range
     * 	       (<code>index &lt; 0 || index &gt;= size()</code>).
     */
    public Object get(int index) {
        return _content.get(index);
    }

    /**
     * Replaces the specified object at the specified position in this
     * XML element.
     *
     * @param  index index of the object to replace.
     * @param  object the object to be stored at the specified position.
     * @return the object previously at the specified position.
     * @throws ClassCastException if this specified object is not a
     *         {@link Representable}.
     * @throws IndexOutOfBoundsException if the specified index is out of
     *         range (<code>index &lt; 0 || index &gt;= size()</code>).
     */
    public Object set(int index, Object object) {
        if (object instanceof Representable) {
            return _content.set(index, object);
        } else {
            throw new ClassCastException(
                "Object parameter is not Representable");
        }
    }

    /**
     * Inserts the specified object at the specified position in this XML
     * element. Shifts the object currently at that position (if any) and
     * any subsequent objects to the right (adds one to their indices).
     *
     * @param  index index at which the specified object is to be inserted.
     * @param  object the object to be inserted.
     * @throws ClassCastException if this specified object is not a
     *         {@link Representable}.
     * @throws IndexOutOfBoundsException if the specified index is out of
     *         range (<code>index &lt; 0 || index &gt; size()</code>).
     */
    public void add(int index, Object object) {
        if (object instanceof Representable) {
            _content.add(index, object);
        } else {
            throw new ClassCastException(
                "Object parameter is not Representable");
        }
    }

    /**
     * Removes the object at the specified position in this list XML element.
     * Shifts any subsequent objects to the left (subtracts one from their
     * indices). Returns the object that was removed.
     *
     * @param  index the index of the object to remove.
     * @return the object previously at the specified position.
     * @throws IndexOutOfBoundsException if the specified index is out of
     *         range (<code>index &lt; 0 || index &gt;= size()</code>).
     */
    public Object remove(int index) {
	return _content.remove(index);
    }

    /**
     * Returns the number of nested element contained in this XML element.
     *
     * @return the size of this XML element.
     */
    public int size() {
        return _content.size();
    }

    /**
     * Indicates if this XML element is empty. Empty elements use an
     * alternate representation: <code>&lt;className .../&gt;</code>
     *
     * @return <code>true</code> if this element has no content;
     *         <code>false</code> otherwise.
     */
    public boolean isEmpty() {
        return _content.isEmpty();
    }

    /**
     * Resets this XML element for reuse.
     */
    void reset() {
        for (int i=0; i < _poolIndex; i++) {
            _pool[i].setLength(0);
        }
        _poolIndex = 0;
        _attributeNames.clear();
        _attributeValues.clear();
        _content.clear();
        _poolIndex = 0;
        _factoryClass = null;
    }

    /**
     * Returns a <code>StringBuffer</code> from the pool.
     *
     * @return a recycled <code>StringBuffer</code>.
     */
    private StringBuffer newStringBuffer() {
        return (_poolIndex < _pool.length) ? _pool[_poolIndex++] :
                                             newStringBuffer2();
    }
    private StringBuffer newStringBuffer2() { // Resizes.
        StringBuffer[] tmp = new StringBuffer[4 + _pool.length * 2];
        System.arraycopy(_pool, 0, tmp, 0, _pool.length);
        for (int i=_pool.length; i < tmp.length; i++) {
            tmp[i] = new StringBuffer();
        }
        _pool = tmp;
        return _pool[_poolIndex++];
    }
    private StringBuffer[] _pool = new StringBuffer[0];
    private int _poolIndex;
}