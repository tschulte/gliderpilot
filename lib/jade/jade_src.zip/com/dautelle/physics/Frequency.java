/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.physics;
import javax.units.SI;
import javax.units.Unit;

/**
 * This class represents the number of times a specified phenomenon occurs
 * within a specified interval. The system unit for this quantity is "1/s".
 * By default, instances of this quantity are showed in Hertz ("Hz").
 *
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.1, February 10, 2003
 */
public class Frequency extends Quantity {

    /**
     * Holds the system unit.
     */
    private final static Unit SYSTEM_UNIT = SI.HERTZ.getDimension();

    /**
     * Holds the factory for this class.
     */
    private final static Factory FACTORY = new Factory(SYSTEM_UNIT) {
        protected Quantity newQuantity() {
             return new Frequency();
        }
    };

    /**
     * Represents a {@link Frequency} amounting to nothing.
     */
    public final static Frequency ZERO = (Frequency) valueOf(0, SYSTEM_UNIT);

    /**
     * Default constructor (allows for derivation).
     */
    protected Frequency() {}

    /**
     * Returns the {@link Frequency} corresponding to the specified quantity.
     *
     * @param  quantity a quantity compatible with {@link Frequency}.
     * @return the specified quantity or a new {@link Frequency} instance.
     * @throws ConversionException if the current model does not allow the
     *         specified quantity to be converted to {@link Frequency}.
     */
    public static Frequency frequencyOf(Quantity quantity) {
        return (Frequency) FACTORY.quantity(quantity);
    }

    /**
     * Shows {@link Frequency} instances in the specified unit.
     *
     * @param  unit the output unit for {@link Frequency} instances.
     * @see    Quantity#getOutputUnit
     */
    public static void showAs(Unit unit) {
        FACTORY.showInstancesAs(unit);
    }
}
