/*
 * Javolution - Java(TM) Solution for Real-Time and Embedded Systems
 * Copyright (C) 2005 - Javolution (http://javolution.org/)
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software is
 * freely granted, provided that this notice is preserved.
 */
package javolution.realtime;

import javolution.JavolutionError;

/**
 * <p> This class represents a concurrent context; it is used to accelerate 
 *     execution of concurrent algorithms on multi-processors systems.</p>
 *     
 * <p> When a thread enters a concurrent context, it may execute multiple
 *     concurrent {@link Logic logics} by calling any of the 
 *     <code>ConcurrentContext.execute(logic, arg0, arg1, ...)</code> 
 *     static methods. Each logic is then executed by the current thread or by 
 *     {@link ConcurrentThread concurrent threads} based upon availability.</p>
 *     
 * <p> Only after all concurrent executions are completed, is the current 
 *     thread allowed to exit the scope of the concurrent context 
 *     (internal synchronization).</p>
 *     
 * <p> Concurrent logics always execute within a {@link PoolContext} and 
 *     do not generate garbage. {@link RealtimeObject Realtime objects} made
 *     available outside of the logic scope have therefore to be either 
 *     {@link RealtimeObject#export exported} or {@link RealtimeObject#preserve
 *     preserved}.</p>
 *     
 * <p> Concurrent contexts are easy to use, and provide automatic 
 *     load-balancing between processors with almost no overhead. Here is
 *     an example of <b>concurrent/recursive/clean</b> (no garbage generated) 
 *     implementation of the Karatsuba multiplication for large integers:<pre>
 *     
 *     public LargeInteger multiply(LargeInteger that) {
 *         if (that._size <= 1) {
 *             return multiply(that.longValue()); // Direct multiplication.
 *             
 *         } else { // Karatsuba multiplication  in O(n<sup>Log(3)</sup>)
 *             int bitLength = this.bitLength();
 *             int n = (bitLength >> 1) + (bitLength & 1);
 *             LargeInteger b = this.shiftRight(n);
 *             LargeInteger a = this.minus(b.shiftLeft(n));
 *             LargeInteger d = that.shiftRight(n);
 *             LargeInteger c = that.minus(d.shiftLeft(n));
 *             StackReference&lt;LargeInteger&gt; ac = StackReference.newInstance();
 *             StackReference&lt;LargeInteger&gt; bd = StackReference.newInstance();
 *             StackReference&lt;LargeInteger&gt; abcd = StackReference.newInstance();
 *             ConcurrentContext.enter();
 *             try { // this = a + 2^n b,   that = c + 2^n d
 *                 ConcurrentContext.execute(MULTIPLY, a, c, ac);
 *                 ConcurrentContext.execute(MULTIPLY, b, d, bd);
 *                 ConcurrentContext.execute(MULTIPLY, a.plus(b), c.plus(d), abcd);
 *             } finally {
 *                 ConcurrentContext.exit(); // Waits for all concurrent threads to complete.
 *             }
 *             // a*c + ((a+b)*(c+d)-a*c-b*d) 2^n + b*d 2^2n 
 *             return ac.get().plus(abcd.get().minus(ac.get()).minus(bd.get()).shiftLeft(n)).plus(bd.get().shiftLeft(2 * n));
 *         }
 *     }
 *     private static final Logic MULTIPLY = new Logic() {
 *         public void run(Object[] args) {
 *             LargeInteger left = (LargeInteger) args[0];
 *             LargeInteger right = (LargeInteger) args[1];
 *             StackReference result = (StackReference) args[2];
 *             result.set(left.times(right).export());  // Recursive.
 *         }
 *    };</pre>
 * 
 * <p> Finally, it should be noted that concurrent contexts ensure the same 
 *     behavior whether or not the execution is performed by the current
 *     thread or concurrent threads. In particular, the current {@link Context
 *     context} is inherited by concurrent threads and any exception raised
 *     during the concurrent logic executions is automatically propagated 
 *     to the current thread.</p>
 * 
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 3.6, September 24, 2005
 */
public class ConcurrentContext extends Context {

    /**
     * Holds the class object (cannot use .class with j2me).
     */
    private static final Class CLASS = new ConcurrentContext(0).getClass();

    /**
     * Holds the maximum number of arguments. 
     */
    private static final int ARGS_SIZE = 6;

    /**
     * Holds the pending logics.
     */
    private final Logic[] _logics;

    /**
     * Holds the pending logics arguments.
     */
    private final Object[][] _args;

    /**
     * Holds the arguments pool.
     */
    private final Object[][][] _argsPool;

    /**
     * Holds the number of pending logics.
     */
    private int _logicsCount;

    /**
     * Indicates if local concurrency is enabled.
     */
    private static final LocalReference ENABLED 
        = new LocalReference(new Boolean(true));

    /**
     * Holds the concurrency of this context (number of concurrent thread
     * executing).
     */
    private int _concurrency;

    /**
     * Holds the number of threads having completed their execution
     * (including the current thread).
     */
    private int _threadsDone;

    /**
     * Holds any error occuring during concurrent execution.
     */
    private Throwable _error;

    /**
     * Default constructor.
     */
    public ConcurrentContext() {
        this(256);
    }

    /**
     * Creates of concurrent context of specified capacity.
     * 
     * @param queueSize the maximum queue size.
     */
    private ConcurrentContext(int queueSize) {
        _logics = new Logic[queueSize];
        _args = new Object[queueSize][];
        _argsPool = new Object[queueSize][ARGS_SIZE][];
    }

    /**
     * Enters a {@link ConcurrentContext}.
     */
    public static void enter() {
        Context.enter(ConcurrentContext.CLASS);
    }

    /**
     * Exits the current {@link ConcurrentContext}. This method blocks until all
     * concurrent executions within the current context are completed.
     * Errors and exceptions raised in concurrent threads are propagated here.
     *
     * @throws java.lang.IllegalStateException if the current context 
     *         is not an instance of ConcurrentContext. 
     * @throws ConcurrentException propagates any error or exception raised
     *         during the execution of a concurrent logic.
     */
    public static void exit() {
        Context.exit(ConcurrentContext.CLASS);
    }

    // Implements Context abstract method.
    protected void enterAction() {
        inheritedPoolContext = null; // Overrides inherited.
        PoolContext outer = getOuter().inheritedPoolContext;
        if (outer != null) {
            outer.setInUsePoolsLocal(false);
        }
    }

    // Implements Context abstract method.
    protected void exitAction() {
        flush(); // Executes remaining logics.

        // Propagates any concurrent error to current thread.
        if (_error != null) {
            ConcurrentException error = new ConcurrentException(_error);
            _error = null; // Resets error flag.
            throw error;
        }
    }

    /**
     * Enables/disables {@link LocalContext local} concurrency.
     * 
     * @param enabled <code>true</code> if concurrency is locally enabled;
     *        <code>false</code> otherwise.
     */
    public static void setEnabled(boolean enabled) {
        ENABLED.set(new Boolean(enabled));
    }

    /**
     * Indicates if concurrency is {@link LocalContext locally} enabled
     * (default <code>true</code>).
     * 
     * @return <code>true</code> if concurrency is locally enabled;
     *         <code>false</code> otherwise.
     */
    public static boolean isEnabled() {
        return ((Boolean) ENABLED.get()).booleanValue();
    }

    /**
     * Executes the specified logic by a {@link ConcurrentThread} when possible.
     * The specified logic is always executed within a {@link PoolContext}
     * and inherits the context of the parent thread. Any exception or error
     * during execution will be propagated to the current thread upon 
     * {@link #exit} of the concurrent context.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     */
    public static void execute(Logic logic) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        ctx._args[ctx._logicsCount] = Logic.NO_ARG;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified argument.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the logic argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(1);
        args[0] = arg0;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified two arguments.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the first argument.
     * @param  arg1 the second argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0, Object arg1) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(2);
        args[0] = arg0;
        args[1] = arg1;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified three arguments.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the first argument.
     * @param  arg1 the second argument.
     * @param  arg2 the third argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0, Object arg1,
            Object arg2) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(3);
        args[0] = arg0;
        args[1] = arg1;
        args[2] = arg2;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified four arguments.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the first argument.
     * @param  arg1 the second argument.
     * @param  arg2 the third argument.
     * @param  arg3 the fourth argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0, Object arg1,
            Object arg2, Object arg3) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(4);
        args[0] = arg0;
        args[1] = arg1;
        args[2] = arg2;
        args[3] = arg3;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified five arguments.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the first argument.
     * @param  arg1 the second argument.
     * @param  arg2 the third argument.
     * @param  arg3 the fourth argument.
     * @param  arg4 the fifth argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0, Object arg1,
            Object arg2, Object arg3, Object arg4) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(5);
        args[0] = arg0;
        args[1] = arg1;
        args[2] = arg2;
        args[3] = arg3;
        args[4] = arg4;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Executes the specified logic with the specified six arguments.
     * 
     * @param  logic the logic to execute concurrently when possible.
     * @param  arg0 the first argument.
     * @param  arg1 the second argument.
     * @param  arg2 the third argument.
     * @param  arg3 the fourth argument.
     * @param  arg4 the fifth argument.
     * @param  arg5 the sixth argument.
     * @throws ClassCastException if the current context is not a
     *         {@link ConcurrentContext}.
     * @see    #execute(ConcurrentContext.Logic)
     */
    public static void execute(Logic logic, Object arg0, Object arg1,
            Object arg2, Object arg3, Object arg4, Object arg5) {
        ConcurrentContext ctx = (ConcurrentContext) currentContext();
        if (ctx._logicsCount >= ctx._logics.length) {
            ctx.flush();
        }
        Object[] args = ctx.getArgs(6);
        args[0] = arg0;
        args[1] = arg1;
        args[2] = arg2;
        args[3] = arg3;
        args[4] = arg4;
        args[5] = arg5;
        ctx._logics[ctx._logicsCount++] = logic;
    }

    /**
     * Stores the first error occuring during a concurrent execution.
     * 
     * @param error an error raised while executing some concurrent logic.
     */
    synchronized void setError(Throwable error) {
        if (_error == null) { // First error.
            _error = error;
        } // Else ignores subsequent errors.
    }

    /**
     * Executes the next pending logic.
     * 
     * @return <code>true</code> if some logics has been executed;
     *         <code>false</code> if there is no pending logic to execute.
     */
    boolean executeNext() {
        int index;
        synchronized (this) {
            if (_logicsCount > 0) {
                index = --_logicsCount;
            } else {
                _threadsDone++;
                this.notify();
                return false;
            }
        }
        try {
            Object[] args = _args[index];
            _logics[index].run(args);
            _logics[index] = null;
            for (int j = args.length; j > 0;) {
                args[--j] = null;
            }
        } catch (Throwable error) {
            setError(error);
        }
        return true;
    }

    /**
     * Executes all pending logics (blocking).
     */
    private void flush() {
        // Current thread enters inner pool context in order to ensure
        // that concurrent threads have no access to its local pools.
        PoolContext.enter();
        try {
            _concurrency = ConcurrentContext.isEnabled() ? ConcurrentThread
                    .execute(this) : 0;
            while (executeNext()) {
                ((PoolContext) Context.currentContext()).recyclePools();
            }
            synchronized (this) {
                while (_threadsDone <= _concurrency) {
                    this.wait();
                } // Exit when _threadsDone = _concurrency + 1 (current thread)
            }
        } catch (InterruptedException e) {
            throw new JavolutionError(e);
        } finally {
            _threadsDone = 0;
            PoolContext.exit();
        }
    }

    /**
     * Gets the next arguments array.
     * 
     * @param  length the array length (> 0).
     * @return the next arguments array available.
     */
    private Object[] getArgs(int length) {
        Object[] args = _argsPool[_logicsCount][length - 1];
        if (args == null) {
            args = new Object[length];
            _argsPool[_logicsCount][length - 1] = args;
        }
        _args[_logicsCount] = args;
        return args;
    }


    /**
     * <p> This abstract class represents some parameterized code which may be
     *     executed concurrently.</p>
     */
    public static abstract class Logic implements Runnable {

        /**
         * Executes this logic with no arguments.
         */
        public final void run() {
            run(NO_ARG);
        }

        private static final Object[] NO_ARG = new Object[0];

        /**
         * Executes this logic with the specified arguments.
         * 
         * @param args the arguments. The number of arguments depends upon
         *        the <code>ConcurrentContext.execute</code> method which 
         *        has been called (e.g. if {@link ConcurrentContext#execute(
         *        ConcurrentContext.Logic, Object, Object)},
         *        has been called, then <code>(args.length == 2)</code>).
         */
        public abstract void run(Object[] args);
    }

}