/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.physics;
import javax.units.SI;
import javax.units.Unit;

/**
 * This class represents the speed of data-transmission.
 * The system unit for this quantity is "bit/s".
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.1, February 10, 2003
 */
public class DataRate extends Quantity {

    /**
     * Holds the system unit.
     */
    private final static Unit SYSTEM_UNIT = SI.BIT.divide(SI.SECOND);

    /**
     * Holds the factory for this class.
     */
    private final static Factory FACTORY = new Factory(SYSTEM_UNIT) {
        protected Quantity newQuantity() {
             return new DataRate();
        }
    };

    /**
     * Represents a {@link DataRate} amounting to nothing.
     */
    public final static DataRate ZERO = (DataRate) valueOf(0, SYSTEM_UNIT);

    /**
     * Default constructor (allows for derivation).
     */
    protected DataRate() {}

    /**
     * Returns the {@link DataRate} corresponding to the specified quantity.
     *
     * @param  quantity a quantity compatible with {@link DataRate}.
     * @return the specified quantity or a new {@link DataRate} instance.
     * @throws ConversionException if the current model does not allow the
     *         specified quantity to be converted to {@link DataRate}.
     */
    public static DataRate dataRateOf(Quantity quantity) {
        return (DataRate) FACTORY.quantity(quantity);
    }

    /**
     * Shows {@link DataRate} instances in the specified unit.
     *
     * @param  unit the output unit for {@link DataRate} instances.
     * @see    Quantity#getOutputUnit
     */
    public static void showAs(Unit unit) {
        FACTORY.showInstancesAs(unit);
    }
}
