/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.math;

/**
 * <p> Thrown when an operation is performed upon two matrices whose dimensions
 *     disagree.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.0, February 29, 2003
 */
public class MatrixDimensionException extends RuntimeException {

    /**
     * Constructs a {@link MatrixDimensionException} with no detail message.
     */
    public MatrixDimensionException() {
        super();
    }

    /**
     * Constructs a {@link MatrixDimensionException} with the specified message.
     *
     * @param  message the message.
     */
    public MatrixDimensionException(String message) {
        super(message);
    }
}