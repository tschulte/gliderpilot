/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * This class is public domain (not copyrighted).
 */
package com.dautelle.util;

import com.dautelle.realtime.ArrayPool;
import com.dautelle.realtime.ObjectFactory;
import com.dautelle.realtime.ObjectPool;
import com.dautelle.realtime.RealtimeObject;

/**
 * <p> This class represents a {@link com.dautelle.realtime.Realtime Real-Time}
 *     String.</p>
 * <p> This class is very much like <code>java.lang.String</code>; but a lot
 *     faster (e.g. string concatenation is as fast as with
 *     <code>java.lang.StringBuffer</code>) and more flexible as it allows for
 *     search, concatenation and comparison with any <code>CharSequence</code>
 *     such as itself, <code>java.lang.String</code> or
 *     <code>java.lang.StringBuffer</code>.</p>
 * <p> Instances of this class are immutable (but like any real-time object,
 *     instances allocated in a pool context must be {@link #export exported}
 *     if referenced after exiting the pool context).</p>
 * <p> In case of successive concatenations, it may be advantageous to start 
 *     with a {@link FastString} whose character buffer is capable of holding 
 *     the final concatenated string (ref. {@link #newInstance(int capacity)}),
 *     this to avoid unnecessary character buffer allocation. Then 
 *     {@link FastString} can advantageously be used in place of 
 *     <code>java.lang.StringBuffer(capacity)</code> (as fast, but immutable).
 *     For example:<pre>
 *         // Constructs an immutable fullName.
 *         FastString fullName = FastString.newInstance(64). 
 *             concat(firstName).concat(" ").concat(lastName);</pre></p>
 * <p> Finally, as for any <code>CharSequence</code>, parsing to primitive types
 *     can be achieved using the {@link com.dautelle.util.TypeFormat} utility
 *     class.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, January 18, 2004
 */
public final class FastString extends RealtimeObject implements CharSequence,
        Comparable {

    /**
     * Holds the empty string.
     */
    public static final FastString EMPTY = new FastString("");

    /**
     * Holds the character used to mark the end of the data being shared
     * (invalid 16-bits UTF character).
     */
    private static final char END_DATA = '\uffff';

    /**
     * Holds the shared character data for this real-time String.
     */
    private char[] _data;

    /**
     * Holds the index of the first character of this real-time String.
     */
    private int _first;

    /**
     * Holds the length of this real-time String.
     */
    private int _length;

    /**
     * Caches the hash code for this real-time String.
     */
    private int _hashCode;

    /**
     * Default constructor.
     */
    private FastString() {
    }

    /**
     * Creates a constant {@link FastString} always allocated on the heap,
     * corresponding to the specified character sequence. This method is
     * typically used to define static {@link FastString} constants.
     *
     * @param  chars the <code>CharSequence</code> source.
     */
    public FastString(CharSequence chars) {
        int length = chars.length();
        _data = new char[length + 1];
        for (int i = 0; i < length; i++) {
            _data[i] = chars.charAt(i);
        }
        _data[length] = END_DATA;
        _first = 0;
        _length = length;
    }

    /**
     * Returns an empty {@link FastString} having an internal data array of
     * specified capacity.
     *
     * <p> Note: Despite of their immutability, strings may share the same data
     *           array (e.g. {@link #substring}). In case of successive
     *           concatenations, it may be advantageous to start with a
     *           {@link FastString} capable of holding the final concatenated
     *           string. Then all intermediate strings share the same
     *           data array (they are substrings) and no additional data array
     *           need to be allocated. Doing so, {@link FastString} behave very
     *           much like <code>StringBuffer</code> (as fast) but still
     *           maintain their immutability requirement.</p>
     *
     * @param  capacity the maximum number of characters during concatenation;
     *         beyond which new allocations of internal data arrays may occur.
     * @return an empty real-time string of specified capacity.
     */
    public static FastString newInstance(int capacity) {
        FastString str = (FastString) FACTORY.object();
        str._data = (char[]) ArrayPool.charArray(capacity + 1).next();
        str._data[0] = END_DATA;
        str._first = 0;
        str._length = 0;
        return str;
    }

    /**
     * Returns the {@link FastString} that contains the characters from
     * the specified subarray of characters.
     *
     * @param  data the source of the characters.
     * @param  first the index of the first character.
     * @param  length the length of the subarray.
     * @return the corresponding real-time string.
     */
    public static FastString valueOf(char data[], int first, int length) {
        FastString str = newInstance(length);
        System.arraycopy(data, first, str._data, 0, length);
        str._data[length] = END_DATA;
        str._length = length;
        return str;
    }

    /**
     * Returns the {@link FastString} representing the specified character
     * sequence.
     *
     * @param  chars the <code>CharSequence</code> source.
     * @return the corresponding real-time string.
     */
    public static FastString valueOf(CharSequence chars) {
        int length = chars.length();
        FastString str = newInstance(length);
        for (int i = 0; i < length; i++) {
            str._data[i] = chars.charAt(i);
        }
        str._data[length] = END_DATA;
        str._length = length;
        return str;
    }

    /**
     * Returns the {@link FastString} representing the <code>boolean</code>
     * argument.
     *
     * @param  b a <code>boolean</code>.
     * @return if the argument is <code>true</code>, a string equal to
     *          <code>"true"</code> is returned; otherwise, a string equal to
     *          <code>"false"</code> is returned.
     * @see    com.dautelle.util.TypeFormat#parseBoolean
     */
    public static FastString valueOf(boolean b) {
        return b ? TRUE : FALSE;
    }

    private final static FastString TRUE = new FastString("true");

    private final static FastString FALSE = new FastString("false");

    /**
     * Returns the {@link FastString} representing the <code>char</code>
     * argument.
     *
     * @param  c a <code>char</code>.
     * @return a string of length <code>1</code> containing
     *         as its single character the argument <code>c</code>.
     */
    public static FastString valueOf(char c) {
        FastString str = newInstance(1);
        str._data[0] = c;
        str._data[1] = END_DATA;
        str._length = 1;
        return str;
    }

    /**
     * Returns the {@link FastString} representing the specified <code>int</code>
     * argument (decimal representation).
     *
     * @param  i the <code>int</code> number.
     * @return the decimal representation of the <code>int</code> argument.
     * @see    com.dautelle.util.TypeFormat#parseInt
     */
    public static FastString valueOf(int i) {
        ObjectPool stringBufferPool = STRING_BUFFER_FACTORY.currentPool();
        StringBuffer sb = (StringBuffer) stringBufferPool.next();
        sb.setLength(0);
        TypeFormat.format(i, sb);
        stringBufferPool.recycle(sb);
        return valueOf(sb); // Safe, sb not reused yet.
    }

    /**
     * Returns the {@link FastString} representing the specified <code>long</code>
     * argument (decimal representation).
     *
     * @param  l the <code>long</code> number.
     * @return the decimal representation of the <code>long</code> argument.
     * @see    com.dautelle.util.TypeFormat#parseLong
     */
    public static FastString valueOf(long l) {
        ObjectPool stringBufferPool = STRING_BUFFER_FACTORY.currentPool();
        StringBuffer sb = (StringBuffer) stringBufferPool.next();
        sb.setLength(0);
        TypeFormat.format(l, sb);
        stringBufferPool.recycle(sb);
        return valueOf(sb); // Safe, sb not reused yet.
    }

    /**
     * Returns the {@link FastString} representing the specified
     * <code>double</code> argument. The error is assumed to be
     * the intrinsic <code>double</code> error (64 bits IEEE 754 format).
     *
     * @param  d the <code>double</code> number.
     * @return <code>valueOf(d, 0)</code>
     * @see    com.dautelle.util.TypeFormat#parseDouble
     */
    public static FastString valueOf(double d) {
        ObjectPool stringBufferPool = STRING_BUFFER_FACTORY.currentPool();
        StringBuffer sb = (StringBuffer) stringBufferPool.next();
        sb.setLength(0);
        TypeFormat.format(d, sb);
        stringBufferPool.recycle(sb);
        return valueOf(sb); // Safe, sb not reused yet.
    }

    /**
     * Returns the length of this {@link FastString}.
     *
     * @return the number of characters (16-bits Unicode) composing this
     *         real-time string.
     */
    public int length() {
        return _length;
    }

    /**
     * Returns the character at the specified index.
     *
     * @param  index the index of the character starting at <code>0</code>.
     * @return the character at the specified index of this real-time string.
     * @throws IndexOutOfBoundsException  if the <code>index</code> is not
     *         in the <code>[0, length() - 1]</code> range.
     */
    public char charAt(int index) {
        if ((index >= 0) && (index < _length)) {
            return _data[_first + index];
        } else {
            throw new IndexOutOfBoundsException("index: " + index);
        }
    }

    /**
     * Returns a sub-string of this {@link FastString}.
     *
     * <p> Note: For performance reason, the sub-string being returned
     *           references this {@link FastString} character array.
     *           If this {@link FastString} is short-lived and the sub-string
     *           is long-lived, it is recommended to perform a copy  of
     *           the sub-string to avoid that small sub-strings takes up a lot
     *           of memory space which cannot be garbage collected.</p>
     *
     * @param  start the index of the first character inclusive.
     * @return the substring starting at the specified position.
     * @throws IndexOutOfBoundsException  if the <code>start</code> index
     *         is not in the <code>[0, length()]</code> range.
     */
    public FastString substring(int start) {
        return substring(start, _length);
    }

    /**
     * Returns a sub-string of this {@link FastString}.
     *
     * <p> Note: For performance reason, the sub-string being returned
     *           references this {@link FastString} character array.
     *           If this {@link FastString} is short-lived and the sub-string
     *           is long-lived, it is recommended to perform a copy of
     *           the sub-string to avoid that small sub-strings takes up a lot
     *           of memory space which cannot be garbage collected.</p>
     *
     * @param  start the index of the first character inclusive.
     * @param  end the index of the last character exclusive.
     * @return the substring starting at the specified <code>start</code>
     *         position and ending just before the specified <code>end</code>
     *         position.
     * @throws IndexOutOfBoundsException  if the <code>start</code> index
     *         is not in the <code>[0, length()]</code> range.
     * @throws IndexOutOfBoundsException  if the <code>end</code> index
     *         is not in the <code>[start, length()]</code> range.
     */
    public FastString substring(int start, int end) {
        if (start >= 0) {
            if (end <= _length) {
                if (start <= end) {
                    FastString str = (FastString) FACTORY.object();
                    str._data = _data;
                    str._first = _first + start;
                    str._length = end - start;
                    return str;
                } else {
                    throw new IndexOutOfBoundsException("index: "
                            + (end - start));
                }
            } else {
                throw new IndexOutOfBoundsException("index: " + end);
            }
        } else {
            throw new IndexOutOfBoundsException("index: " + start);
        }
    }

    /**
     * Returns a new character sequence that is a subsequence of this sequence.
     * Equivalent to {@link #substring(int, int)}
     *
     * @param  start the index of the first character inclusive.
     * @param  end the index of the last character exclusive.
     * @return the character sequence starting at the specified
     *         <code>start</code> position and ending just before the specified
     *         <code>end</code> position.
     * @throws IndexOutOfBoundsException  if the <code>start</code> index
     *         is not in the <code>[0, length()]</code> range.
     * @throws IndexOutOfBoundsException  if the <code>end</code> index
     *         is not in the <code>[start, length()]</code> range.
     */
    public CharSequence subSequence(int start, int end) {
        return this.substring(start, end);
    }

    /**
     * Copies the characters from this {@link FastString} into the destination
     * character array.
     *
     * @param  start the index of the first character in the string to copy.
     * @param  end the index after the last character in the string to copy.
     * @param  dest the destination array.
     * @param  destPos the start offset in the destination array.
     * @throws StringIndexOutOfBoundsException  if the <code>start</code> index
     *         is not in the <code>[0, length()]</code> range.
     * @throws StringIndexOutOfBoundsException  if the <code>end</code> index
     *         is not in the <code>[start, length()]</code> range.
     */
    public void getChars(int start, int end, char dest[], int destPos) {
        if (start >= 0) {
            if (end <= _length) {
                if (start <= end) {
                    System.arraycopy(_data, _first + start, dest, destPos, end
                            - start);
                } else {
                    throw new IndexOutOfBoundsException("index: "
                            + (end - start));
                }
            } else {
                throw new StringIndexOutOfBoundsException("index: " + end);
            }
        } else {
            throw new StringIndexOutOfBoundsException("index: " + start);
        }
    }

    /**
     * Returns the index within this {@link FastString} of the first occurrence
     * of the specified character sequence searching forward.
     *
     * @param  chars a character sequence.
     * @return the index of the first character of the character sequence found;
     *         or <code>-1</code> if the character sequence is not found.
     */
    public int indexOf(CharSequence chars) {
        return indexOf(chars, 0);
    }

    /**
     * Returns the index within this {@link FastString} of the first occurrence
     * of the specified character sequence searching forward from the specified
     * index.
     *
     * @param  chars a character sequence.
     * @param  fromIndex the index to start the search from.
     * @return the index in the range <code>[fromIndex, length()-chars.length()]
     *         </code> or <code>-1</code> if the character sequence is not
     *         found.
     */
    public int indexOf(CharSequence chars, int fromIndex) {
        int charsLength = chars.length();
        fromIndex = Math.max(0, fromIndex);
        if (charsLength != 0) { // At least one character to search for.
            char firstChar = chars.charAt(0);
            int last = _first + _length - charsLength;
            for (int i = _first + fromIndex; i <= last; i++) {
                if (_data[i] == firstChar) {
                    boolean match = true;
                    for (int j = 1; j < charsLength; j++) {
                        if (_data[i + j] != chars.charAt(j)) {
                            match = false;
                            break;
                        }
                    }
                    if (match) { return i - _first; }
                }
            }
            return -1;
        } else {
            return Math.min(_length, fromIndex);
        }
    }

    /**
     * Returns the index within this {@link FastString} of the last occurrence of
     * the specified character sequence searching backward.
     *
     * @param  chars a character sequence.
     * @return the index of the first character of the character sequence found;
     *         or <code>-1</code> if the character sequence is not found.
     */
    public int lastIndexOf(CharSequence chars) {
        return indexOf(chars, _length);
    }

    /**
     * Returns the index within this {@link FastString} of the last occurrence of
     * the specified character sequence searching backward from the specified
     * index.
     *
     * @param  chars a character sequence.
     * @param  fromIndex the index to start the backward search from.
     * @return the index in the range <code>[0, fromIndex]</code> or
     *         <code>-1</code> if the character sequence is not found.
     */
    public int lastIndexOf(CharSequence chars, int fromIndex) {
        int charsLength = chars.length();
        fromIndex = Math.min(_length - chars.length(), fromIndex);
        if (charsLength != 0) { // At least one character to search for.
            char firstChar = chars.charAt(0);
            for (int i = _first + fromIndex; i >= _first; i--) {
                if (_data[i] == firstChar) {
                    boolean match = true;
                    for (int j = 1; j < charsLength; j++) {
                        if (_data[i + j] != chars.charAt(j)) {
                            match = false;
                            break;
                        }
                    }
                    if (match) { return i - _first; }
                }
            }
            return -1;
        } else {
            return Math.max(-1, fromIndex);
        }
    }

    /**
     * Indicates if this {@link FastString} starts with the specified prefix.
     *
     * @param  prefix the prefix.
     * @return <code>true</code> if the character sequence represented by the
     *         argument is a prefix of the character sequence represented by
     *         this string; <code>false</code> otherwise.
     */
    public boolean startsWith(CharSequence prefix) {
        return startsWith(prefix, 0);
    }

    /**
     * Indicates if this {@link FastString} ends with the specified suffix.
     *
     * @param  suffix the suffix.
     * @return <code>true</code> if the character sequence represented by the
     *         argument is a suffix of the character sequence represented by
     *         this string; <code>false</code> otherwise.
     */
    public boolean endsWith(CharSequence suffix) {
        return startsWith(suffix, _length - suffix.length());
    }

    /**
     * Indicates if this {@link FastString} starts with the specified prefix
     * at the specified index.
     *
     * @param  prefix the prefix.
     * @param  index the index of the prefix location in this string.
     * @return <code>this.substring(index).startsWith(prefix)</code>
     */
    public boolean startsWith(CharSequence prefix, int index) {
        if ((index >= 0) && (index <= (_length - prefix.length()))) {
            int offset = _first + index;
            for (int i = 0; i < prefix.length(); i++) {
                if (prefix.charAt(i) != _data[i + offset]) { return false; }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Concatenates the specified character sequence to the end of this
     * {@link FastString}.
     *
     * @param  chars the character sequence that is concatenated.
     * @return a real-time string that represents the concatenation of this
     *         string's characters followed by the specified sequence of
     *         character.
     */
    public FastString concat(CharSequence chars) {
        FastString str = (FastString) FACTORY.object();
        int newLength = this._length + chars.length();

        // Try to append if possible.
        if ((_first + newLength) < _data.length) {
            // Enough room.
            synchronized (_data) {
                int thisEnd = _first + _length;
                if (_data[thisEnd] == END_DATA) {
                    // Trailing space available: Append.
                    if (chars instanceof FastString) {
                        FastString that = (FastString) chars;
                        System.arraycopy(that._data, that._first, _data,
                                thisEnd, that._length);
                    } else {
                        for (int i = 0; i < chars.length(); i++) {
                            _data[thisEnd + i] = chars.charAt(i);
                        }
                    }
                    _data[thisEnd + chars.length()] = END_DATA;
                    str._data = _data;
                    str._first = _first;
                    str._length = newLength;
                    return str;
                }
            }
        }

        // Allocate a new char array.
        char[] tmp = (char[]) ArrayPool.charArray(newLength + 1).next();
        System.arraycopy(_data, _first, tmp, 0, _length);
        if (chars instanceof FastString) {
            FastString that = (FastString) chars;
            System.arraycopy(that._data, that._first, tmp, _length,
                    that._length);
        } else {
            for (int i = 0; i < chars.length(); i++) {
                tmp[_length + i] = chars.charAt(i);
            }
        }
        str._data = tmp;
        str._data[newLength] = END_DATA;
        str._first = 0;
        str._length = newLength;
        return str;
    }

    /**
     * Returns a {@link FastString} where all occurrences of
     * <code>oldChar</code> have been replaced with <code>newChar</code>.
     *
     * @param  oldChar the old character.
     * @param  newChar the new character.
     * @return this {@link FastString} if it does not contain any occurence of
     *         the specifed <code>oldChar</code> or a string derived from this
     *         string by replacing every occurrence of <code>oldChar</code>
     *         with <code>newChar</code>.
     */
    public FastString replace(char oldChar, char newChar) {
        int last = _first + _length;
        for (int i = _first; i < last; i++) {
            if (_data[i] == oldChar) { // Found at least one.
                FastString str = valueOf(_data, _first, _length); // Copy.
                for (int j = i - _first; j < str._length; j++) {
                    if (str._data[j] == oldChar) {
                        str._data[j] = newChar;
                    }
                }
                return str;
            }
        }
        return this;
    }

    /**
     * Returns a copy of this {@link FastString}, with leading and trailing
     * whitespace omitted.
     *
     * @return a copy of this string with leading and trailing white
     *          space removed, or this string if it has no leading or
     *          trailing white space.
     */
    public FastString trim() {
        int first = _first; // First character index.
        int last = _first + _length - 1; // Last character index.
        while ((first <= last) && (_data[first] <= ' ')) {
            first++;
        }
        while ((last >= first) && (_data[last] <= ' ')) {
            last--;
        }
        int newLength = last - first + 1;
        return (newLength == _length) ? this : substring(first - _first, last
                - _first + 1);
    }

    /**
     * Returns the text representation of this {@link FastString}.
     * The <code>String</code> returned is always allocated on the heap
     * and can safely be referenced elsewhere.
     *
     * @return the <code>java.lang.String</code> for this {@link FastString}.
     */
    public String toString() {
        return new String(_data, _first, _length);
    }

    /**
     * Compares this {@link FastString} against the specified object.
     *
     * <p> Note: Unfortunately, due to the current (JDK 1.4.1) implementation
     *          of <code>java.lang.String</code> and <code>
     *          java.lang.StringBuffer</code>, this method is not symmetric.</p>
     *
     * @param  that the object to compare with.
     * @return <code>true</code> if both objects are <code>CharSequence</code>
     *         and they represent the same sequence;
     *         <code>false</code> otherwise.
     */
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        } else if (that instanceof CharSequence) {
            CharSequence chars = (CharSequence) that;
            if (_length == chars.length()) {
                for (int i = 0, j = _first; i < _length; i++) {
                    if (_data[j++] != chars.charAt(i)) { return false; }
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Compares this {@link FastString} to the specified character sequence
     * ignoring case considerations. The two character sequence are considered
     * equal ignoring case if they are of the same length, and corresponding
     * characters in the two strings are equal ignoring case.
     *
     * @param  chars the <code>CharSequence</code> to compare this
     *         {@link FastString} against.
     * @return <code>true</code> if the argument is not <code>null</code>
     *         and the character sequences are equal, ignoring case;
     *         <code>false</code> otherwise.
     * @see     #equals(Object)
     */
    public boolean equalsIgnoreCase(CharSequence chars) {
        if (this == chars) {
            return true;
        } else {
            if (_length == chars.length()) {
                for (int i = 0, j = _first; i < _length; i++) {
                    char u1 = Character.toUpperCase(_data[j++]);
                    char u2 = Character.toUpperCase(chars.charAt(i));
                    if ((u1 != u2)
                            && (Character.toLowerCase(u1) != Character
                                    .toLowerCase(u2))) { return false; }
                }
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * Returns the hash code for this real-time string.
     *
     * <p> Note: Returns the same hashCode as <code>java.lang.String</code>
     *           (consistent with {@link #equals})</p>
     *
     * @return the hash code value.
     */
    public int hashCode() {
        int h = _hashCode;
        if (h == 0) {
            for (int i = 0, j = _first; i < _length; i++) {
                h = 31 * h + _data[j++];
            }
            _hashCode = h;
        }
        return h;
    }

    /**
     * Compares this {@link FastString} to another object.
     * If the object is a <code>CharSequence</code> this function behaves like
     * {@link #compareTo(CharSequence)}. Otherwise, it throws a
     * <code>ClassCastException</code>.
     *
     * @param   that the object to be compared.
     * @return  <code>compareTo((CharSequence) that)</code>
     * @throws  ClassCastException if the specifed object is not a
     *          <code>CharSequence</code>.
     */
    public int compareTo(Object that) {
        return compareTo((CharSequence) that);
    }

    /**
     * Compares this {@link FastString} with the specified character sequence
     * lexicographically.
     *
     * @param   chars the character sequence to be compared with.
     * @return  the value <code>0</code> if the argument character sequence is
     *          equal to this string; a value less than <code>0</code> if this
     *          string is lexicographically less than the character sequence
     *          argument; and a value greater than <code>0</code> if this string
     *          is lexicographically greater than the character sequence
     *          argument.
     * @throws  ClassCastException if the specifed object is not a
     *          <code>CharSequence</code>.
     */
    public int compareTo(CharSequence chars) {
        char thisData[] = this._data;
        int i = this._first;
        int j = 0;
        int n = Math.min(this._length, chars.length());
        while (n-- != 0) {
            char c1 = thisData[i++];
            char c2 = chars.charAt(j++);
            if (c1 != c2) { return c1 - c2; }
        }
        return this._length - chars.length();
    }

    //////////////
    // Realtime // 
    //////////////

    // Holds a StringBuffer factory used during number formatting.
    private static final ObjectFactory STRING_BUFFER_FACTORY = new ObjectFactory() {

        public Object create() {
            return new StringBuffer(26); // Maximum number of characters
        } // for "double" representations.
    };

    // Holds the FastString factory.
    private static final Factory FACTORY = new Factory() {
        public Object create() {
            return new FastString();
        }
        public void cleanup(Object obj) {
            ((FastString)obj)._data = null;
        }
    };

    // Overrides.
    public Object export() {
        if (isLocalObject()) {
            super.export();
            _data = (char[]) ArrayPool.outerCopy(_data, _first, _length + 1);
            _data[_length] = END_DATA;
            _first = 0;
        }  // Else non-local object cannot refer to local object.
        return this;
    }

    // Overrides.
    public Object toHeap() {
        if (isPoolObject()) {
            super.toHeap();
            _data = (char[]) ArrayPool.heapCopy(_data, _first, _length + 1);
            _data[_length] = END_DATA;
            _first = 0;
        } // Else heap objects can only refer to heap objects.
        return this;
    }

}