/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.math;

import com.dautelle.util.TypeFormat;
import com.dautelle.xml.Representable;
import com.dautelle.xml.XmlElement;

/**
 * <p> This class contains wrappers to Java numerics types and classes.</p>
 * <p> The numbers defined are all {@link Operable}, 
 *     {@link com.dautelle.realtime.Realtime Realtime}
 *      and {@link Representable XML Representable}.</p> 
 * <p> They are no substitute for the {@link LargeInteger}, 
 *     {@link Rational} and {@link Real} classes, but they can be useful 
 *     when precision is not an issue (e.g. {@link Float64}) or as  
 *     real-time alternates to <code>java.lang.Integer</code>, 
 <code>java.lang.Long</code>, <code>java.lang.Float</code> or 
 *     <code>java.lang.Double</code>.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, February 1, 2004
 */
public class Numerics {

    /**
     * Default constructor (private for container class).
     */
    private Numerics() {
    }

    /**
     * <p> This class represents a 32 bits floating point number.</p>
     *
     * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
     * @version 5.1, August 27, 2003
     */
    public static final class Float32 extends RealtimeNumber implements
            Comparable, Operable, Representable {

        /**
         * Holds the factory used to produce {@link Numerics.Float32} instances.
         */
        private static final Factory FACTORY = new Factory() {

            public Object create() {
                return new Float32();
            }
        };

        /**
         * The 32 bits floating point representing zero.
         */
        public static final Float32 ZERO = (Float32) valueOf(0.0f).toHeap();

        /**
         * The 32 bits float one.
         */
        public static final Float32 ONE = (Float32) valueOf(1.0f).toHeap();

        /**
         * The associated double value.
         */
        private float _value;

        /**
         * Default constructor.
         */
        private Float32() {
        }

        /**
         * Returns the 32 bits float of specified <code>float</code> value.
         *
         * @param  floatValue the <code>float</code> value for this number.
         * @return the corresponding number.
         * @see    #doubleValue()
         */
        public static Float32 valueOf(float floatValue) {
            Float32 r = (Float32) FACTORY.object();
            r._value = floatValue;
            return r;
        }

        /**
         * Returns the 32 bits float for the specified character sequence.
         *
         * @param  chars the character sequence.
         * @return the corresponding number.
         */
        public static Float32 valueOf(CharSequence chars) {
            Float32 r = (Float32) FACTORY.object();
            r._value = TypeFormat.parseFloat(chars);
            return r;
        }

        /**
         * XML factory method.
         *
         * @param  xml the XML element describing the 32 bits float to return
         *         (e.g. <code>&lt;math:Float32 value="0.0"/&gt;</code>).
         * @return a number as described by the specified xml element.
         */
        public static Float32 valueOf(XmlElement xml) {
            Float32 r = (Float32) FACTORY.object();
            r._value = xml.getAttribute("value", 0.0f);
            return r;
        }

        /**
         * Indicates if this 32 bits float is infinite.
         *
         * @return <code>true</code> if this float is infinite;
         *         <code>false</code> otherwise.
         */
        public boolean isInfinite() {
            return Float.isInfinite(_value);
        }

        /**
         * Indicates if this 32 bits Float is not a number.
         *
         * @return <code>true</code> if this float is NaN;
         *         <code>false</code> otherwise.
         */
        public boolean isNaN() {
            return Float.isNaN(_value);
        }

        /**
         * Returns the negation of this number.
         *
         * @return <code>-this</code>.
         */
        public Float32 negate() {
            Float32 r = (Float32) FACTORY.object();
            r._value = -this._value;
            return r;
        }

        /**
         * Returns the sum of this number with the one specified.
         *
         * @param  that the number to be added.
         * @return <code>this + that</code>.
         */
        public Float32 add(Float32 that) {
            Float32 r = (Float32) FACTORY.object();
            r._value = this._value + that._value;
            return r;
        }

        /**
         * Returns the difference between this number and the one specified.
         *
         * @param  that the number to be subtracted.
         * @return <code>this - that</code>.
         */
        public Float32 subtract(Float32 that) {
            Float32 r = (Float32) FACTORY.object();
            r._value = this._value - that._value;
            return r;
        }

        /**
         * Returns the product of this number with the one specified.
         *
         * @param  that the multiplier.
         * @return <code>this * that</code>.
         */
        public Float32 multiply(Float32 that) {
            Float32 r = (Float32) FACTORY.object();
            r._value = this._value * that._value;
            return r;
        }

        /**
         * Returns the inverse of this number.
         *
         * @return <code>1 / this</code>.
         */
        public Float32 inverse() {
            Float32 r = (Float32) FACTORY.object();
            r._value = 1.0f / this._value;
            return r;
        }

        /**
         * Returns this number divided by the one specified.
         *
         * @param  that the divisor.
         * @return <code>this / that</code>.
         */
        public Float32 divide(Float32 that) {
            Float32 r = (Float32) FACTORY.object();
            r._value = this._value / that._value;
            return r;
        }

        /**
         * Returns the absolute value of this number.
         *
         * @return <code>abs(this)</code>.
         */
        public Float32 abs() {
            Float32 r = (Float32) FACTORY.object();
            r._value = Math.abs(this._value);
            return r;
        }

        /**
         * Appends the decimal text representation of this number 
         * to the <code>StringBuffer</code> argument.
         *
         * @param  sb the <code>StrinBuffer</code> to append.
         * @return the specified <code>StrinBuffer</code>.
         */
        public StringBuffer appendTo(StringBuffer sb) {
            return TypeFormat.format(_value, sb);
        }

        /**
         * Returns the decimal text representation of this number.
         *
         * @return the text representation of this number.
         */
        public String toString() {
            return appendTo(new StringBuffer(26)).toString();
        }

        /**
         * Indicates if two 32 bits float are "sufficiently" alike to be 
         * considered equal.
         *
         * @param  that the number to compare with.
         * @param  tolerance the maximum difference between them before
         *         they are considered <i>not</i> equal.
         * @return <code>true</code> if they are considered equal;
         *         <code>false</code> otherwise.
         */
        public boolean equals(Float32 that, float tolerance) {
            return Math.abs(this._value - that._value) <= tolerance;
        }

        /**
         * Compares this 32 bits float  against the specified object.
         *
         * @param  that the object to compare with.
         * @return <code>true</code> if the objects are the same;
         *         <code>false</code> otherwise.
         */
        public boolean equals(Object that) {
            return (that instanceof Float32)
                    && (this._value == ((Float32) that)._value);
        }

        /**
         * Returns the hash code for this number.
         *
         * @return the hash code value.
         */
        public int hashCode() {
            return Float.floatToIntBits(_value);
        }

        /**
         * Returns the value of this number as an <code>int</code>.
         *
         * @return the <code>int</code> value.
         */
        public int intValue() {
            return (int) _value;
        }

        /**
         * Returns the value of this number as a <code>long</code>.
         *
         * @return the <code>long</code> value. 
         */
        public long longValue() {
            return (long) _value;
        }

        /**
         * Returns the value of this number as a <code>float</code>.
         *
         * @return the <code>float</code> value.
         */
        public float floatValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>double</code>.
         *
         * @return the <code>double</code> value
         */
        public double doubleValue() {
            return _value;
        }

        /**
         * Compares two 32 bits float numerically.
         *
         * @param  that the number to compare with.
         * @return -1, 0 or 1 as this number is numerically less than, equal
         *         to, or greater than <code>that</code>.
         */
        public int compareTo(Float32 that) {
            if (this._value < that._value) {
                return -1;
            } else if (this._value > that._value) {
                return 1;
            } else {
                int i1 = Float.floatToIntBits(this._value);
                int i2 = Float.floatToIntBits(that._value);
                return (i1 == i2 ? 0 : (i1 < i2 ? -1 : 1));
            }
        }

        // Implements Comparable
        public int compareTo(Object that) {
            return this.compareTo((Float32) that);
        }

        // Implements Operable.
        public Operable plus(Operable that) {
            return this.add((Float32) that);
        }

        // Implements Operable.
        public Operable opposite() {
            return this.negate();
        }

        // Implements Operable.
        public Operable times(Operable that) {
            return this.multiply((Float32) that);
        }

        // Implements Operable.
        public Operable reciprocal() {
            return this.inverse();
        }

        // Implements Representable.
        public void toXml(XmlElement xml) {
            xml.setAttribute("value", _value);
        }

    }

    /**
     * <p> This class represents a 64 bits floating point number.</p>
     *
     * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
     * @version 5.1, August 27, 2003
     */
    public static final class Float64 extends RealtimeNumber implements
            Comparable, Operable, Representable {

        /**
         * Holds the factory used to produce 64 bits float instances.
         */
        private static final Factory FACTORY = new Factory() {

            public Object create() {
                return new Float64();
            }
        };

        /**
         * The 64 bits floating point representing zero.
         */
        public static final Float64 ZERO = (Float64) valueOf(0.0).toHeap();

        /**
         * The 64 bits float one.
         */
        public static final Float64 ONE = (Float64) valueOf(1.0).toHeap();

        /**
         * The associated double value.
         */
        private double _value;

        /**
         * Default constructor.
         */
        private Float64() {
        }

        /**
         * Returns the 64 bits float of specified <code>double</code> value.
         *
         * @param  doubleValue the <code>double</code> value for this number.
         * @return the corresponding number.
         * @see    #doubleValue()
         */
        public static Float64 valueOf(double doubleValue) {
            Float64 r = (Float64) FACTORY.object();
            r._value = doubleValue;
            return r;
        }

        /**
         * Returns the number for the specified character sequence.
         *
         * @param  chars the character sequence.
         * @return the corresponding number.
         */
        public static Float64 valueOf(CharSequence chars) {
            Float64 r = (Float64) FACTORY.object();
            r._value = TypeFormat.parseDouble(chars);
            return r;
        }

        /**
         * XML factory method.
         *
         * @param  xml the XML element describing the number to return (e.g.
         *         <code>&lt;math:Float64 value="0.0"/&gt;</code>).
         * @return a new number as described by the specified xml element.
         */
        public static Float64 valueOf(XmlElement xml) {
            Float64 r = (Float64) FACTORY.object();
            r._value = xml.getAttribute("value", 0.0);
            return r;
        }

        /**
         * Indicates if this number is infinite.
         *
         * @return <code>true</code> if this number is infinite;
         *         <code>false</code> otherwise.
         */
        public boolean isInfinite() {
            return Double.isInfinite(_value);
        }

        /**
         * Indicates if this number is not a number.
         *
         * @return <code>true</code> if this number is NaN;
         *         <code>false</code> otherwise.
         */
        public boolean isNaN() {
            return Double.isNaN(_value);
        }

        /**
         * Returns the negation of this number.
         *
         * @return <code>-this</code>.
         */
        public Float64 negate() {
            Float64 r = (Float64) FACTORY.object();
            r._value = -this._value;
            return r;
        }

        /**
         * Returns the sum of this number with the one specified.
         *
         * @param  that the number to be added.
         * @return <code>this + that</code>.
         */
        public Float64 add(Float64 that) {
            Float64 r = (Float64) FACTORY.object();
            r._value = this._value + that._value;
            return r;
        }

        /**
         * Returns the difference between this number and the one specified.
         *
         * @param  that the number to be subtracted.
         * @return <code>this - that</code>.
         */
        public Float64 subtract(Float64 that) {
            Float64 r = (Float64) FACTORY.object();
            r._value = this._value - that._value;
            return r;
        }

        /**
         * Returns the product of this number with the one specified.
         *
         * @param  that the number multiplier.
         * @return <code>this * that</code>.
         */
        public Float64 multiply(Float64 that) {
            Float64 r = (Float64) FACTORY.object();
            r._value = this._value * that._value;
            return r;
        }

        /**
         * Returns the inverse of this number.
         *
         * @return <code>1 / this</code>.
         */
        public Float64 inverse() {
            Float64 r = (Float64) FACTORY.object();
            r._value = 1.0 / this._value;
            return r;
        }

        /**
         * Returns this number divided by the one specified.
         *
         * @param  that the number divisor.
         * @return <code>this / that</code>.
         */
        public Float64 divide(Float64 that) {
            Float64 r = (Float64) FACTORY.object();
            r._value = this._value / that._value;
            return r;
        }

        /**
         * Returns the absolute value of this number.
         *
         * @return <code>abs(this)</code>.
         */
        public Float64 abs() {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.abs(this._value);
            return r;
        }

        /**
         * Returns the positive square root of this number.
         *
         * @return <code>sqrt(this)</code>.
         */
        public Float64 sqrt() {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.sqrt(this._value);
            return r;
        }

        /**
         * Returns the exponential number <i>e</i> raised to the power of this
         * number.
         *
         * @return <code>exp(this)</code>.
         */
        public Float64 exp() {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.exp(this._value);
            return r;
        }

        /**
         * Returns the natural logarithm (base e) of this number.
         *
         * @return <code>log(this)</code>.
         */
        public Float64 log() {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.log(this._value);
            return r;
        }

        /**
         * Returns this number raised to the specified power.
         *
         * @param  e the exponent.
         * @return <code>this**e</code>.
         */
        public Float64 pow(double e) {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.pow(this._value, e);
            return r;
        }

        /**
         * Returns this number raised to the power of the specified exponent.
         *
         * @param  that the exponent.
         * @return <code>this**that</code>.
         */
        public Float64 pow(Float64 that) {
            Float64 r = (Float64) FACTORY.object();
            r._value = Math.pow(this._value, that._value);
            return r;
        }

        /**
         * Appends the decimal text representation of this number
         * to the <code>StringBuffer</code> argument.
         *
         * @param  sb the <code>StrinBuffer</code> to append.
         * @return the specified <code>StrinBuffer</code>.
         */
        public StringBuffer appendTo(StringBuffer sb) {
            return TypeFormat.format(_value, sb);
        }

        /**
         * Returns the decimal text representation of this number.
         *
         * @return the text representation of this number.
         */
        public String toString() {
            return appendTo(new StringBuffer(26)).toString();
        }

        /**
         * Compares this number against the specified object.
         *
         * @param  that the object to compare with.
         * @return <code>true</code> if the objects are the same;
         *         <code>false</code> otherwise.
         */
        public boolean equals(Object that) {
            return (that instanceof Float64)
                    && (this._value == ((Float64) that)._value);
        }

        /**
         * Returns the hash code for this number.
         * 
         * @return the hash code value.
         */
        public int hashCode() {
            long bits = Double.doubleToLongBits(_value);
            return (int) (bits ^ (bits >>> 32));
        }

        /**
         * Returns the value of this number as an <code>int</code>.
         *
         * @return the <code>int</code> value.
         */
        public int intValue() {
            return (int) _value;
        }

        /**
         * Returns the value of this number as a <code>long</code>.
         *
         * @return the <code>long</code> value.
         */
        public long longValue() {
            return (long) _value;
        }

        /**
         * Returns the value of this number as a <code>float</code>.
         *
         * @return the <code>float</code> value.
         */
        public float floatValue() {
            return (float) _value;
        }

        /**
         * Returns the value of this number as a <code>double</code>.
         *
         * @return the <code>double</code> value.
         */
        public double doubleValue() {
            return _value;
        }

        /**
         * Compares two 64 bits float numerically.
         *
         * @param  that the number to compare with.
         * @return -1, 0 or 1 as this number is numerically less than, equal
         *         to, or greater than <code>that</code>.
         */
        public int compareTo(Float64 that) {
            if (this._value < that._value) {
                return -1;
            } else if (this._value > that._value) {
                return 1;
            } else {
                long l1 = Double.doubleToLongBits(this._value);
                long l2 = Double.doubleToLongBits(that._value);
                return (l1 == l2 ? 0 : (l1 < l2 ? -1 : 1));
            }
        }

        // Implements Comparable
        public int compareTo(Object that) {
            return this.compareTo((Float64) that);
        }

        // Implements Operable.
        public Operable plus(Operable that) {
            return this.add((Float64) that);
        }

        // Implements Operable.
        public Operable opposite() {
            return this.negate();
        }

        // Implements Operable.
        public Operable times(Operable that) {
            return this.multiply((Float64) that);
        }

        // Implements Operable.
        public Operable reciprocal() {
            return this.inverse();
        }

        // Implements Representable.
        public void toXml(XmlElement xml) {
            xml.setAttribute("value", _value);
        }

    }

    /**
     * <p> This class represents a 32 bits signed integer.</p>
     *
     * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
     * @version 5.1, August 27, 2003
     */
    public static final class Integer32 extends RealtimeNumber implements
            Comparable, Representable {

        /**
         * Holds the factory used to produce 32 bits integer instances.
         */
        private static final Factory FACTORY = new Factory() {

            public Object create() {
                return new Integer32();
            }
        };

        /**
         * The 32 bits integer representing zero.
         */
        public static final Integer32 ZERO = (Integer32) valueOf(0).toHeap();

        /**
         * The 32 bits integer one.
         */
        public static final Integer32 ONE = (Integer32) valueOf(1).toHeap();

        /**
         * The associated int value.
         */
        private int _value;

        /**
         * Default constructor.
         */
        private Integer32() {
        }

        /**
         * Returns the 32 bits integer of specified <code>int</code> value.
         *
         * @param  intValue the <code>int</code> value for this 32 bits integer.
         * @return the corresponding number.
         * @see    #intValue()
         */
        public static Integer32 valueOf(int intValue) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = intValue;
            return r;
        }

        /**
         * Returns the 32 bits integer for the specified character sequence.
         *
         * @param  chars the character sequence.
         * @return the corresponding number.
         */
        public static Integer32 valueOf(CharSequence chars) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = TypeFormat.parseInt(chars);
            return r;
        }

        /**
         * XML factory method.
         *
         * @param  xml the XML element describing the 32 bits integer to return
         *         (e.g.<code>&lt;math:Integer32 value="0"/&gt;</code>).
         * @return a new number as described by the specified xml element.
         */
        public static Integer32 valueOf(XmlElement xml) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = xml.getAttribute("value", 0);
            return r;
        }

        /**
         * Returns the negation of this number.
         *
         * @return <code>-this</code>.
         */
        public Integer32 negate() {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = -this._value;
            return r;
        }

        /**
         * Returns the sum of this number with the one specified.
         *
         * @param  that the number to be added.
         * @return <code>this + that</code>.
         */
        public Integer32 add(Integer32 that) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = this._value + that._value;
            return r;
        }

        /**
         * Returns the difference between this number and the one
         * specified.
         *
         * @param  that the number to be subtracted.
         * @return <code>this - that</code>.
         */
        public Integer32 subtract(Integer32 that) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = this._value - that._value;
            return r;
        }

        /**
         * Returns the product of this number with the one specified.
         *
         * @param  that the multiplier.
         * @return <code>this * that</code>.
         */
        public Integer32 multiply(Integer32 that) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = this._value * that._value;
            return r;
        }

        /**
         * Returns this number divided by the one specified.
         *
         * @param  that the divisor.
         * @return <code>this / that</code>.
         */
        public Integer32 divide(Integer32 that) {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = this._value / that._value;
            return r;
        }

        /**
         * Returns the absolute value of this number.
         *
         * @return <code>abs(this)</code>.
         */
        public Integer32 abs() {
            Integer32 r = (Integer32) FACTORY.object();
            r._value = Math.abs(this._value);
            return r;
        }

        /**
         * Appends the decimal text representation of this number
         * to the <code>StringBuffer</code> argument.
         *
         * @param  sb the <code>StrinBuffer</code> to append.
         * @return the specified <code>StrinBuffer</code>.
         */
        public StringBuffer appendTo(StringBuffer sb) {
            return TypeFormat.format(_value, sb);
        }

        /**
         * Returns the decimal text representation of this number.
         *
         * @return the text representation of this number.
         */
        public String toString() {
            return appendTo(new StringBuffer(11)).toString();
        }

        /**
         * Compares this number against the specified object.
         *
         * @param  that the object to compare with.
         * @return <code>true</code> if the objects are the same;
         *         <code>false</code> otherwise.
         */
        public boolean equals(Object that) {
            return (that instanceof Integer32)
                    && (this._value == ((Integer32) that)._value);
        }

        /**
         * Returns the hash code for this number.
         *
         * @return the hash code value.
         */
        public int hashCode() {
            return _value;
        }

        /**
         * Returns the value of this number as an <code>int</code>.
         *
         * @return the <code>int</code> value.
         */
        public int intValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>long</code>.
         *
         * @return the <code>long</code> value.
         */
        public long longValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>float</code>.
         *
         * @return the <code>float</code> value.
         */
        public float floatValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>double</code>.
         *
         * @return the <code>double</code> value.
         */
        public double doubleValue() {
            return _value;
        }

        /**
         * Compares two 32 bits integer numerically.
         *
         * @param  that the number to compare with.
         * @return -1, 0 or 1 as this numberis numerically less than,
         *         equal to, or greater than <code>that</code>.
         */
        public int compareTo(Integer32 that) {
            if (this._value < that._value) {
                return -1;
            } else if (this._value > that._value) {
                return 1;
            } else {
                return 0;
            }
        }

        // Implements Comparable
        public int compareTo(Object that) {
            return this.compareTo((Integer32) that);
        }

        // Implements Representable.
        public void toXml(XmlElement xml) {
            xml.setAttribute("value", _value);
        }

    }

    /**
     * <p> This class represents a 64 bits signed integer.</p>
     *
     * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
     * @version 5.1, August 27, 2003
     */
    public static final class Integer64 extends RealtimeNumber implements
            Comparable, Representable {

        /**
         * Holds the factory used to produce 32 bits integer instances.
         */
        private static final Factory FACTORY = new Factory() {

            public Object create() {
                return new Integer64();
            }
        };

        /**
         * The 64 bits integer representing zero.
         */
        public static final Integer64 ZERO = (Integer64) valueOf(0).toHeap();

        /**
         * The 64 bits integer one.
         */
        public static final Integer64 ONE = (Integer64) valueOf(1).toHeap();

        /**
         * The associated long value.
         */
        private long _value;

        /**
         * Default constructor.
         */
        private Integer64() {
        }

        /**
         * Returns the 64 bits integer of specified <code>long</code> value.
         *
         * @param  longValue the <code>long</code> value for this number.
         * @return the corresponding number.
         * @see    #intValue()
         */
        public static Integer64 valueOf(long longValue) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = longValue;
            return r;
        }

        /**
         * Returns the 64 bits integer for the specified character sequence.
         *
         * @param  chars the character sequence.
         * @return the corresponding number.
         */
        public static Integer64 valueOf(CharSequence chars) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = TypeFormat.parseInt(chars);
            return r;
        }

        /**
         * XML factory method.
         *
         * @param  xml the XML element describing the number to return
         *         (e.g.<code>&lt;math:Integer64 value="0"/&gt;</code>).
         * @return a new number as described by the specified xml element.
         */
        public static Integer64 valueOf(XmlElement xml) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = xml.getAttribute("value", 0L);
            return r;
        }

        /**
         * Returns the negation of this number.
         *
         * @return <code>-this</code>.
         */
        public Integer64 negate() {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = -this._value;
            return r;
        }

        /**
         * Returns the sum of this number with the one specified.
         *
         * @param  that the number to be added.
         * @return <code>this + that</code>.
         */
        public Integer64 add(Integer64 that) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = this._value + that._value;
            return r;
        }

        /**
         * Returns the difference between this number and the one
         * specified.
         *
         * @param  that the number to be subtracted.
         * @return <code>this - that</code>.
         */
        public Integer64 subtract(Integer64 that) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = this._value - that._value;
            return r;
        }

        /**
         * Returns the product of this number with the one specified.
         *
         * @param  that the multiplier.
         * @return <code>this * that</code>.
         */
        public Integer64 multiply(Integer64 that) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = this._value * that._value;
            return r;
        }

        /**
         * Returns this number divided by the one specified.
         *
         * @param  that the divisor.
         * @return <code>this / that</code>.
         */
        public Integer64 divide(Integer64 that) {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = this._value / that._value;
            return r;
        }

        /**
         * Returns the absolute value of this number.
         *
         * @return <code>abs(this)</code>.
         */
        public Integer64 abs() {
            Integer64 r = (Integer64) FACTORY.object();
            r._value = Math.abs(this._value);
            return r;
        }

        /**
         * Appends the decimal text representation of this number
         * to the <code>StringBuffer</code> argument.
         *
         * @param  sb the <code>StrinBuffer</code> to append.
         * @return the specified <code>StrinBuffer</code>.
         */
        public StringBuffer appendTo(StringBuffer sb) {
            return TypeFormat.format(_value, sb);
        }

        /**
         * Returns the decimal text representation of this number.
         *
         * @return the text representation of this number.
         */
        public String toString() {
            return appendTo(new StringBuffer(21)).toString();
        }

        /**
         * Compares this number against the specified object.
         *
         * @param  that the object to compare with.
         * @return <code>true</code> if the objects are the same;
         *         <code>false</code> otherwise.
         */
        public boolean equals(Object that) {
            return (that instanceof Integer64)
                    && (this._value == ((Integer64) that)._value);
        }

        /**
         * Returns the hash code for this number.
         *
         * @return the hash code value.
         */
        public int hashCode() {
            return (int) _value;
        }

        /**
         * Returns the value of this number as an <code>int</code>.
         *
         * @return the <code>int</code> value.
         */
        public int intValue() {
            return (int) _value;
        }

        /**
         * Returns the value of this number as a <code>long</code>.
         *
         * @return the <code>long</code> value.
         */
        public long longValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>float</code>.
         *
         * @return the <code>float</code> value.
         */
        public float floatValue() {
            return _value;
        }

        /**
         * Returns the value of this number as a <code>double</code>.
         *
         * @return the <code>double</code> value.
         */
        public double doubleValue() {
            return _value;
        }

        /**
         * Compares two 64 bits integer numerically.
         *
         * @param  that the number to compare with.
         * @return -1, 0 or 1 as this number is numerically less than,
         *         equal to, or greater than <code>that</code>.
         */
        public int compareTo(Integer64 that) {
            if (this._value < that._value) {
                return -1;
            } else if (this._value > that._value) {
                return 1;
            } else {
                return 0;
            }
        }

        // Implements Comparable
        public int compareTo(Object that) {
            return this.compareTo((Integer64) that);
        }

        // Implements Representable.
        public void toXml(XmlElement xml) {
            xml.setAttribute("value", _value);
        }

    }
}