/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.xml.sax.ErrorHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.dautelle.util.FastMap;
import com.dautelle.xml.sax.Attributes;
import com.dautelle.xml.sax.ContentHandler;

/**
 * <p> This class handles SAX2 events during the construction process.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.0, February 29, 2003
 * @see     Constructor
 */
final class ConstructorHandler implements ContentHandler, ErrorHandler {

    /**
     * The parameter signature for the factory method <code>valueOf</code>.
     */
    private static final Class[] PARAM_XML_ELEMENT
        = new Class[] { XmlElement.class };

    /**
     * Holds the current nesting level (0 is the document level)
     */
    private int _level;

    /**
     * Holds the current character buffer.
     */
    private final StringBuffer _charBuffer = new StringBuffer();

    /**
     * Holds the document locator.
     */
    private Locator _locator; 

    /**
     * Holds the root object.
     */
    Object _root;

    /**
     * Holds the stack of XML elements (nesting limited to 64).
     */
    final XmlElement[] _stack = new XmlElement[64];

    /**
     * Default constructor.
     */
    ConstructorHandler() {
        _stack[0] = new XmlElement();
        for (int i=1; i < _stack.length; i++) {
            _stack[i] = new XmlElement();
            _stack[i]._parent = _stack[i-1];
        }
    }

    /**
     * Receive an object for locating the origin of SAX document events.
     *
     * <p> SAX parsers are strongly encouraged (though not absolutely
     *     required) to supply a locator: if it does so, it must supply
     *     the locator to the application by invoking this method before
     *     invoking any of the other methods in the ContentHandler
     *     interface.</p>
     *
     * <p> The locator allows the application to determine the end
     *     position of any document-related event, even if the parser is
     *     not reporting an error.  Typically, the application will
     *     use this information for reporting its own errors (such as
     *     character content that does not match an application's
     *     business rules).  The information returned by the locator
     *     is probably not sufficient for use with a search engine.</p>
     *
     * <p> Note that the locator will return correct information only
     *     during the invocation of the events in this interface.  The
     *     application should not attempt to use it at any other time.</p>
     *
     * @param  locator an object that can return the location of any SAX
     *         document event.
     */
    public void setDocumentLocator (Locator locator) {
        _locator = locator;
    }

    /**
     * Receives notification of the beginning of the document.
     *
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void startDocument() throws SAXException {
        _level = 0;
    }

    /**
     * Receives notification of the end of the document.
     *
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void endDocument() throws SAXException {
        if (_stack[0]._content.size() == 1) {
            _root = _stack[0]._content.get(0);
        } else {
            _root = null;
        }
        // Clean-up (e.g. if parsing failed)
        for (int i=0; i <= _level; i++) {
            _stack[i].reset();
        }
    }

    /**
     * Receives notification of the start of an element.
     *
     * @param  uri the namespace.
     * @param  localName the local name.
     * @param  qName the raw XML 1.0 name.
     * @param  attributes the attributes.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void startElement(CharSequence uri, CharSequence localName,
                             CharSequence qName, Attributes attributes)
            throws SAXException {
        flushCharData(); // Flushes buffer.
        XmlElement xml = _stack[++_level];
        xml._factoryClass = classFor(uri, localName);
        for (int i = 0; i < attributes.getLength(); i++) {
            CharSequence key = attributes.getQName(i);
            CharSequence value = attributes.getValue(i);
            xml.setAttribute(key, value);
        }
    }

    /**
     * Receives notification of the end of an element.
     *
     * @param  uri the namespace.
     * @param  localName the local name.
     * @param  qName the raw XML 1.0 name.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void endElement(CharSequence uri, CharSequence localName,
                           CharSequence qName)
            throws SAXException {
        flushCharData(); // Flushes buffer.

        // Creates the object from the XML element.
        XmlElement xml = _stack[_level];
        try {
            Method valueOf = (Method) _methodCache.get(xml._factoryClass);
            if (valueOf == null) { // Cache miss.
                valueOf = xml._factoryClass.getMethod(
                    "valueOf", PARAM_XML_ELEMENT);
                _methodCache.put(xml._factoryClass, valueOf);
            }
            _paramsTmp[0] = _stack[_level];
            Object obj = valueOf.invoke(null, _paramsTmp);
            _stack[_level-1]._content.add(obj);
        } catch (IllegalAccessException e1) {
            throw new SAXParseException(
                qName + " valueOf(XmlElement) inaccessible", _locator);
        } catch (NoSuchMethodException e3) {
            throw new SAXParseException(
                qName + " valueOf(XmlElement) not found", _locator);
        } catch (InvocationTargetException e6) {
            throw new SAXParseException(
                qName + " valueOf(XmlElement) throws " +
                e6.getTargetException(), _locator);
        }

        // Clears the xml element (for reuse latter).
        _stack[_level].reset();
        _level--;
    }
    private final Object[] _paramsTmp = new Object[1];
    private final FastMap _methodCache = new FastMap();

    /**
     * Receives notification of character data.
     *
     * @param ch the characters from the XML document.
     * @param start the start position in the array.
     * @param length the number of characters to read from the array.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void characters(char ch[], int start, int length)
            throws SAXException {
        _charBuffer.append(ch, start, length);
    }

    // Implements ContentHandler
    public void startPrefixMapping(CharSequence prefix, CharSequence uri)
        throws SAXException {}

    // Implements ContentHandler
    public void endPrefixMapping(CharSequence prefix) throws SAXException {}

    // Implements ContentHandler
    public void ignorableWhitespace(char ch[], int start, int length)
        throws SAXException {}

    // Implements ContentHandler
    public void processingInstruction(CharSequence target, CharSequence data)
        throws SAXException {}

    // Implements ContentHandler
    public void skippedEntity(CharSequence name) throws SAXException {}

    /**
     * Receives notification of a parser warning. The warning is printed to
     * the error stream (System.err)
     *
     * @param e the warning information encoded as an exception.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void warning(SAXParseException e) throws SAXException {
	System.err.println("XML Parsing Warning: " + e);
    }

    /**
     * Receive notification of a recoverable parser error.
     * This implementation throws a ConstructorException.
     *
     * @param e the error encoded as an exception.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void error(SAXParseException e) throws SAXException {
	throw e;
    }

    /**
     * Report a fatal XML parsing error.
     *
     * @param e the error information encoded as an exception.
     * @throws SAXException any SAX exception, possibly wrapping
     *         another exception.
     */
    public void fatalError(SAXParseException e) throws SAXException {
	throw e;
    }

    /**
     * Adds any CharData object to the enclosing element if it contains at least
     * one character different from white space.
     */
    private void flushCharData() {
        for (int i=0; i < _charBuffer.length(); i++) {
            if (_charBuffer.charAt(i) > ' ') {
                CharData charData = new CharData(_charBuffer.toString());
                _stack[_level]._content.add(charData);
                break;
            }
        }
        _charBuffer.setLength(0);
    }

    /**
     * Returns the class for the specified Java URI and local name.
     *
     * @param  uri the package name.
     * @param  localName the relative name of the class.
     * @return the corresponding class.
     * @throws SAXException invalid URI (must use a java scheme).
     */
    private Class classFor(CharSequence uri, CharSequence localName)
            throws SAXException {
        ClassRecord cr = (ClassRecord) _classRecords.get(localName);
        if ((cr != null) && (uri.equals(cr._uri))) {
            return cr._class; // Cache hit.
        }
        String className;
        String uriString = uri.toString();
        String localNameString = localName.toString();
        if (uri.length() == 0) {
            className = localNameString;
        } else if (uriString.startsWith("java:")) {
            String pkg = uriString.substring(5);
            className = (pkg.length() == 0) ? localNameString :
                                              pkg + "." + localName;
        } else {
            throw new SAXParseException(
                "Invalid URI (must use a java scheme)", _locator);
        }
        try {
            cr = new ClassRecord();
            cr._uri = uriString;
            cr._class = Class.forName(className);
            _classRecords.put(localNameString, cr);
            return cr._class;
        } catch (ClassNotFoundException e) {
            throw new SAXParseException(
                "Class " + className + " not found", _locator);
        }
    }
    private FastMap _classRecords = new FastMap();
    private static class ClassRecord {
        String _uri;
        Class _class;
    }

}