/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.util.ArrayList;

import com.dautelle.util.Utf8StreamWriter;

/**
 * <p> This class takes a {@link Representable} object and formats it to
 *     a stream as XML. Objects written using this facility may be read using
 *     the {@link Constructor} class.</p>
 * <p> Namespaces are supported (including default namespace).</p>
 * <p> For example, the following code creates an <code>ObjectWriter</code>
 *     using a default namespace for all classes within the package
 *     <code>com.dautelle</code>, excepts for the <code>com.dautelle.math</code>
 *     classes which will be using the <code>math</code> prefix.
 *    <pre>
 *        ObjectWriter objectWriter = new ObjectWriter();
 *        objectWriter.setNamespace("", "com.dautelle"); // Default namespace.
 *        objectWriter.setNamespace("math", "com.dautelle.math");
 *        ...
 *        objectWriter.write(matrix, outputStream);// Uses UTF-8 encoding.
 *        objectWriter.write(matrix, writer);      // Uses UTF-16 encoding.
 *    </pre></p>
 * <p> The more discriminative namespace is used during serialization. If an
 *     object being serialized has no matching namespace (including the default
 *     namespace for which the default value <code>""</code> matches all
 *     possible classes), then a local namespace is automatically created
 *     (with the prefix <code>pkg</code>).</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.0, February 29, 2003
 */
public class ObjectWriter {

    /**
     * Holds the list of prefixes.
     */
    private final ArrayList _prefixes = new ArrayList();

    /**
     * Holds the list of packages.
     */
    private final ArrayList _packages = new ArrayList();

    /**
     * Holds the document indent (default two-space indent).
     */
    private String _indent = "  ";

    /**
     * Indicates if the prolog has to be written (default <code>false</code>).
     */
    private boolean _isProlog = true;

    /**
     * Holds the stack of XML elements (nesting limited to 64).
     */
    private final XmlElement[] _stack = new XmlElement[64];

    /**
     * Holds the stream writer.
     */
    private final Utf8StreamWriter _utf8StreamWriter
        = new Utf8StreamWriter(2048);

    /**
     * Creates a default writer.
     */
    public ObjectWriter() {
        _stack[0] = new XmlElement();
        for (int i=1; i < _stack.length; i++) {
            _stack[i] = new XmlElement();
            _stack[i]._parent = _stack[i-1];
        }
        // Default namespace association.
        _prefixes.add("");
        _packages.add("");
    }

    /**
     * Maps a namespace to a Java package. The specified prefix is used to
     * shorten the tag name of the object being serialized. For example:
     * <code>setNamespace("math", "com.dautelle.math")</code> associates the
     * namespace prefix <code>math</code> with the namespace name
     * <code>java:com.dautelle.math</code>. Any class within the package
     * <code>com.dautelle.math</code> now uses the <code>math</code> prefix
     * (e.g. &lt;math:Complex real='0' imaginary='1'\&gt;).
     * Any previous association of the specified prefix or package is removed.
     *
     * @param  prefix the namespace prefix or <code>""</code> to set the default
     *         namespace.
     * @param  packageName of the package associated to the specified prefix.
     * @throws IllegalArgumentException if the prefix <code>"pkg"</code> if
     *         used (reserved for local namespace declarations).
     */
    public void setNamespace(String prefix, String packageName) {
        if (packageName.equals("pkg")) {
            throw new IllegalArgumentException(
                "Prefix \"pkg\" is reserved for local namespace declarations");
        }

        // Removes any previous association of the specified package.
        for (int i=0; i < _packages.size(); i++) {
            if (packageName.equals(_packages.get(i))) {
                _packages.remove(i);
                _prefixes.remove(i);
                break;
            }
        }

        // Overrides prefix association (if any)
        for (int i=0; i < _prefixes.size(); i++) {
            if (prefix.equals(_prefixes.get(i))) {
                _packages.set(i, packageName);
                return; // Done.
            }
        }

        // New association.
        _prefixes.add(prefix);
        _packages.add(packageName);
    }

    /**
     * Sets the indentation <code>String</code> (default two-spaces).
     *
     * @param  indent the indent <code>String</code>, usually some number of
     *         spaces.
     */
    public void setIndent(String indent) {
        _indent = indent;
    }

    /**
     * Indicates if the XML prolog has to be written
     * (default <code>true</code>).
     *
     * @param  isProlog <code>true</code> if the XML prolog has to be written;
     *         <code>false</code> otherwise.
     */
    public void setProlog(boolean isProlog) {
        _isProlog = isProlog;
    }

    /**
     * Writes the specified <code>Representable</code> to the specified
     * file in XML format. The characters are written using UTF-8 encoding.
     *
     * @param  r the <code>Representable</code> object to format.
     * @param  file the file to write to.
     * @throws IOException if there's any problem writing.
     */
    public void write(Representable r, File file) throws IOException {
        write(r, new FileOutputStream(file));
    }

    /**
     * Writes the specified <code>Representable</code> to the given output
     * stream in XML format. The characters are written using UTF-8 encoding.
     *
     * @param  r the <code>Representable</code> object to format.
     * @param  out the output stream to write to.
     * @throws IOException if there's any problem writing.
     */
    public void write(Representable r, OutputStream out) throws IOException {
        _utf8StreamWriter.setOutputStream(out);
        if (_isProlog) {
            _utf8StreamWriter.write(
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            _utf8StreamWriter.write('\n');
        }
        writeElement(r, _utf8StreamWriter, 0);
        _utf8StreamWriter.close();
    }

    /**
     * Writes the specified <code>Representable</code> to the given writer
     * in XML format. The characters are written using UTF-16 encoding.
     *
     * @param  r the <code>Representable</code> object to format.
     * @param  writer the writer to write to.
     * @throws IOException if there's any problem writing.
     */
    public void write(Representable r, Writer writer) throws IOException {
        if (_isProlog) {
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-16\"?>");
            writer.write('\n');
        }
        writeElement(r, writer, 0);
        writer.close();
    }

    /*
     * Writes the specified element.
     *
     * @param the r <code>Representable</code> to output.
     * @param out the writer to write to.
     * @param level the level of nesting (0 for root).
     */
    private void writeElement(Representable r, Writer writer, int level)
            throws IOException {

        // Checks for CharData
        if (r instanceof CharData) {
            writer.write(escapeSpecialCharacters(r.toString()));
            return;
        }
        // Indentation.
        if (level > 0) {
            writer.write('\n');
            for (int i=0; i < level; i++) {
                writer.write(_indent);
            }
        }

        // Serializes.
        XmlElement xml = _stack[level];
        xml._factoryClass = r.getClass();
        r.toXml(xml);

        // Searches for associated prefix with longest package name.
        String prefix = null;
        String pkgName = "";
        String className = xml._factoryClass.getName();

        for (int i=0; i < _packages.size(); i++) {
            String pkg = (String) _packages.get(i);
            if (    (pkg.length() >= pkgName.length()) &&
                    (className.startsWith(pkg)) ) {
                prefix = (String) _prefixes.get(i);
                pkgName = pkg;
            }
        }
        if (prefix == null) {
            // None found, not even default namespace, use local pkg namespace.
            prefix = "pkg";
            pkgName = xml._factoryClass.getPackage().getName();
        }

        // Construct element's tag.
        String tag = (pkgName.length() != 0) ?
            (prefix.length() != 0) ?
                prefix + ":" + className.substring(pkgName.length()+1) :
                className.substring(pkgName.length()+1) :
            (prefix.length() != 0) ?
                prefix + ":" + className : className;

        // Writes start tag.
        writer.write('<');
        writer.write(tag);
        if (level == 0) {
            // Writes namespace declaration (root).
            for (int i = 0; i < _prefixes.size(); i++) {
                String pfx = (String) _prefixes.get(i);
                String pkg = (String) _packages.get(i);
                if (pfx.length() == 0) { // Default namespace.
                    if (pkg.length() != 0) {
                        writer.write(" xmlns=\"java:");
                        writer.write(pkg);
                        writer.write('"');
                    }
                } else {
                    writer.write(" xmlns:");
                    writer.write(pfx);
                    writer.write("=\"java:");
                    writer.write(pkg);
                    writer.write('"');
                }
            }
        }
        if (prefix.equals("pkg")) { // Local namespace.
            writer.write(" xmlns:pkg=\"java:");
            writer.write(pkgName);
            writer.write('"');
        }

        // Writes attributes
        for (int i=0; i < xml._attributeNames.size(); i++) {
            String key = xml._attributeNames.get(i).toString();
            String value = xml._attributeValues.get(i).toString();
            writer.write(' ');
            writer.write(key);
            writer.write("=\"");
            writer.write(escapeSpecialCharacters(value));
            writer.write('"');
        }
        // Writes content
        if (xml.isEmpty()) {
            writer.write("/>"); // Empty element.
        } else {
            writer.write(">");
            for (int i=0; i < xml._content.size(); i++) {
                Representable child = (Representable) xml._content.get(i);
                writeElement(child, writer, level + 1);
            }
            // Indentation.
            writer.write('\n');
            for (int i=0; i < level; i++) {
                writer.write(_indent);
            }
            writer.write("</");
            writer.write(tag);
            writer.write('>');
        }

        // Clears XmlElement for reuse.
        xml.reset();
    }

    /*
     * Replaces special characters with their appropriate entity reference
     * suitable for XML attributes.
     */
    private String escapeSpecialCharacters(String str) {
        _tmpBuff.setLength(0);
        boolean escapeFound = false;
        for (int i=0; i < str.length(); i++) {
            char c = str.charAt(i);
            switch (c) {
                case '<':
                    _tmpBuff.append("&lt;");
                    escapeFound = true;
                    break;
                case '>':
                    _tmpBuff.append("&gt;");
                    escapeFound = true;
                    break;
                case '\'':
                    _tmpBuff.append("&apos;");
                    escapeFound = true;
                    break;
                case '\"':
                    _tmpBuff.append("&quot;");
                    escapeFound = true;
                    break;
                case '&':
                    _tmpBuff.append("&amp;");
                    escapeFound = true;
                    break;
                default:
                    if (c >= ' ') {
                        _tmpBuff.append(c);
                    } else {
                        _tmpBuff.append("&#" + Integer.toString(c) + ";");
                        escapeFound = true;
                    }
            }
        }
        if (!escapeFound) {
            return str;
        } else {
            return _tmpBuff.toString();
        }
    }
    private StringBuffer _tmpBuff = new StringBuffer();
}