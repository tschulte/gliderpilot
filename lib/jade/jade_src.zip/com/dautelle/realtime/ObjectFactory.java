/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;

import com.dautelle.util.TypeFormat;

/**
 * <p> This class represents an object factory. How and when a factory allocates
 *     its objects depends upon its real-time context. The default context
 *     ({@link HeapContext}) allocates objects on-demand (from the heap)
 *     and recycling is done through garbage collection.</p>
 * <p> Object factories should be used preferably to class constructors 
 *     (ref. "new" keyword) to allow for "stack" allocation when the current 
 *     thread executes in a {@link PoolContext}:<pre>
 *     static final ObjectFactory STRING_BUFFER_FACTORY = new ObjectFactory() {
 *         public Object create() {
 *             return new StringBuffer(26);
 *         }
 *     };
 *     // Unlike toString() the following method avoids heap allocation.
 *     public CharSequence toChars() {  
 *         StringBuffer sb 
 *              = (StringBuffer) STRING_BUFFER_FACTORY.object();
 *         ... // Formats this object into sb 
 *         ... // (e.g. using {@link com.dautelle.util.TypeFormat TypeFormat})
 *         return sb; // On the stack when executing in a pool context.
 *     }</pre></p>
 * <p> It is also possible to {@link #cleanup} factories' objects for future 
 *     reuse (e.g. to clear references to external objects allocated on the
 *     heap and allow these external objects to be garbage collected):<pre>
 *     static final ObjectFactory ARRAY_LIST_FACTORY = new ObjectFactory() {
 *         public Object create() {
 *              return new ArrayList(256);
 *         }
 *         public void cleanup(Object obj) {
 *             ((ArrayList)obj).clear();
 *         }  
 *     };</pre>
 * <p> Instances of this class are typically <code>private static final</code>.
 *     They serve to implement the {@link Realtime} interface either   
 *     by extending {@link RealtimeObject} (recommended) or directly when 
 *     the class hierarchy cannot be modified. For example:<pre>
 *     public class Foo extends LegacyClass implements {@link Realtime} {
 *         private static final ObjectFactory FACTORY = new ObjectFactory() {
 *             public Object create() {
 *                 return new Foo(currentPool());
 *             }
 *         };
 *         private ObjectPool _pool; // The pool this object belongs to.
 *         protected Foo(ObjectPool pool) { // Base constructor for sub-classes.
 *             _pool = pool;
 *         }
 *         public static Foo newInstance() { // Static factory method.
 *             return (Foo) FACTORY.object();
 *         }
 *         public Object export() {
 *             if (_pool.isLocal()) {
 *                 _pool = _pool.export(this);
 *             }  
 *             return this;    
 *         }
 *         public Object toHeap() {
 *             if (_pool.isLocal()) {
 *                 _pool = _pool.remove(this);
 *             } else if (!_pool.isHeap()) {
 *                 // Non-local pools require synchronization.
 *                 synchronized (_pool) {
 *                    _pool = _pool.remove(this);
 *                 }
 *             } // Else already on the heap.
 *             return this;
 *         }
 *     }</pre>
 * </p>
 * <p> The number of instances of this class is voluntarely limited (see 
 *     <a href="{@docRoot}/overview-summary.html#configuration">JADE's 
 *     Configuration</a> for details). Instances of this class should be either 
 *     <code>static</code> or member of persistent objects.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 16, 2004
 */
public abstract class ObjectFactory {

    /**
     * Holds the maximum number of {@link ObjectFactory} (system property 
     * <code>"jade.factories"</code>, default <code>256</code>).
     */
    public static final int MAX = TypeFormat.parseInt(System.getProperty(
            "jade.factories", "256"));

    /**
     * Holds the factory instances.
     */
    static ObjectFactory[] INSTANCES = new ObjectFactory[MAX];

    /**
     * Holds the current number of instances.
     */
    static volatile int Count;

    /**
     * Holds the factory identifier (range [0..MAX[).
     */
    int id;

    /**
     * Holds the current pool when executing in a heap context.
     */
    private ObjectPool _heapPool;

    /**
     * Default constructor.
     * 
     * @throws UnsupportedOperationException if already {@link #MAX} 
     *         factories exist. 
     */
    protected ObjectFactory() {
        synchronized (INSTANCES) {
            if (ObjectFactory.Count < MAX) {
                INSTANCES[ObjectFactory.Count] = this;
                id = ObjectFactory.Count++;
                _heapPool = newPool();
            } else {
                throw new UnsupportedOperationException(
                        "Maximum number of factories (" + MAX
                                + ") has been reached");
            }
        }
    }

    /**
     * Returns a new object from this factory allocated on the heap.
     *
     * @return a new object allocated on the heap.
     */
    public abstract Object create();

    /**
     * Cleans-up this factory's object for future reuse. 
     * When overriden, this method is called on objects being recycled to 
     * dispose of system resources or to clear any reference to external
     * objects potentially on the heap (it allows these external objects to
     * be garbage collected). For example:<pre>
     * static final ObjectFactory MY_ARRAY_LIST_FACTORY = new ObjectFactory() {
     *      public Object create() {
     *          return new ArrayList(256);
     *      }
     *      protected void cleanup(Object obj) {
     *          ((ArrayList)obj).clear();
     *      }  
     * };</pre>
     *
     * @param  obj the object product of this factory being recycled.
     * @throws UnsupportedOperationException if this factory does not 
     *         support object clean-up (default).
     */
    public void cleanup(Object obj) {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the pool for the current thread. If the current thread is not
     * executing in a {@link PoolContext}, then the {@link #heapPool heap pool}
     * is returned.
     * 
     * @return the pool for the current thread.
     * @see    ObjectPool#isHeap
     */
    public final ObjectPool currentPool() { // Fast version.
        PoolContext poolContext = Context.current().poolContext();
        if (poolContext != null) {
            return poolContext.getLocalPool(this);
        } else { // Heap.
            return _heapPool;
        }
    }

    /**
     * Returns a pool from this factory which represents the heap.
     * 
     * @return a heap pool.
     */
    public final ObjectPool heapPool() {
        return _heapPool;
    }

    /**
     * Creates a new pool for this object factory (initially representing 
     * the heap). Sub-classes may override this method in order 
     * to use custom pools.
     * 
     * @return a default implementation for {@link ObjectPool}.
     */
    protected ObjectPool newPool() {
        return new DefaultPool(this);
    }
}