/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.physics.models;

import javax.units.Converter;
import javax.units.MultiplyConverter;
import javax.units.SI;
import javax.units.Unit;

/**
 * This class represents the natural model.
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 4.1, February 17, 2003
 */
public final class NaturalModel extends PhysicalModel {

    /**
     * Holds the single instance of this class.
     */
    private final static NaturalModel INSTANCE = new NaturalModel();

    /**
     * Selects the natural model as the current model.
     */
    public static void select() {
        INSTANCE.setPhysicalDimensions();
        PhysicalModel.setCurrent(INSTANCE);
    }

    /**
     * Sets the dimensional units of the seven base quantities as follow:
     * <ul>
     * <li>{@link com.dautelle.physics.Length} : <code>"1"</code></li>
     * <li>{@link com.dautelle.physics.Mass} : <code>"1"</code></li>
     * <li>{@link com.dautelle.physics.Duration Duration} : <code>"1"</code></li>
     * <li>{@link com.dautelle.physics.ElectricCurrent ElectricCurrent} : <code>"1"</code></li>
     * <li>{@link com.dautelle.physics.Temperature Temperature} : <code>"1"</code></li>
     * <li>{@link com.dautelle.physics.AmountOfSubstance AmountOfSubstance} : <code>"mol"</code></li>
     * <li>{@link com.dautelle.physics.LuminousIntensity LuminousIntensity} : <code>"cd"</code></li>
     * </ul>
     *
     * @see     javax.units.BaseUnit#setDimension
     */
    protected final void setPhysicalDimensions() {

        // H_BAR (SECOND * JOULE = SECOND * (KILOGRAM / C^2 )) = 1
        // SPEED_OF_LIGHT (METER / SECOND) = 1
        // BOLTZMANN (JOULE / KELVIN = (KILOGRAM / C^2 ) / KELVIN) = 1
        // MAGNETIC CONSTANT (NEWTON / AMPERE^2) = 1
        // GRAVITATIONAL CONSTANT (METER^3 / KILOGRAM / SECOND^2) = 1
        SI.SECOND.setDimension(Unit.ONE, new MultiplyConverter((c * c)
                * Math.sqrt(c / (hBar * G))));
        SI.METER.setDimension(Unit.ONE, new MultiplyConverter(c
                * Math.sqrt(c / (hBar * G))));
        SI.KILOGRAM.setDimension(Unit.ONE, new MultiplyConverter(Math.sqrt(G
                / (hBar * c))));
        SI.KELVIN.setDimension(Unit.ONE, new MultiplyConverter(k
                * Math.sqrt(G / (hBar * c)) / (c * c)));
        SI.AMPERE.setDimension(Unit.ONE, new MultiplyConverter(Math
                .sqrt(µ0 * G)
                / (c * c)));
        SI.MOLE.setDimension(SI.MOLE, Converter.IDENTITY);
        SI.CANDELA.setDimension(SI.CANDELA, Converter.IDENTITY);
    }
}
