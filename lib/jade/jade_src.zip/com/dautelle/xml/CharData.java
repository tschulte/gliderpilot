/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.xml;

/**
 * <p> This class represents the text that is not markup and constitutes
 *     the character data of a XML document.</p>
 * <p> During parsing, instances of this class are generated for character data
 *     containing at least one non-whitespace character.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 5.3, October 13, 2003
 */
public class CharData implements Representable {

    /**
     * Holds the text.
     */
    private final String _text;

    /**
     * Creates a {@link CharData} instance with the specified text.
     *
     * @param text the text of this <code>CharData</code>.
     */
    public CharData(String text) {
        _text = text;
    }

    /**
     * Returns the text of this {@link CharData}.
     *
     * @return the text of this <code>CharData</code>.
     */
    public String toString() {
        return _text;
    }

    // Implements Representable.
    public void toXml(XmlElement xml) {
        // Do nothing, tagging class.
    }
}