/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.math;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;

import com.dautelle.math.Numerics.Integer32;
import com.dautelle.realtime.ArrayPool;
import com.dautelle.realtime.ConcurrentContext;
import com.dautelle.realtime.LocalContext;
import com.dautelle.realtime.ObjectPool;
import com.dautelle.realtime.PoolContext;
import com.dautelle.realtime.RealtimeObject;
import com.dautelle.realtime.ConcurrentContext.Logic;
import com.dautelle.xml.Representable;
import com.dautelle.xml.XmlElement;

/**
 * <p> This class represents a rectangular array of {@link Operable}
 *     objects. It may be used to resolve system of linear equations
 *     involving <i>any kind</i> of {@link Operable} elements
 *     (e.g. {@link Real}, {@link Complex}, 
 *     {@link com.dautelle.physics.Quantity Quantity},
 *     {@link com.dautelle.math.functions.Function Function}, etc).</p>
 *
 * <p> Non-commutative multiplication is supported and this class itself
 *     implements the {@link Operable} interface. Consequently, this class may
 *     be used to resolve system of linear equations involving matrices
 *     (for which the multiplication is not commutative).</p>
 *
 * <p> <b>Implementation Note:</b> This class uses {@link ConcurrentContext}
 *     to accelerate calculations on multi-processor systems.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, May 11, 2004
 * @see     com.dautelle.realtime
 */
public class Matrix extends RealtimeObject implements Operable, Representable {

    /**
     * Holds the Matrix factory.
     */
    private static final Factory FACTORY = new Factory() {

        public Object create() {
            return new Matrix();
        }
        // No need to override cleanup, real-time arrays from ArrayPool
        // clean themselves up.
    };

    /**
     * The array of operable objects (M[i][j] = o[i*n+j], i < m, j < n).
     */
    Operable[] o;

    /**
     * Holds the number of rows.
     */
    int m;

    /**
     * Holds the number of columns.
     */
    int n;

    /**
     * Default constructor.
     */
    Matrix() {
    }

    /**
     * Returns a m-by-n matrix filled with <code>null</code> elements.
     *
     * @param  m the number of rows.
     * @param  n the number of columns.
     * @return a m-by-n matrix non-initialized.
     */
    public static Matrix newInstance(int m, int n) {
        Matrix M = (Matrix) FACTORY.object();
        M.o = (Operable[]) ArrayPool.array(Operable.class, m * n).next();
        M.m = m;
        M.n = n;
        return M;
    }

    /**
     * Returns a m-by-n matrix filled with the specified diagonal element
     * and the specified non-diagonal element.
     * This constructor may be used to create an identity matrix
     * (e.g. <code>valueOf(n, n, ONE, ZERO)</code>).
     *
     * @param  m the number of rows.
     * @param  n the number of columns.
     * @param  diagonal the diagonal element.
     * @param  other the non-diagonal element.
     * @return a m-by-n matrix with <code>d</code> on the diagonal and
     *         <code>o</code> elsewhere.
     */
    public static Matrix valueOf(int m, int n, Operable diagonal, Operable other) {
        Matrix M = newInstance(m, n);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                M.o[i * n + j] = (i != j) ? other : diagonal;
            }
        }
        return M;
    }

    /**
     * Returns a matrix from a 2-dimensional array of {@link Operable} objects.
     * The first dimension being the row and the second being the column.
     *
     * <p>Note: It is safe to reuse the specifed array as it is not internally
     *          referenced by the matrix being returned.</p>
     *
     * @param  elements the array of {@link Operable} objects.
     * @return the matrix having the specified components.
     * @throws IllegalArgumentException all rows must have the same length.
     */
    public static Matrix valueOf(Operable[][] elements) {
        int m = elements.length;
        int n = elements[0].length;
        Matrix M = newInstance(m, n);
        for (int i = 0; i < m; i++) {
            if (elements[i].length == n) {
                System.arraycopy(elements[i], 0, M.o, i * n, n);
            } else {
                throw new IllegalArgumentException(
                        "All rows must have the same length.");
            }
        }
        return M;
    }

    /**
     * Returns a m-by-n matrix populated from the specified collection of
     * {@link Operable} objects (rows first).
     *
     * @param  m the number of rows.
     * @param  n the number of columns.
     * @param  elements the collection of {@link Operable} objects.
     * @return the matrix having the specified size and elements.
     * @throws MatrixDimensionException if <code>elements.size() != m * n</code>
     * @throws ClassCastException if any of the element is not {@link Operable}.
     */
    public static Matrix valueOf(int m, int n, Collection elements) {
        if (elements.size() == m * n) {
            Matrix M = newInstance(m, n);
            Iterator iterator = elements.iterator();
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    M.o[i * n + j] = (Operable) iterator.next();
                }
            }
            return M;
        } else {
            throw new MatrixDimensionException(m * n
                    + " elements expected but found " + elements.size());
        }
    }

    /**
     * XML factory method.
     *
     * @param  xml the XML element describing the matrix to return.
     * For example: <pre>
     *             &lt;math:Matrix row="2" column="1"&gt;
     *                 &lt;math:Complex real="1.0" imaginary="0.0"/&gt;
     *                 &lt;math:Complex real="0.0" imaginary="1.0"/&gt;
     *             &lt;/math:Matrix&gt;</pre>
     *
     * @return a new matrix as described by the specified XML element.
     */
    public static Matrix valueOf(XmlElement xml) {
        return valueOf(xml.getAttribute("row", 1), xml
                .getAttribute("column", 1), xml);
    }

    /**
     * Returns the row dimension of this matrix.
     *
     * @return m, the number of rows.
     */
    public final int getRowDimension() {
        return m;
    }

    /**
     * Returns the column dimension of this matrix.
     *
     * @return n, the number of columns.
     */
    public final int getColumnDimension() {
        return n;
    }

    /**
     * Indicates if this matrix is square.
     *
     * @return <code>getRowDimension == getColumnDimension</code>
     */
    public final boolean isSquare() {
        return m == n;
    }

    /**
     * Returns a single element from this matrix.
     *
     * @param  i the row index (range [0..m]).
     * @param  j the column index (range [0..n]).
     * @return the element read at [i,j].
     * @throws IndexOutOfBoundsException <code>i &gt;= getRowDimension() |
     *         j &gt;= getColumnDimension()</code>.
     */
    public final Operable get(int i, int j) {
        if ((i < m) && (j < n)) {
            return o[i * n + j];
        } else {
            throw new IndexOutOfBoundsException("i: " + i + ", j: " + j
                    + " (matrix[" + n + "," + m + "])");
        }
    }

    /**
     * Sets a single element of this matrix.
     *
     * @param  i the row index (range [0..m]).
     * @param  j the column index (range [0..n]).
     * @param  element the element set at [i,j].
     * @throws IndexOutOfBoundsException <code>i &gt;= getRowDimension() |
     *         j &gt;= getColumnDimension()</code>.
     */
    public final void set(int i, int j, Operable element) {
        if ((i < m) && (j < n)) {
            o[i * n + j] = element;
        } else {
            throw new IndexOutOfBoundsException("i: " + i + ", j: " + j
                    + " (matrix[" + n + "," + m + "])");
        }
    }

    /**
     * Returns a sub-matrix of this matrix given the range of its rows and
     * columns indices.
     *
     * @param  i0 the initial row index.
     * @param  i1 the final row index.
     * @param  j0 the initial column index.
     * @param  j1 the final column index.
     * @return <code>THIS(i0:i1, j0:j1)</code>
     */
    public final Matrix getMatrix(int i0, int i1, int j0, int j1) {
        int Mm = i1 - i0 + 1;
        int Mn = j1 - j0 + 1;
        Matrix M = newInstance(Mm, Mn);
        for (int i = 0; i < Mm; i++) {
            for (int j = 0; j < Mn; j++) {
                M.o[i * Mn + j] = this.o[(i + i0) * n + j + j0];
            }
        }
        return M;
    }

    /**
     * Returns a sub-matrix composed of the specified rows and columns from
     * this matrix.
     *
     * @param  rows the indices of the rows to return.
     * @param  columns the indices of the columns to return.
     * @return the sub-matrix from the specified rows and columns.
     */
    public final Matrix getMatrix(int[] rows, int[] columns) {
        int Mm = rows.length;
        int Mn = columns.length;
        Matrix M = newInstance(Mm, Mn);
        for (int i = 0; i < Mm; i++) {
            for (int j = 0; j < Mn; j++) {
                M.o[i * Mn + j] = this.o[rows[i] * n + columns[j]];
            }
        }
        return M;
    }

    /**
     * Returns the {@link LUDecomposition} of this {@link Matrix}.
     * Numerical stability is guaranteed  (through pivoting) if the
     * {@link Operable} elements of this matrix are derived
     * from <code>java.lang.Number</code>. For others elements types,
     * numerical stability can be ensured by setting the 
     * {@link LUDecomposition#setPivotComparator local pivot comparator}.
     *
     * @return the decomposition of this matrix into a product of upper and
     *         lower triangular matrices.
     */
    public final LUDecomposition lu() {
        return LUDecomposition.valueOf(this);
    }

    /**
     * Indicates if this matrix is equal to the object specified.
     *
     * @param  that the object to compare for equality.
     * @return <code>true</code> if this matrix and the specified object are
     *         considered equal; <code>false</code> otherwise.
     */
    public final boolean equals(Object that) {
        if (this == that) {
            return true;
        } else if (that instanceof Matrix) {
            Matrix M = (Matrix) that;
            if (M.m != this.m || M.n != this.n) {
                return false;
            } else {
                for (int i = m * n; i > 0;) {
                    if (!this.o[--i].equals(M.o[i])) { return false; }
                }
                return true;
            }
        } else {
            return false;
        }
    }

    /**
     * Returns a hash code value for this matrix.
     * Equals object have equal hash codes.
     *
     * @return this matrix hash code value.
     * @see    #equals
     */
    public final int hashCode() {
        int code = 0;
        for (int i = m * n; i > 0;) {
            code += o[--i].hashCode();
        }
        return code;
    }

    /**
     * Returns the negation of this matrix.
     *
     * @return <code>-this</code>.
     */
    public final Matrix negate() {
        Matrix M = newInstance(m, n);
        for (int i = m * n; i > 0;) {
            M.o[--i] = this.o[i].opposite();
        }
        return M;
    }

    /**
     * Returns the sum of this matrix with the one specified.
     *
     * @param   that the matrix to be added.
     * @return  <code>this + that</code>.
     * @throws  MatrixDimensionException matrices's dimensions are different.
     */
    public final Matrix add(Matrix that) {
        if ((this.m == that.m) && (this.n == that.n)) {
            Matrix M = newInstance(m, n);
            for (int i = m * n; i > 0;) {
                M.o[--i] = this.o[i].plus(that.o[i]);
            }
            return M;
        } else {
            throw new MatrixDimensionException();
        }
    }

    /**
     * Returns the difference between this matrix and the one specified.
     *
     * @param  that the matrix to be subtracted.
     * @return <code>this - that</code>.
     * @throws MatrixDimensionException matrices's dimensions are different.
     */
    public final Matrix subtract(Matrix that) {
        if ((this.m == that.m) && (this.n == that.n)) {
            Matrix M = newInstance(m, n);
            for (int i = m * n; i > 0;) {
                M.o[--i] = this.o[i].plus(that.o[i].opposite());
            }
            return M;
        } else {
            throw new MatrixDimensionException();
        }
    }

    /**
     * Return the multiplication of this matrix with the specified factor.
     *
     * @param  k the coefficient multiplier.
     * @return <code>k * M</code>.
     */
    public final Matrix multiply(Operable k) {
        Matrix M = newInstance(m, n);
        for (int i = m * n; i > 0;) {
            M.o[--i] = k.times(this.o[i]);
        }
        return M;
    }

    /**
     * Returns the product of this matrix with the one specified.

     * <p> Note: This method uses {@link ConcurrentContext} to reduce garbage 
     *           and accelerate calculation on multi-processor systems.</p>  
     *
     * @param  that the matrix multiplier.
     * @return <code>this * that</code>.
     * @throws MatrixDimensionException <code>M.getRowDimension()
     *         != this.getColumnDimension()</code>.
     */
    public Matrix multiply(Matrix that) {
        if (this.n == that.m) {
            if (n < 32) { // Sequential calculation.
                Matrix M = newInstance(this.m, that.n);
                for (int i = 0; i < this.m; i++) {
                    final int i_n = i * n;
                    for (int j = 0; j < that.n; j++) {
                        Operable sum = this.o[i_n].times(that.o[j]);
                        for (int k = 1; k < this.n; k++) {
                            sum = sum.plus(this.o[i_n + k].times(that.o[k
                                    * that.n + j]));
                        }
                        M.o[i * M.n + j] = sum;
                    }
                }
                return M;
            } else { // Concurrent calculation.
                return concurrentMultiply(that);
            }
        } else {
            throw new MatrixDimensionException();
        }
    }

    private Matrix concurrentMultiply(Matrix that) {
        ConcurrentContext.enter();
        try {
            Matrix M = newInstance(this.m, that.n);
            for (int i = 0; i < this.m; i++) {
                for (int j = 0; j < that.n; j++) {
                    ConcurrentContext.execute(MULTIPLY_ROW_COLUMN, this, that,
                            M, Integer32.valueOf(i), Integer32.valueOf(j));
                }
            }
            return M; // No need to export result, only the concurrent
        } finally { // logic is performed in a pool context.
            ConcurrentContext.exit();
        }
    }

    private static final Logic MULTIPLY_ROW_COLUMN = new Logic() {

        public void run(Object[] args) {
            Matrix left = (Matrix) args[0];
            Matrix right = (Matrix) args[1];
            Matrix result = (Matrix) args[2];
            int i = ((Integer32) args[3]).intValue();
            int j = ((Integer32) args[4]).intValue();
            int i_n = i * left.n;
            Operable sum = left.o[i_n].times(right.o[j]);
            for (int k = 1; k < left.n; k++) {
                sum = sum.plus(left.o[i_n + k].times(right.o[k * right.n + j]));
            }
            result.o[i * result.n + j] = sum;
            sum.export();
        }
    };

    /**
     * Returns this matrix divided by the one specified.
     *
     * @param  that the matrix divisor.
     * @return <code>this.multiply(that.inverse())</code>.
     */
    public Matrix divide(Matrix that) {
        return this.multiply(that.inverse());
    }

    /**
     * Returns the pseudo-inverse of this matrix. The matrix doesn't need
     * to be square and can be ill-formed. Stability is guaranteed.
     *
     * @return the pseudo-inverse of this matrix.
     */
    public Matrix pseudoInverse() {
        Matrix thisTranspose = this.transpose();
        return (thisTranspose.multiply(this)).inverse().multiply(thisTranspose);
    }

    /**
     * Returns the inverse of this matrix.
     *
     * <p> Note: To resolve the equation <code>A * X = B</code>,
     *           it is usually faster to calculate <code>A.lu().solve(B)</code>
     *           rather than <code>A.inverse().times(B)</code>.</p>
     *
     * @return  the inverse or this matrix or its {@link #pseudoInverse} if 
     *          the matrix is not square.
     * @see     #lu
     */
    public Matrix inverse() {
        if (isSquare()) {
            return lu().inverse();
        } else {
            return pseudoInverse();
        }
    }

    /**
     * Returns the linear algebraic matrix tensor product of this matrix
     * and another.
     *
     * @param  that the second matrix.
     * @return the Kronecker Tensor (direct) product of <code>this</code>
     *         and <code>that</code>.
     * @since  January 2002, by Jonathan Grattage (jjg99c@cs.nott.ac.uk).
     */
    public Matrix tensor(Matrix that) {
        Matrix C = newInstance(this.m * that.m, this.n * that.n);
        boolean endCol = false;
        int cCount = 0, rCount = 0;
        int subMatrix = 0, iref = 0, jref = 0;
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < m; i++) {
                Matrix X = that.multiply(o[i * this.n + j]);
                rCount = subMatrix % m;
                if (rCount > 0) {
                    endCol = true;
                }
                if ((rCount == 0) && (endCol == true)) {
                    cCount++;
                }
                for (int y = 0; y < that.n; y++) {
                    for (int x = 0; x < that.m; x++) {
                        iref = x + (rCount * that.m);
                        jref = y + (cCount * that.m);
                        C.o[iref * C.n + jref] = X.get(x, y);
                    }
                }
                subMatrix++;
            }
        }
        return C;
    }

    /**
     * Returns the text representation of this matrix.
     *
     * @return the text representation of this matrix.
     */
    public String toString() {
        StringBuffer sb = new StringBuffer(32);
        sb.append("{");
        for (int i = 0; i < m; i++) {
            sb.append("{");
            for (int j = 0; j < n; j++) {
                sb.append(o[i * n + j].toString());
                if (j != n - 1) {
                    sb.append(", ");
                }
            }
            if (i != m - 1) {
                sb.append("},\n ");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    /**
     * Returns the transpose of this matrix.
     *
     * @return <code>A'</code>.
     */
    public Matrix transpose() {
        Matrix M = newInstance(n, m);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                M.o[j * m + i] = o[i * n + j];
            }
        }
        return M;
    }

    /**
     * Returns the determinant of this matrix. This method uses the matrix 
     * LU decomposition to guarantee correct results even for 
     * non-commutative operables (the famous formula: <i>a00·a11-a10·a01</i> 
     * for 2x2 matrices is incorrect when operables are non-commutative).
     *
     * @return <code>lu().determinant()</code>
     * @throws MatrixDimensionException matrix is not square.
     */
    public Operable determinant() {
        return lu().determinant();
    }

    /**
     * Returns the cofactor of an element in this matrix. It is the value
     * obtained by evaluating the determinant formed by the elements not in
     * that particular row or column.
     *
     * @param  i the row index.
     * @param  j the column index.
     * @return the cofactor of <code>THIS[i,j]</code>.
     * @throws MatrixDimensionException matrix is not square or its dimension
     *         is less than 2.
     */
    public Operable cofactor(int i, int j) {
        Matrix M = newInstance(m - 1, n - 1);
        int row = 0;
        for (int k1 = 0; k1 < m; k1++) {
            if (k1 == i) {
                continue;
            }
            int column = 0;
            for (int k2 = 0; k2 < n; k2++) {
                if (k2 == j) {
                    continue;
                }
                M.o[row * M.n + column] = o[k1 * n + k2];
                column++;
            }
            row++;
        }
        return M.determinant();
    }

    /**
     * Returns the trace of this matrix.
     *
     * @return the sum of the diagonal elements.
     */
    public Operable trace() {
        Operable sum = o[0];
        for (int i = Math.min(m, n); i > 1;) {
            sum = sum.plus(o[--i * n + i]);
        }
        return sum;
    }

    /**
     * Returns the adjoint of this matrix. It is obtained by replacing each
     * element in this matrix with its cofactor and applying a + or - sign
     * according (-1)**(i+j), and then finding the transpose of the resulting
     * matrix.
     *
     * @return the adjoint of this matrix.
     * @throws MatrixDimensionException if this matrix is not square or if
     *         its dimension is less than 2.
     */
    public Matrix adjoint() {
        Matrix M = newInstance(m, n);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                M.o[i * n + j] = ((i + j) % 2 == 0) ? this.cofactor(i, j)
                        : this.cofactor(i, j).opposite();
            }
        }
        return M.transpose();
    }

    // Implements Operable.
    public Operable plus(Operable that) {
        return add((Matrix) that);
    }

    // Implements Operable.
    public Operable opposite() {
        return this.negate();
    }

    // Implements Operable.
    public Operable times(Operable that) {
        return multiply((Matrix) that);
    }

    // Implements Operable.
    public Operable reciprocal() {
        return this.inverse();
    }

    // Implements Representable.
    public void toXml(XmlElement xml) {
        xml.setAttribute("row", m);
        xml.setAttribute("column", n);
        final int mn = m * n;
        for (int i = 0; i < mn; i++) {
            xml.add(o[i]);
        }
    }

    // Overrides.
    public Object export() {
        if (isLocalObject()) {
            super.export();
            o = (Operable[]) ArrayPool.outerCopy(o, 0, m * n);
            for (int i = m * n; i > 0;) { // Exports operable themselves.
                o[--i].export();
            }
        } // Else non-local objects cannot refer to local object.
        return this;
    }

    // Overrides.
    public Object toHeap() {
        if (isPoolObject()) {
            super.toHeap();
            o = (Operable[]) ArrayPool.heapCopy(o, 0, m * n);
            for (int i = m * n; i > 0;) { // Exports operable themselves.
                o[--i].toHeap();
            }
        } // Else heap object can only refer to heap objects.
        return this;
    }

    /**
     * <p> This class represents the decomposition of a {@link Matrix} into
     *     a product of lower and upper triangular matrices
     *     (L and U, respectively).</p>
     * <p> <a href="http://mathworld.wolfram.com/LUDecomposition.html">
     *     This decomposition</a> is typically used to resolve linear systems
     *     of equations (Gaussian elimination) or to calculate the determinant
     *     of a square {@link Matrix} (<code>O(n³)</code>).</p>
     * <p> Numerical stability is guaranteed through pivoting if the
     *     {@link Operable} elements of this matrix are derived
     *     from <code>java.lang.Number</code>. For others elements types,
     *     numerical stability can be ensured by setting the appropriate 
     *     pivot comparator (see {@link #setPivotComparator}).</p>
     * <p> Instances of this class are created using the {@link Matrix#lu()}
     *     factory methods.</p>
     *
     * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
     * @version 6.0, April 28, 2004
     */
    public static final class LUDecomposition extends RealtimeObject {

        /**
         * Holds the comparator for pivoting <code>java.lang.Number</code>
         * instances.
         */
        public static final Comparator NUMBER_COMPARATOR = new Comparator() {

            public int compare(Object left, Object right) {
                if ((left instanceof Number) && (right instanceof Number)) {
                    return Math.abs(((Number) left).doubleValue()) > Math
                            .abs(((Number) right).doubleValue()) ? 1 : -1;
                } else {
                    return 0;
                }
            }
        };

        /**
         * Holds the LUDecomposition factory.
         */
        private static final Factory LU_FACTORY = new Factory() {

            public Object create() {
                return new LUDecomposition();
            }
            // No need to override cleanup, real-time arrays from ArrayPool
            // clean themselves up.
        };

        /**
         * Holds the local comparator.
         */
        private static final LocalContext.Variable PIVOT_COMPARATOR = new LocalContext.Variable(
                NUMBER_COMPARATOR);

        /**
         * Holds the size of the square matrix source.
         */
        private int _size;

        /**
         * Holds the LU elements.
         */
        private Operable[] _lu;

        /**
         * Holds the pivots indexes.
         */
        private int[] _pivots;

        /**
         * Holds the number of permutation performed.
         */
        private int _permutationCount;

        /**
         * Default constructor.
         */
        LUDecomposition() {
        }

        /**
         * Returns the LU decomposition of the specified matrix..
         *
         * @param  source the matrix for which the LU decomposition is 
         *         returned.
         * @return the corresponding LU decomposition.
         * @throws MatrixDimensionException if this matrix is not square.
         */
        static LUDecomposition valueOf(Matrix source) {
            if (source.isSquare()) {
                int size = source.m;
                LUDecomposition lu = (LUDecomposition) LU_FACTORY.object();
                lu._lu = (Operable[]) ArrayPool.array(Operable.class,
                        size * size).next();
                lu._pivots = (int[]) ArrayPool.intArray(size).next();
                lu._size = size;
                lu._permutationCount = 0;
                lu.construct(source);
                return lu;
            } else {
                throw new MatrixDimensionException("Matrix is not square");
            }
        }

        /**
         * Sets the {@link LocalContext local} comparator used 
         * for pivoting during LU decomposition (default 
         * {@link #NUMBER_COMPARATOR}).
         *
         * @param  cmp the comparator for pivoting.
         */
        public void setPivotComparator(Comparator cmp) {
            PIVOT_COMPARATOR.setValue(cmp);
        }

        /**
         * Returns the solution X of the equation: A * X = B  with
         * <code>this = A.lu()</code> using back and forward substitutions.
         *
         * @param  B the input vector.
         * @return the solution X = (1 / A) * B.
         * @throws MatrixDimensionException if
         *         <code>A.getRowDimension() != B.getRowDimension()</code>.
         */
        public Matrix solve(Matrix B) {
            if (_size == B.m) {

                // Copies B with pivoting.
                final int n = B.n;
                Matrix X = Matrix.newInstance(_size, n);
                final Operable[] x = X.o;
                for (int i = 0; i < _size; i++) {
                    for (int j = 0; j < n; j++) {
                        x[i * n + j] = B.o[_pivots[i] * n + j];
                    }
                }

                // Solves L * Y = pivot(B)
                for (int k = 0; k < _size; k++) {
                    for (int i = k + 1; i < _size; i++) {
                        Operable luik = _lu[i * _size + k];
                        for (int j = 0; j < n; j++) {
                            x[i * n + j] = x[i * n + j].plus(luik.times(
                                    x[k * n + j]).opposite());
                        }
                    }
                }

                // Solves U * X = Y;
                for (int k = _size - 1; k >= 0; k--) {
                    for (int j = 0; j < n; j++) {
                        x[k * n + j] = _lu[k * _size + k].reciprocal().times(
                                x[k * n + j]);
                    }
                    for (int i = 0; i < k; i++) {
                        Operable luik = _lu[i * _size + k];
                        for (int j = 0; j < n; j++) {
                            x[i * n + j] = x[i * n + j].plus(luik.times(
                                    x[k * n + j]).opposite());
                        }
                    }
                }

                return X;

            } else {
                throw new MatrixDimensionException("Input vector has " + B.m
                        + " rows instead of " + _size);
            }
        }

        /**
         * Returns the solution X of the equation: A * X = Identity  with
         * <code>this = A.lu()</code> using back and forward substitutions.
         * This method uses {@link PoolContext} internally.
         *
         * @return <code>this.solve(Identity)</code>
         */
        public Matrix inverse() {
            // Calculates inv(U).
            final int n = _size;
            Matrix R = Matrix.newInstance(n, n);
            final Operable[] r = R.o;
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {
                    r[i * n + j] = _lu[i * n + j];
                }
            }
            for (int j = n - 1; j >= 0; j--) {
                r[j * n + j] = r[j * n + j].reciprocal();
                for (int i = j - 1; i >= 0; i--) {
                    PoolContext.enter();
                    try {
                        Operable sum = r[i * n + j].times(r[j * n + j])
                                .opposite();
                        for (int k = j - 1; k > i; k--) {
                            sum = sum.plus(r[i * n + k].times(r[k * n + j])
                                    .opposite());
                        }
                        r[i * n + j] = r[i * n + i].reciprocal().times(sum);
                        r[i * n + j].export();
                    } finally {
                        PoolContext.exit();
                    }
                }
            }
            // Solves inv(A) * L = inv(U)
            for (int i = 0; i < n; i++) {
                for (int j = n - 2; j >= 0; j--) {
                    PoolContext.enter();
                    try {
                        for (int k = j + 1; k < n; k++) {
                            Operable lukj = _lu[k * n + j];
                            if (r[i * n + j] != null) {
                                r[i * n + j] = r[i * n + j].plus(r[i * n + k]
                                        .times(lukj).opposite());
                            } else {
                                r[i * n + j] = r[i * n + k].times(lukj)
                                        .opposite();
                            }
                        }
                        r[i * n + j].export();
                    } finally {
                        PoolContext.exit();
                    }
                }
            }
            // Swaps columns (reverses pivots permutations).
            ObjectPool pool = ArrayPool.array(Operable.class, n);
            Operable[] tmp = (Operable[]) pool.next();
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    tmp[j] = r[i * n + j];
                }
                for (int j = 0; j < n; j++) {
                    r[i * n + _pivots[j]] = tmp[j];
                }
            }
            pool.recycle(tmp);
            return R;
        }

        /**
         * Returns the determinant of the {@link Matrix} having this
         * {@link Matrix.LUDecomposition}.
         *
         * @return the determinant of the matrix source.
         */
        public Operable determinant() {
            Operable product = _lu[0];
            for (int i = 1; i < _size; i++) {
                product = product.times(_lu[i * _size + i]);
            }
            return ((_permutationCount & 1) == 0) ? product : product
                    .opposite();
        }

        /**
         * Constructs the LU decomposition of the specified matrix.
         * We make the choise of Lii = ONE (diagonal elements of the
         * lower triangular matrix are multiplicative identities).
         *
         * @param  source the matrix to decompose.
         * @throws MatrixDimensionException if the matrix source is not square.
         */
        private void construct(Matrix source) {
            System.arraycopy(source.o, 0, _lu, 0, _size * _size);
            for (int i = 0; i < _size; i++) {
                _pivots[i] = i;
            }

            // Main loop.
            Comparator cmp = (Comparator) PIVOT_COMPARATOR.getValue();
            final int n = _size;
            for (int k = 0; k < _size; k++) {

                // Rearranges the rows so that the absolutely largest
                // elements of the matrix source in each column lies
                // in the diagonal.
                int pivot = k;
                for (int i = k + 1; i < n; i++) {
                    if (cmp.compare(_lu[i * n + k], _lu[pivot * n + k]) > 0) {
                        pivot = i;
                    }
                }
                if (pivot != k) { // Exchanges.
                    for (int j = 0; j < n; j++) {
                        Operable tmp = _lu[pivot * n + j];
                        _lu[pivot * n + j] = _lu[k * n + j];
                        _lu[k * n + j] = tmp;
                    }
                    int j = _pivots[pivot];
                    _pivots[pivot] = _pivots[k];
                    _pivots[k] = j;
                    _permutationCount++;
                }

                // Computes multipliers and eliminate k-th column.
                Operable lukkInv = _lu[k * n + k].reciprocal();
                for (int i = k + 1; i < n; i++) {
                    // Multiplicative order is important
                    // for non-commutative elements.
                    _lu[i * n + k] = _lu[i * n + k].times(lukkInv);
                    for (int j = k + 1; j < n; j++) {
                        _lu[i * n + j] = _lu[i * n + j].plus(_lu[i * n + k]
                                .times(_lu[k * n + j]).opposite());
                    }
                }
            }
        }

        // Overrides.
        public Object export() {
            if (isLocalObject()) {
                // Exports the operable array out of its current pool.
                ObjectPool luPool = ArrayPool.array(Operable.class, _size
                        * _size);
                luPool.export(_lu);
                for (int i = _size * _size; i > 0;) { // Exports operable themselves.
                    _lu[--i].export();
                }
                // Exports the pivot array out of its current pool.
                ObjectPool pivotsPool = ArrayPool.intArray(_size);
                pivotsPool.export(_pivots);
                super.export();
            } // Else non-local objects cannot refer to local object.
            return this;
        }

        // Overrides.
        public Object toHeap() {
            if (isPoolObject()) {
                // Copies the operable array to the heap.
                _lu = (Operable[]) _lu.clone(); // Clone are always on the heap.
                for (int i = _size * _size; i > 0;) {
                    _lu[--i].toHeap(); // Moves operable themselves.
                }
                // Copies the pivot array to the heap.
                _pivots = (int[]) _pivots.clone(); // Clone are always on the heap.
                super.toHeap();
            } // Else heap object cannot refer to pool objects.
            return this;
        }
    }
}