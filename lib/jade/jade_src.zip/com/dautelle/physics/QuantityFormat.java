/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.physics;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;

import javax.units.Converter;
import javax.units.Unit;

import com.dautelle.util.TypeFormat;

/**
 * <p> This is the abstract base class for all quantity formats.</p>
 * <p> This class provides the interface for formatting and parsing
 *     quantity.</p>
 * <p> Instances of this class can be used to define the default 
 *     output format for quantities (ref. {@link Quantity#setFormat}).</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, February 29, 2003
 */
public abstract class QuantityFormat extends Format {

    /**
     * Base constructor.
     */
    protected QuantityFormat() {}

    /**
     * Returns the default quantity format. 
     * Only the digits guaranteed to be exact are written out.
     * In other words, the error is always on the last digit and less than
     * the last digit weight. For example, if "1.33" is appended then the
     * quantity is guaranteed to be in the range <code>]1.32, 1.34[</code>.
     *
     *
     * @return the default quantity format.
     */
    public final static QuantityFormat getInstance() {
        return Default.INSTANCE;
    }

    /**
     * Formats a quantity and appends the resulting text to a given string
     * buffer.
     *
     * @param  obj the quantity to format.
     * @param  toAppendTo where the text is to be appended
     * @param  pos  a <code>FieldPosition</code> identifying a field
     *         in the formatted text (not used).
     * @return the string buffer passed in as <code>toAppendTo</code>,
     *         with formatted text appended.
     * @throws NullPointerException if <code>toAppendTo</code> is
     *         <code>null</code>
     * @throws IllegalArgumentException if this format cannot format the given
     *         object (e.g. not a <code>Quantity</code> instance).
     */
    public final StringBuffer format(Object obj, StringBuffer toAppendTo,
            FieldPosition pos) {
        return format((Quantity) obj, toAppendTo, ((Quantity) obj)
                .getOutputUnit());
    }

    /**
     * Parses text from a string to produce an object.
     *
     * @param  source a <code>String</code>, part of which should be parsed.
     * @param  pos a <code>ParsePosition</code> object with index and error
     *         index information.
     * @return an <code>Object</code> parsed from the string. In case of
     *         error, returns null.
     */
    public final Object parseObject(String source, ParsePosition pos) {
        try {
            int start = pos.getIndex();
            Quantity quantity = parse(source.substring(start));
            pos.setIndex(source.length()); // Parsing uses all characters up to
            // the end of the string.
            return quantity;
        } catch (ParseException e) {
            pos.setErrorIndex(e.getErrorOffset());
            return null;
        }
    }

    /**
     * Parses text from a character sequence to produce a quantity.
     * 
     * @param  source the characters sequence to be parsed.
     * @return a <code>Quantity</code> parsed from the string.
     * @throws ParseException if a parsing error occurs.
     */
    public abstract Quantity parse(CharSequence source) throws ParseException;

    /**
     * Formats a quantity and appends the resulting text to a given string
     * buffer.
     *
     * @param  quantity the quantity to format.
     * @param  toAppendTo where the text is to be appended.
     * @param  outputUnit the output unit for the quantity.
     * @return the string buffer passed in as <code>toAppendTo</code>,
     *         with formatted text appended.
     * @throws NullPointerException if <code>toAppendTo</code> is
     *         <code>null</code>
     * @throws IllegalArgumentException if this format cannot format the given
     *         object (e.g. not a <code>Quantity</code> instance).
     */
    public abstract StringBuffer format(Quantity quantity,
            StringBuffer toAppendTo, Unit outputUnit);

    /**
     * This inner class represents the default quantity format.
     */
    private static final class Default extends QuantityFormat {

        /**
         * Holds default instance.
         */
        private static final Default INSTANCE = new Default();

        /**
         * Default constructor.
         */
        private Default() {}

        // Implements abstract method.
        public StringBuffer format(Quantity q, StringBuffer toAppendTo,
                Unit outputUnit) {
            double min = q.getMinimum();
            double max = q.getMaximum();
            if (q.getSystemUnit() != outputUnit) { // Convert.
                Converter cvtr = q.getSystemUnit().getConverterTo(outputUnit);
                min = cvtr.convert(q.getMinimum());
                max = cvtr.convert(q.getMaximum());
            }
            double value = (min + max) / 2.0;
            double error = Math.max(Double.MIN_VALUE, Math.max(max - min,
                    Math.abs(value) * Quantity.DOUBLE_RELATIVE_ERROR) * 10);
            TypeFormat.format(value, error, toAppendTo);
            toAppendTo.append(' ');
            return outputUnit.appendTo(toAppendTo);
        }

        public Quantity parse(CharSequence source) throws ParseException {
            // Searches for ' ' (separator value/unit)
            int sepIndex = source.length();
            for (int i = 0; i < source.length(); i++) {
                if (source.charAt(i) == ' ') {
                    sepIndex = i;
                    break;
                }
            }
            Unit unit = Unit.valueOf(source.subSequence(sepIndex, source
                    .length()));
            double amount = TypeFormat.parseDouble(source.subSequence(0,
                    sepIndex));
            return Quantity.valueOf(amount, unit);
        }
    }
}