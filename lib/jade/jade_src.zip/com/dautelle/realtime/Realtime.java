/*
 * J.A.D.E. Java(TM) Addition to Default Environment.
 * Latest release available at http://jade.dautelle.com/
 * Copyright (C) 2004 Jean-Marie Dautelle.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation (http://www.gnu.org/copyleft/lesser.html); either version
 * 2.1 of the License, or any later version.
 */
package com.dautelle.realtime;
import java.io.Serializable;

/**
 * <p> This interface identifies classes with higher performance and higher
 *     predictability when their methods are executed within 
 *     a {@link PoolContext}.</p>
 * <p> Classes implementing this interface can be allocated on the stack and
 *     do not generate garbage.</p>
 *
 * @author  <a href="mailto:jean-marie@dautelle.com">Jean-Marie Dautelle</a>
 * @version 6.0, February 15,  2004
 */
public interface Realtime extends Serializable {

    /**
     * Exports this object out of the current pool context. 
     * {@link Realtime} members are exported as well (recursion).
     * This method affects only objects belonging to the current pool context.
     * 
     * @return <code>this</code>
     */
    Object export();

    /**
     * Moves this object to the heap.
     * {@link Realtime} members are moved to the heap as well (recursion).
     * This method affects only objects belonging to a pool context.
     * 
     * @return <code>this</code>
     */
    Object toHeap();

}